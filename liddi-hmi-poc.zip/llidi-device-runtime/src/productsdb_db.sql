--
-- File generated with SQLiteStudio v3.3.3 on Fri May 5 01:09:38 2023
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: brands
CREATE TABLE brands (brand VARCHAR (24), manufacturer VARCHAR (32), active BOOLEAN DEFAULT (1), countrycode VARCHAR (2), shortname VARCHAR (48), description VARCHAR (96), imageref VARCHAR (255), UNIQUE (brand, countrycode));

-- Table: products
CREATE TABLE products (upc VARCHAR (24) UNIQUE, active BOOLEAN DEFAULT (1), sku VARCHAR (24) PRIMARY KEY UNIQUE, material VARCHAR (24), brand VARCHAR (24), descriptor VARCHAR (128), "group" VARCHAR (32), uom VARCHAR, qty INTEGER, sub_qty INTEGER, power DECIMAL, cylinder DECIMAL, axis INTEGER, "add" VARCHAR, base_curve DECIMAL);

-- Table: sysparam
CREATE TABLE sysparam (
    sysparamid INTEGER  PRIMARY KEY
                        NOT NULL,
    created    DATETIME NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
    createdby  VARCHAR,
    updated    DATETIME,
    updatedby  VARCHAR,
    name       VARCHAR  NOT NULL,
    [group]    VARCHAR  DEFAULT ('sys'),
    subgroup   VARCHAR,
    value      VARCHAR,
    type       VARCHAR,
    cfg        VARCHAR,
    attr       VARCHAR
);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
