// configenv.js
var crypto = require('crypto');

module.exports = {
    loadEnvVars: function() {
        // add to settings.js:
        //      var configEnv = require('./appdata/config/configenv');
        // then within module
        //      envConfig: configEnv.loadEnvVars(),

        const registrationId = "llidi-base-000";
        const deviceId = "e0000000-0000-0000-0000-00000000000e";

        const deviceHub = "";
        const deviceHubUser = "/ams:"+deviceId+"@lenslogix.io";
        const deviceHubPwdEnc = "41e75b5e08c4e39d11aee13cd9ba96fc"; //ToDo: pass as env arg: process.env.ENV_DEVICEHUB_PWD_ENC

        const key = Buffer.from(process.env.ENV_NODEREDCRED_SECRET); // crypto.createHash('sha256').update(String(process.env.ENV_NODEREDCREDSECRET)).digest('base64').substring(0,32); 
        const iv = Buffer.from(process.env.ENV_NODEREDCRED_IV, 'hex'); // crypto.randomBytes(16);

        //let cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(key), iv);
        //var encrypted = cipher.update(code, 'utf8', 'hex') + cipher.final('hex');

        var decipher = crypto.createDecipheriv("aes-256-cbc", key, iv);
        const deviceHubPwd = decipher.update(deviceHubPwdEnc, 'hex', 'utf8') + decipher.final('utf8');

        process.env.ENV_IOTDEVICEREGISTERID = registrationId;
        process.env.ENV_IOTBUS_SERVER="bus.qa.lenslogix.io";
        process.env.ENV_IOTBUS_PORT = "8883";  
        process.env.ENV_IOTBUS_CLIENTID = deviceId;    
        process.env.ENV_IOTBUS_USER = deviceHubUser;   
        process.env.ENV_IOTBUS_PWD = deviceHubPwd;    

        process.env.ENV_IOTINGRESS_EVENTS = "ams/devices/"+registrationId+"/events/#";
        process.env.ENV_IOTINGRESS_COMMANDS = "ams/devices/"+registrationId+"/commands/#";

        //process.env.ENV_IOTSECUREUSER = deviceHub+".azure-devices.net/"+registrationId+"/?api-version=2021-04-12";   
        process.env.ENV_IOTCERTPATH = "/data/certs/device_iot.cert.pem";     
        process.env.ENV_IOTCERTKEYPATH = "/data/certs/device_iot.key.pem";  
	    
        //const storageaccount = "STORAGEACCOUNTNAME_HERE";
        //
        //process.env.ENV_AZRSTOREACCNAME = storageaccount ; 
        //process.env.ENV_AZRSTOREACCKEY = "ACCKEY_HERE"; or from environment
        //process.env.ENV_AZRSTOREHOST = "https://"+storageaccount+".blob.core.windows.net/"; 
        //process.env.ENV_AZRSTORESASTOKEN = "SAS_TOKEN_HERE"; 
        //process.env.ENV_AZRSTORECONTAINER = "CONTAINERNAME_HERE"; 

       return;
    }
 }