--
-- File generated with SQLiteStudio v3.3.3 on Fri May 5 01:09:07 2023
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: sysparam
CREATE TABLE sysparam (sysparamid INTEGER PRIMARY KEY NOT NULL, created DATETIME NOT NULL DEFAULT (CURRENT_TIMESTAMP), createdby VARCHAR, updated DATETIME, updatedby VARCHAR, name VARCHAR NOT NULL, "group" VARCHAR DEFAULT ('sys'), subgroup VARCHAR, value VARCHAR, type VARCHAR, cfg VARCHAR, attr VARCHAR);

-- Table: transaction
CREATE TABLE "transaction" (transactionid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, created DATETIME DEFAULT (CURRENT_TIMESTAMP), createdby VARCHAR, updated DATETIME, updatedby VARCHAR, transguid VARCHAR NOT NULL, transtype VARCHAR DEFAULT (NULL), transcode VARCHAR, workref VARCHAR NOT NULL DEFAULT (NULL), snapshotref VARCHAR, segmentresponse VARCHAR, location_src VARCHAR, location_dest VARCHAR, sku VARCHAR, upc VARCHAR, qty INTEGER NOT NULL DEFAULT (0), onhand_src INTEGER, onhand_dest INTEGER, lot VARCHAR, serial VARCHAR, expiration DATE, itemdetails VARCHAR, transdetails VARCHAR, processed BOOLEAN DEFAULT NULL, event VARCHAR);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
