--
-- File generated with SQLiteStudio v3.3.3 on Fri May 5 01:07:03 2023
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: inventory
CREATE TABLE inventory (inventoryid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, created DATETIME NOT NULL DEFAULT (CURRENT_TIMESTAMP), createdby VARCHAR, updated DATETIME, updatedby VARCHAR, status VARCHAR, area VARCHAR NOT NULL, location VARCHAR NOT NULL, sku VARCHAR, upc VARCHAR, manufacturer VARCHAR, descriptor VARCHAR, loc_size VARCHAR, qty INTEGER, subqty INTEGER, gtin VARCHAR, expiration DATETIME, serialnumber VARCHAR, lot VARCHAR, mfgdate DATETIME, cfg VARCHAR);

-- Table: scan
CREATE TABLE scan (location VARCHAR PRIMARY KEY UNIQUE, slotstatus BOOLEAN, bcformat VARCHAR, bcscancode VARCHAR, scandata VARCHAR, status VARCHAR, updated DATETIME, synced DATETIME, processed BOOLEAN, invStatus VARCHAR, invUPC VARCHAR, invSerialNumber VARCHAR, invLot VARCHAR, qty INTEGER, expiration DATETIME, gtin VARCHAR, mfgdate DATETIME, invUpdated DATETIME, invUpdatedBy VARCHAR, readDeviceRefNo VARCHAR (50));

-- Table: sysparam
CREATE TABLE sysparam (
    sysparamid INTEGER  PRIMARY KEY
                        NOT NULL,
    created    DATETIME NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
    createdby  VARCHAR,
    updated    DATETIME,
    updatedby  VARCHAR,
    name       VARCHAR  NOT NULL,
    [group]    VARCHAR  DEFAULT ('sys'),
    subgroup   VARCHAR,
    value      VARCHAR,
    type       VARCHAR,
    cfg        VARCHAR,
    attr       VARCHAR
);

-- Table: workqueue
CREATE TABLE workqueue (workqueueid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, created DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, createdby VARCHAR, updated DATETIME, updatedby DATETIME, status VARCHAR NOT NULL DEFAULT 'new', workorderid VARCHAR, workrequestid VARCHAR, requestor VARCHAR (16), destination VARCHAR (16), recipient VARCHAR (16), clientref VARCHAR NOT NULL UNIQUE, request VARCHAR, resultsmessage VARCHAR, details VARCHAR, cfg VARCHAR);

-- Table: workqueueitem
CREATE TABLE workqueueitem (workqueueitemid INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL UNIQUE, workqueueid INTEGER REFERENCES workqueue (workqueueid) ON DELETE CASCADE, created DATETIME NOT NULL DEFAULT (CURRENT_TIMESTAMP), createdby VARCHAR, updated DATETIME, updatedby VARCHAR, status VARCHAR NOT NULL DEFAULT ('scheduled'), priority INTEGER NOT NULL DEFAULT (0), sku VARCHAR, upc VARCHAR, manufacturer VARCHAR, descriptor VARCHAR, qty INTEGER, lot VARCHAR, expiry DATETIME, serialnumber VARCHAR, area VARCHAR, location VARCHAR DEFAULT (NULL), destination VARCHAR DEFAULT (NULL), "action" VARCHAR NOT NULL, cfg VARCHAR, FOREIGN KEY (workqueueid) REFERENCES workqueue (workqueueid) ON UPDATE CASCADE ON DELETE CASCADE);

-- Index: unique_area_location
CREATE UNIQUE INDEX unique_area_location ON inventory (area, location);

-- Index: wqItemId
CREATE UNIQUE INDEX wqItemId ON workqueueitem (workqueueitemid);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
