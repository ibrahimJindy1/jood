## General Notes

If you have installed Node-RED as a global npm package, you can upgrade to the latest version with the following command:

sudo npm install -g --unsafe-perm node-red


https://nodered.org/docs/getting-started/local

Native Node-Red:
(Use this for testing and executing locally)
...from project root... (requires \data sym link):

	node-red -u ./src --settings ./src/.dev-settings.js <<<==== FOR DEVELOPMENT
	
	node-red -u ./src
	node-red -u ./src -p 1888 flows_xyz.json	

Note:

## Node-RED Stack or Compose

	docker compose -f docker-compose.yml -f docker-compose.dev.yml --env-file .sensitive/.env build --no-cache arcos-ams-iotedge
	docker compose -f docker-compose.yml -f docker-compose.dev.yml --env-file .sensitive/.env up -d

	//docker stack deploy node-red --compose-file docker-compose-node-red.yml
	//docker-compose -f docker-compose-node-red.yml -p myNoderedProject up

## Data volume/mount
Create \data sym link to allow native execution and docker to use absolute path - the docker node-red image uses /data for mounting container volume
To create a symbolic link named data from the root directory to the \MyDocs\LLGX\device\llidi-device-runtime\.node-red directory, type:

	mklink /d \data \MyDocs\LLGX\Dev\device\llidi-device-runtime\src

	Note: to remove symlink:  rmdir \data 
	
Docker run:

	docker run -it -p 1880:1880 -v C:\\MyDocs\\LLGX\\Dev\\device\\llidi-device-runtime\\src:/data --name llgxiotedge nodered/node-red
	docker run -it -p 192.168.0.111:1880:1880 -v C:\\MyDocs\\LLGX\\Dev\\device\\llidi-device-runtime\\src:/data --name llgxiotedge nodered/node-red
	docker run -it -p 192.168.0.111:1880:1880 -p 1880:1880 -v C:\\MyDocs\\LLGX\\Dev\\device\\llidi-device-runtime\\src:/data --name llgxiotedge nodered/node-red

https://nodered.org/docs/getting-started/docker

Note: Users migrating from version 0.20 to 1.0 will need to ensure that any existing /data directory 
has the correct ownership. As of 1.0 this needs to be 1000:1000. This can be forced by the 
command sudo chown -R 1000:1000 path/to/your/node-red/data

note: install sqlite on rasperry pi
	sudo apt install sqlite3
	npm install node-red-node-sqlite

set data symlink
	sudo ln -s /home/pi/.node-red/ /data

MISC:

https://www.codenotary.com/blog/reverse-engineer-docker-files-and-visualize-docker-compose-files
docker ps -a

# Identity service
find / -type d -name "[folder_name]"

docker inspect [container_id]


RabbitMQ

    ams/devices/"+registrationId+"/events/heartbeat
	ams/devices/"+registrationId+"/events/pickordercreated
	ams/devices/"+registrationId+"/commands/pickorder

	ams/devices/proto-cabz-000/events/pickordercreated
	ams/devices/proto-cabz-000/commands/pickorder
	
