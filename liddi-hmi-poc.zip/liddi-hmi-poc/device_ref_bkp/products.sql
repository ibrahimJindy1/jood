--
-- File generated with SQLiteStudio v3.3.3 on Sun Aug 28 23:56:57 2022
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: brands
CREATE TABLE brands (brand VARCHAR (24), manufacturer VARCHAR (32), active BOOLEAN DEFAULT (1), countrycode VARCHAR (2), shortname VARCHAR (48), description VARCHAR (96), imageref VARCHAR (255), UNIQUE (brand, countrycode));

-- Table: products
CREATE TABLE products (upc VARCHAR (24), active BOOLEAN DEFAULT (1), sku VARCHAR (24) PRIMARY KEY UNIQUE, material VARCHAR (24), brand VARCHAR (24), descriptor VARCHAR (128), "group" VARCHAR (32), unit_of_measure VARCHAR, qty INTEGER, sub_qty INTEGER, sphere DECIMAL, cylinder DECIMAL, axis INTEGER);

-- Table: sysparam
CREATE TABLE sysparam (
    sysparamid INTEGER  PRIMARY KEY
                        NOT NULL,
    created    DATETIME NOT NULL
                        DEFAULT (CURRENT_TIMESTAMP),
    createdby  VARCHAR,
    updated    DATETIME,
    updatedby  VARCHAR,
    name       VARCHAR  NOT NULL,
    [group]    VARCHAR  DEFAULT ('sys'),
    subgroup   VARCHAR,
    value      VARCHAR,
    type       VARCHAR,
    cfg        VARCHAR,
    attr       VARCHAR
);

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
