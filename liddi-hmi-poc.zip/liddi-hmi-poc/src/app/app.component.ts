import { Component, ElementRef, ViewChildren, ViewEncapsulation, ViewChild } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from "@angular/router";
import { filter, map, mergeMap } from 'rxjs/operators';

import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';

import { EventService, EventServiceMessage } from './services/event.service';
import { WebsocketService } from './services/websocket.service';
import { DeviceMessage } from './models/DeviceMessage';

import { Subscription } from 'rxjs';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  private readonly _eventService: EventService;
  private eventServiceSubscription;
  public componentReference: string = "AppComponent";

  private wsSubscription: Subscription;

  public eventMessage: string;

  public machineState: string = ""
  public navActionEnable: boolean = true;  

  title = 'imshmi';

  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;

  doTimer;

  @ViewChild('drawer') drawer: any;  

  constructor(private router:Router,private activatedRoute:ActivatedRoute, private idle: Idle, private keepalive: Keepalive, eventService: EventService,
    public websocketService: WebsocketService) { 
        this._eventService = eventService;
        this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});

        // sets an idle timeout of 300 seconds
        idle.setIdle(300);         
        // sets a timeout period of 5 seconds. after 5 more seconds of inactivity, the user will be redirected.
        idle.setTimeout(5);
        // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
        idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    
        idle.onIdleEnd.subscribe(() => { 
          //this.idleState = 'No longer idle.'
          //console.log(this.idleState);
          this.reset();
        });
        
        idle.onTimeout.subscribe(() => {
          this.idleState = 'Idle timed out!';
          this.timedOut = true;
          
          if(this.navActionEnable && this.router.url !== '/splashidle') { 
            console.log("idleState: "+this.idleState);
            this.router.navigateByUrl('/splashidle', { state: { splashType:"idler"} }); 
          }
          this.reset();
        });
        
        idle.onIdleStart.subscribe(() => {
          if(this.navActionEnable && this.router.url !== '/splashidle'){
            this.idleState = 'Idle state detected!'

            const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "app-idle-state-start", null, []);
            this.broadcastComponentMessage(message);

            console.log(this.idleState);
          }
        });
        
        idle.onTimeoutWarning.subscribe((countdown) => {
          //this.idleState = 'You will time out in ' + countdown + ' seconds!'
          //console.log(this.idleState);
        });
    
        // sets the ping interval to 15 seconds
        keepalive.interval(15);
    
        keepalive.onPing.subscribe(() => this.lastPing = new Date());
    
        this.reset();
  }

  visible:boolean=false;
  
  ngOnInit(){
    //this.websocketService.openWebSocket();
    this.websocketService.deviceMessageChange.subscribe((m:string) => {this.deviceIncomingMessage(m)});
    this.websocketService.deviceConnectionChange.subscribe((m:string) => {this.deviceConnectionState(m)});

    this.router.events.pipe(
      filter(events=>events instanceof NavigationEnd),
      map(evt =>this.activatedRoute),
      map(route => {
        while(route.firstChild) {
          route = route.firstChild;
        }
        return route;
      }))
      .pipe(
        filter(route => route.outlet === 'primary'),
        mergeMap(route => route.data)
      ).subscribe(x=>x.footer===true ?this.visible=true:this.visible=false);
  }

  ngOnDestroy(): void {
    //unsubscribe/dispose
    this.wsSubscription.unsubscribe();
    this.eventServiceSubscription.unsubscribe();
  }

  deviceIncomingMessage(msg: string){
    //Tell the toolbar component of device alert/incoming message
    console.log("app - deviceIncomingMessage:"+msg);

    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "device-incomingmessage", msg, ['AppToolbarComponent']);
    this.broadcastComponentMessage(message);
  }

  deviceConnectionState(status:string){
    //Tell the toolbar component of device websocket connection state chnage
    console.log("app - deviceConnectionState:"+status);

    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "device-connectionstatus", status, ['AppToolbarComponent']);
    this.broadcastComponentMessage(message);
  }

  deviceSendMessage(dvMsg:DeviceMessage){

    if(!dvMsg.topic && !dvMsg.payload) {dvMsg.topic = "genericHmiEvent"; dvMsg.payload = null;}
    const outMsg = dvMsg;

    this.websocketService.sendMessage(outMsg);
  }
  

  broadcastComponentMessage(message:EventServiceMessage = null): void {   
    //console.log(this.componentReference+' sent Message...', message); 
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      //console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "sidebar-openwithmonitor":
          this.drawerOpenWithMonitor();
          break;
        case "sidebar-closeforced":
          this.drawerClose();
          break;      
        case "device-sendmessage":
          this.deviceSendMessage(message.payload);
          break;   
        case "apptoolbar-heartbeat-relay":
          this.processHeartbeat(message.payload);
          break;                      
      }
    }    
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  //This method exposed to child app-sidenav component
  navigateBySidebar( option:String = null, target:String = null ){
    console.log(this.drawer.opened);
    if(this.drawer.opened) this.drawer.close(); //.toggle();
    //console.log('test',option);    
  }

  drawerOpenWithMonitor(){
    this.drawer.open();

    //close the side bar drawer after elapsed time
    if(this.doTimer) clearTimeout(this.doTimer);
    let that = this;
    this.doTimer = setTimeout(function() { that.drawer.close(); }, 5000);
  }

  drawerClose(){
    this.drawer.close();

    //close the side bar drawer after elapsed time
    if(this.doTimer) clearTimeout(this.doTimer);
  }


  processHeartbeat(hb:any){
    console.log("processHeartbeat...");
    console.log(hb);
    try{
      
      if((hb !== undefined ) && (hb !== null)) {
        this.machineState = hb.machineState.toLowerCase();
        this.navActionEnable = ((this.machineState !== "locate") && (this.machineState !== "locatenoscan"));
      }
    } catch(err){
      console.log(err);
    } 
  }

}
