import { Component, ElementRef, EventEmitter, OnInit, QueryList, ViewChildren, ViewEncapsulation, TemplateRef} from '@angular/core';
import { DeviceApiService } from '../../services/device-api.service';
import {Title} from "@angular/platform-browser";

import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {MatSelectModule} from '@angular/material/select';

import { DeviceMessage } from 'src/app/models/DeviceMessage';

import { FormGroup, FormControl, Validators } from '@angular/forms';

import { NgbModal, NgbModalRef, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import { EventService, EventServiceMessage } from '../../services/event.service';


import { Router } from '@angular/router';

import { InventoryItem, InventoryPickItem } from '../../models/Inventory';
import { HtmlUtils } from '../../shared/html-utils'
import { PickOrder, PickOrderDetail, PickOrderEvent, PickProduct } from 'src/app/models/PickOrder';
import { environment } from 'src/environments/environment';

import * as GS1Parser from 'gs1-barcode-parser-mod';
import { throwError } from 'rxjs';

const ELEMENT_EMPTY: InventoryItem[] = [];

@Component({
  selector: 'app-product-finder',
  templateUrl: './product-finder.component.html',
  styleUrls: ['./product-finder.component.css']
})
export class ProductFinderComponent implements OnInit {
  private readonly _eventService: EventService;
  private eventServiceSubscription;
  public componentReference: string = "ProductFinderComponent";
  
  public eventMessage: string;
  
  public directPickRequest:PickOrder;  //activePickOrder
  public activePickItem: InventoryPickItem;
  public activePickItemPickQty: number = 0;
  public activePickItemReturnQty: number = 0;
  public activeArea:string = "";
  public activeLocation:string = "";

  public pickArea:string = ""; //ToDo - populate on response from API and use if led echo commnad does not set activeArea
  public pickLocation:string = ""; //ToDo - populate on response from API and use if led echo commnad does not set activeLocation

  public itemPickQty = new FormControl({value:'', disabled: false});
  public itemReturnQty = new FormControl({value:'', disabled: false});
  public pickWarningMessage: string = "";

  public lastItemScan: any;
  public lastItemEntry: string;

  public pageMessage: string = "";
  public loading: boolean = true;
  public invMessage: string = "Loading...";
  public errState: boolean = false;
 
  public displayedColumns: string[] = ['manufacturer','brand','descriptor','base_curve','qty','location', 'action'];
  public dataSource: MatTableDataSource<InventoryItem> = new MatTableDataSource<InventoryItem>(ELEMENT_EMPTY);
  //public noData = this.dataSource.connect().pipe(map(data => data.length === 0));

  public filterText = new FormControl({value:'', disabled: false});
  public diopterFilterText = new FormControl('');
 
  public inventoryArray = ELEMENT_EMPTY;
  public inventoryRefreshAllowNext: Date = new Date();
 
  public selectedRowIndex: number = 0;// = "";
  public invalidUPCCount: number = 0;

  public modalRef: NgbModalRef;
  public modalYesNoRef: NgbModalRef;
  public modalRefArray: NgbModalRef[] = [];
  public modalTitle: string;
  public modalMessage: string;
  public modalButtonStyle: string;  
  public modalOkOption: boolean;
  public modalYesNoOption: boolean;
  public modalPinOption: boolean = false;  
  public modalCloseResult: string;
  public modalYesNoCloseResult: string;  

  public itemScan:PickProduct = new PickProduct;

  public pinCaptured: string = "";
  public pinDisplayMasked: boolean = true;
  public pinBackCount: number = 0;

  public forceManualMode: boolean = false;

  public noBarcodeEnable: boolean = false;

  public modalShowErrorMsg: boolean = false;
  public errorMsg: string = "";

  public mfgList = []; //[{"name":"J&J"},{"name":"Alcon"},{"name":"B&L"}];
  public brandMasterList = []; //[{"mfg":"J&J", "name":"Acuvue"},{"mfg":"Alcon", "name":"Air Optix®"},{"mfg":"B&L", "name":"Biotrue ONEday"}];
  public brandList = [];
  public sphere2List = ["*", 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  public sphere3Full = ["*",".00", ".25", ".50", ".75"];
  public sphere3Half = ["*",".00", ".50"];
  public sphere3List = [];
  public sphere3Option = "Full";
  public cylList = ["*", "-0.75", "-1.25", "-1.75", "-2.25", "-2.75"];
  public axisList = ["*", "010", "020", "030", "040", "050", "060", "070", "080", "090", 100, 110, 120, 130, 140, 150, 160, 170, 180];

  public mfgSelected = "";
  public brandSelected = "";;
  public sphere1Selected = false; //true = "+", false ="-"
  public sphere2Selected;
  public sphere3Selected;
  public cylSelected;
  public axisSelected;

  public filterState: boolean = false;
  public permitReload: boolean = false;

  public hasPending: boolean = false;
  public machineState: string = "";
  public searchControlsEnable: boolean = false;
  public pickActionEnable: boolean = false;  

  //public mfgSelector = new FormControl({value:'', disabled: false});  

  public mfgBrandGroup = new FormGroup({
    mfgSelector: new FormControl(),
    brandSelector: new FormControl(),
 });

 public mfgBrandGroup2 = new FormGroup({
  sphere2Selector: new FormControl(),
  sphere3Selector: new FormControl(),  
});

  /*
- Sphere – multiple dropdowns (x2 and radio option)
  range: +8.00 to -12.00 
    +8.00 to +6.50 in 0.50 diopter steps  
    +6.00 to -6.00 in 0.25 diopter steps
    -6.50 to -12.00 in 0.50 diopter steps
    
    -12.00 ------- -6.50 --- 0 --- +6.50 --- +8.00
    [    .50      ][         0.25        ][ .50  ]

    List all for [2] , filter [3] based on [2] see range
      Radio values:
      [1] +   -
    Dropdown values:
      [2] 0  1  2  3   4  5  6  7   8   9   10    11    12
      [3] .00  .25  .50 .75      

- Cyl - dropdown
  range:   -0.75 to -2.75  in 0.5 diopter steps
  List all options always
    Dropdown values:                          
    [1] -0.75 -1.25 -1.75 -2.25 -2.75

- Axis - dropdown
  range:   0 to 180 in 10 degree steps
  List all options always
  Dropdown values:
    [1] 0 10  20  30  40  50  60  70  80  90  100 110 120 130 140 150 160 170 180
*/

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChildren('input') inputs: QueryList<ElementRef>;
  @ViewChild("workrequestmodal") workrequestmodal: TemplateRef<any>;
  @ViewChild("workrequestconfirmmodal") workrequestconfirmmodal: TemplateRef<any>;
  @ViewChild("workrequestyesnomodal") workrequestyesnomodal: TemplateRef<any>;

  constructor(public router: Router, public restApi: DeviceApiService, private modalService: NgbModal, public htmlUtils: HtmlUtils, eventService: EventService) { 
    this._eventService = eventService;
    this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});

   }
   
  ngOnInit(): void {

    this.htmlUtils = new HtmlUtils;
    this.dataSource.paginator = this.paginator;
    this.searchControlsEnable = false;

    //get inventory list
    console.log("init");
    this.loadInventory();
    this.clearSearch();
    this.loadHmiConfig(); 
    this.requestHeartbeat();
  }

  ngOnDestroy(): void {
    //unsubscribe/dispose
    this.eventServiceSubscription.unsubscribe();
  }

  ngAfterViewInit() {
    //Note: ngAfterViewInit fires on init but there may not be a data source ready/loaded
    this.configDatasource();
  }

  clearSearch(){

    this.mfgSelected = "";
    this.mfgBrandGroup.get('mfgSelector').setValue('');
   
    this.setBrandList("",""); //also clears brandSelected

    this.sphere1Selected = false; //true = "+", false ="-"
    //this.sphere2Selected = this.sphere2List[0];
    this.sphere2Selected = this.sphere2List[0];

    this.setSphere3List(); //also sets sphere3Selected

    this.cylSelected = this.cylList[0];
    this.axisSelected = this.axisList[0];
    console.log("clearSearch Called");

    this.filterState = false;
    //this.setFilter(false);
    this.setFilter();

    //this.activeArea = "0";
    //this.activeLocation = "0";    
  }

  onMfgSelected(e){
    this.mfgSelected = e.value;
    this.setBrandList(e.value,"*");
    console.log("onMfgSelected Called");
    this.setFilter();
  }

  onBrandSelected(e){
    //this.setBrandList(e.value);
    this.brandSelected = e.value;
    console.log("onBrandSelected Called");
    this.setFilter();
  }

  setBrandList(mfgFilter:string="", brandFilter:string=""){
    let brandlist;
    
    if(mfgFilter == ""){
      //set brandlist with no mfg filter
      brandlist = [...this.brandMasterList]
      //this.brandSelected = "";
    } else {
      brandlist = this.brandMasterList.filter((b)=> {
        return b.mfg == mfgFilter;
      });      
      //this.brandList[0].name;      
    }
    //console.log(this.brandSelected);
    let curBrandSelected = this.brandSelected;
    this.brandList = brandlist;
    
    if(brandFilter == ""){
      curBrandSelected = "";
    } else {
      let brd = brandlist.filter((b) => {return b.name === curBrandSelected});

      if(brd.length === 0) curBrandSelected = "";      
      if(brandlist && brandlist.length === 1) curBrandSelected = brandlist[0].name;  
    }
    
    this.brandSelected = curBrandSelected;  
    this.mfgBrandGroup.get('brandSelector').setValue(curBrandSelected);    
  }

  onSphere1Selected(e){
    //filter brands 
    //console.log(e);
    console.log("onSphere1Selected Called");
    this.setFilter();
  }

  onSphere2Selected(e){
    //filter brands 
    console.log(e);

    if(e < 7 || e === "*"){
      this.setSphere3List("Full");
    } else {
      this.setSphere3List("Half");
    }
    console.log("onSphere2Selected Called");
    this.setFilter();
  }

  onSphere3Selected(e){
    console.log("onSphere3Selected Called");
    this.setFilter();
  }

  onCylSelected(e){
    console.log("onCylSelected Called");
    this.setFilter();
  }

  onAxisSelected(e){
    console.log("onAxisSelected Called");
    this.setFilter();
  }

  setSphere3List(clearOption:string=""){
    var lastOption = this.sphere3Option;

    if(clearOption == "" || clearOption == "Full"){
      //display all/full otpions 
      this.sphere3List = [...this.sphere3Full];
      this.sphere3Option = "Full";
    } else {     
      //display half otpions 
      this.sphere3List = [...this.sphere3Half];
      this.sphere3Option = "Half";
    }

    if(!this.sphere3List.includes(this.sphere3Selected) || (clearOption == "")){
      //if the previous select item is no longer in the list then seect first item
      this.sphere3Selected = this.sphere3List[0]; //set to first item on list - the wildcard
    }
  }

  configDatasource(){
    if(this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;   
    }
    console.log("configDatasource...");

    this.dataSource.filterPredicate = (data, filter) => {
      const dataStr = data; 
      //console.log("filter..."+filter);      
      // Note:  filtering considers various field - using the filter string to detect a change on multiple fields.  
      //        when the fitler predicate is called all filterable fileds are checked.

      let filterval = filter.split('|:|'); //filter grouped in string: mfg|:|brand|:|descriptor[regex]
      //filterval[0] = mfg change
      //filterval[1] = brand change
      //filterval[2] = descriptor change

      // any-all:  |:||:|-****  |:||:|+****   *|:||:|-****   |:|*|:|-****   *|:|*|:|-****

      let filterMatch = false; //on filter reset

      /*
      //if there are no filtering fields set, then keep the row/record object
      if((filterval.length < 3 ) || ((filterval.length >= 3) 
        && (filterval[0].length <= 1) && (filterval[1].length <= 1) 
        && (filterval[2].length <= 1 || (filterval[2].includes("****"))))) {          
          filterMatch = true;
      }    
      */
     
      if(!filterMatch) {
        // the filter variable contains search criteria
        // let's apply the filter to the row/record object

        //determine mfg: filtering 
        let mfgFilterOn = (filterval[0].length > 1);
        let mfgFilterMatch; 
        if(mfgFilterOn) mfgFilterMatch = (dataStr.manufacturer.includes(filterval[0])); 
        
        //determine brand: filtering 
        let brandFilterOn = (filterval[1].length > 1);
        let brandFilterMatch;
        if(brandFilterOn) brandFilterMatch = (dataStr.brand === filterval[1]); 
        //if(brandFilterOn) brandFilterMatch = (dataStr.brand.includes(filterval[1])); 

        //determine descriptor: filtering
        let descriptorFilterOn = true; //!filterval[2].includes("****") && !this.clearShowAll;
        let descriptorFilterMatch = false;
        if(descriptorFilterOn){
          /*   
          regex pattern - for reference:       
            any/all                     : /^(\+|\-)\d\.\d{0,2}\sx\s(\+|\-)\d\.\d{0,2}\sx\s\d{0,3}/gm
            any (+ or -) matching sphere: /^(\+|\-)\d\.\d{0,2}[\w\W]/gm
            any (+ only) matching sphere: /^(\+)\d\.\d{0,2}[\w\W]/gm

            ToDo: for ADD adjust need suffix like [\w\W]*
          */
          let reg_exp_str = "";

          let sph1 = (this.sphere1Selected)?"^(\\+)":"^(\\-)"; 
          let sph2 = (this.sphere2Selected === "*")?"\\d{1,2}":"["+this.sphere2Selected.toString().split("").join("][")+"]";
          let sph3 = (this.sphere3Selected === "*")?"\.\\d{0,2}":this.sphere3Selected;     
          
          if((this.sphere2Selected === "*") && (this.sphere3Selected === "*")){
            //sph1 = "^(\\+|\\-)";
          }

          let cylAxis;

          if((this.cylSelected !== "*") || (this.axisSelected !== "*")){
          //determine cyl: filtering
          let cyl = "\\sx\\s"+((this.cylSelected === "*")?"(\\+|\\-)\\d\\.\\d{0,2}":this.cylSelected);
          
          //determine axis: filtering
          let axis = "\\sx\\s"+((this.axisSelected === "*")?"d{0,3}":this.axisSelected);
          
          cylAxis =cyl+axis;

          } else cylAxis = "[\\w\\W]*";

          reg_exp_str = sph1+sph2+sph3+cylAxis;  

          let regX = new RegExp(reg_exp_str, 'gm'); 
          let dts = dataStr.descriptor.toString();
          let results = regX.exec(dts);
          descriptorFilterMatch = (results !== null);

          console.log(reg_exp_str);
          console.log(results);
        }
        return ((!mfgFilterOn || mfgFilterOn && mfgFilterMatch) && (!brandFilterOn || brandFilterOn && brandFilterMatch) && (!descriptorFilterOn || descriptorFilterOn && descriptorFilterMatch) );

      }
      else return (filterMatch);
      
    } 
  }


  setFilter(apply:boolean = true){
    //set the (regex) filter for descriptor
    console.log(this.filterState);
    console.log("setFilter");
    if(apply) {this.filterState = true};

    //determine mfg: filtering
    var mfg = this.mfgSelected;
    if(mfg && mfg.trim().length<=1) mfg = "*";

    //determine brand: filtering
    var brand = this.brandSelected;
    if(brand && brand.trim().length<=1) brand = "*";

    let sep = "|:|";
    let filterValue = mfg + sep + brand + sep;

    //determine sphere: filtering 
    let sph1 = (this.sphere1Selected)?"+":"-"; 
    let sph2 = this.sphere2Selected;
    let sph3 = this.sphere3Selected;

    //determine cyl: filtering
    let cyl = this.cylSelected;
    
    //determine axis: filtering
    let axis = this.axisSelected;

    filterValue+=sph1+sph2+sph3+cyl+axis;

    //console.log(filterValue); 
    if(!apply) filterValue = "*"+sep+"*"+sep+"*";
    this.dataSource.filter = filterValue; //setting/changing the filterValue will execute the filter predicate for the dataSource

    if (this.dataSource.paginator) {
      //this.dataSource.paginator.firstPage();    
    }
  }

  test(){
  /*
  console.log(this.dataSource.filter);
    let rex  = "(\\-)0.\\d{0,2}[\\w\\W]";
    
    let rex2 = "(\\+)0."+"\\d{0,2}[\\w\\W]";
    
    let re = new RegExp(rex, 'gm'); 
    let re2 = new RegExp(rex2, 'gm'); 

    let array1 = re.exec("-0.25 x -1.25 x 110");
    console.log(rex);
    console.log(array1);
    let array2 = re2.exec("-2.25 x -1.25 x 110");
    console.log(rex2);
    console.log(array2);   
    */

    console.log(this.mfgSelected);
    console.log(this.brandSelected);
    console.log(this.sphere1Selected); 
    console.log(this.sphere2Selected);
    console.log(this.sphere3Selected);
    console.log(this.cylSelected);
    console.log(this.axisSelected);

    this.setFilter();
  }
  
  loadInventory(){
    this.dataSource = new MatTableDataSource(ELEMENT_EMPTY);
   
    this.errState = false;
    this.loading = true;
  
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.invMessage = "Sorry, something is not quite right.";}
      }, 6000);

    this.restApi.getInventory().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.invMessage = "";
      
      console.log(data);

      let wrdata = data as {topic:string, payload:any};

      let inv_full= wrdata.payload.messageData;

      that.inventoryArray = inv_full.filter((inv) => (inv.status === "available"));

      that.dataSource = new MatTableDataSource(that.inventoryArray);

      that.setMfgBrandFilterFromInventory();
      this.setBrandList(this.mfgSelected,"*");

      //ngAfterViewInit not firing - safe call here instead
      that.configDatasource();
      that.setFilter();

    });     
  }

  setMfgBrandFilterFromInventory(){
    let inv = this.inventoryArray;

   // public mfgList = []; //[{"name":"J&J"},{"name":"Alcon"},{"name":"B&L"}];
   // public brandMasterList = []; //[{"mfg":"J&J", "name":"Acuvue"},{"mfg":"Alcon", "name":"Air Optix®"},{"mfg":"B&L", "name":"Biotrue ONEday"}];

    let brands = inv.filter(function (a) {
      var key = a.manufacturer + '|' + a.brand;
      if (!this[key]) {
        this[key] = true;
        return true;
      }
    }, Object.create(null)).map(a => ({"mfg":a.manufacturer,"name":a.brand}));
    
    this.brandMasterList = brands;
  
    let mfgs = brands.filter(function (a) {
      var key = a.mfg;
      if (!this[key]) {
        this[key] = true;
        return true;
      }
    }, Object.create(null)).map(a => ({"name":a.mfg}));

    this.mfgList = mfgs;

  }
  
  locateInventory(item:InventoryItem){
    //s0: start pick - activate work request (direct pick --> workrequestid = 0)
    this.directPickRequest = new PickOrder;
    this.directPickRequest.mode = "directPick";
    this.directPickRequest.workrequestid = 0;

    this.directPickRequest.request = {"area":item.area,"location":item.location};

    this.errState = false;
    this.loading = true;

    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        //that.pageMessage = "Sorry, something is not quite right.";
      }
    }, 6000);

    this.restApi.putWorkRequest(this.directPickRequest.workrequestid, this.directPickRequest.mode, this.directPickRequest.request ).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      //that.pageMessage = "";
  
      let wrdata = data as {topic:string, payload:any};
      
      //Note: 
      //device will echo led commnad to notify UI of location that 
      //is staged/highlighted (see workrequestitems-locationledcmd call setActiveItem())
      //however let's show action buttons

      that.pickArea = item.area;
      that.pickLocation = item.location;

      if(wrdata.payload.messageData?.request?.area) {
        this.hasPending = true;
        console.log('activateWorkRequest --> wrdata: ',wrdata);

        this.setActiveItem(that.pickArea+"|"+that.pickLocation+"|on");  //call setActiveItem with formatted pseudo payload
      }
    }); 

  }

  pickRowItem(row:InventoryItem) {
    //s0-1: start prick process
    if(this.machineState !== "ready") return;

    console.log('PICK: Row clicked: ', row); //, ' this.lastMState:', this.lastMState);
    
    this.permitReload = false; //prevent reload on pick request - device sends refresh on pick request
    //this.selectedRowIndex = row.location;

    //this.activeArea = row.area;
    //this.activeLocation = row.location;

    //this.selectedRowIndex = this.dataSource.data.findIndex((obj => ((obj.area === this.activeArea)&&(obj.location === this.activeLocation))));

    this.locateInventory(row);
  }

  refresh(){
      //on second/successive clicks clear/reload form  
      let refreshNow = Date.now();
      var diff = this.inventoryRefreshAllowNext.getTime() - refreshNow;
  
      if(diff < 0) {
        this.inventoryRefreshAllowNext = new Date(Date.now() + 1500);
        
        //get invenotry
        this.loadInventory();
      }
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      //console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "workrequestitems-locationledcmd":
          if((this.activeLocation === "") || !message.payload.includes(this.activeLocation)) this.setActiveItem(message.payload);
          break;
        case "workrequest-endlocate":
          this.endLocate();
          break;          
        case "workrequestitems-refresh":
          //this.loadWorkRequestDetails();
          if(this.permitReload) {
            this.loadInventory();
          }
          this.permitReload = true;
          console.log("workrequestitems-refresh--- now what?");
          break;
        case "app-keyinput":
          //console.log("product-finder received key:"+message.payload);
          console.log("product-finder received key");
          this.processKeyedInput(message.payload); 
          break;            
        case "app-enteredinput":
          //this.navigateHome();
          if(message.payload.length > 1){
            console.log("received entered input (scanner):"+message.payload);
            this.processScannedInput(message.payload, "scanner");     
          }       
          break; 
        case "apptoolbar-heartbeat-relay":
        case "apptoolbar-heartbeat-lastest":
          this.processHeartbeat(message.payload);
          break;  
        case "hmi-config-relay":
          this.processHmiConfig(message.payload);
          break;                           
      }
    }    
  }  

endLocate(clear:boolean = true){
  this.activeArea ="";
  this.activeLocation = "";

  this.pickArea = "";
  this.pickLocation = "";

  this.hasPending = false;

  if(clear){
    this.loadInventory();
    //this.clearSearch();
  }
}

broadcastComponentMessage(message:EventServiceMessage = null): void {   
  //console.log(this.componentReference+' sent Message...', message); 
  let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
  this._eventService.broadcastMessage(msgx);
}

processHeartbeat(hb:any){
  console.log("processHeartbeat...");
  console.log(hb);
  try{
    
    if((hb !== undefined ) && (hb !== null)) {
      this.machineState = hb.machineState.toLowerCase();
      this.searchControlsEnable = (hb.machineState === "ready");
      
      if(!this.searchControlsEnable) {
        this.mfgBrandGroup.disable();
      }else{
        this.mfgBrandGroup.enable();
      }

      this.pickActionEnable = (hb.machineState === "ready");
      
      if(hb.machineState === "ready" && this.hasPending ){
        this.endLocate(false);
      }

      //close any modals if opened - manual entry modal, etc.
      this.modalManager("msgClose", "", "");
    }
  } catch(err){
    console.log(err);
  } 
}

loadHmiConfig(){
  //leverage incoming hmi config and broadcast to other components
  const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "hmi-config-send", null, ['AppToolbarComponent']);
  this.broadcastComponentMessage(message);  
  console.log(this.componentReference + " loadHmiConfig called -- hmi-config-send");  
}

requestHeartbeat(){
  //leverage incoming heartbeat
  const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "send-heartbeat-latest", null, ['AppToolbarComponent']);
  this.broadcastComponentMessage(message);  
  console.log(this.componentReference + " requestHeartbeat called -- send-heartbeat-latest");  
}

processHmiConfig(cfg:any){    
  try{
    if((cfg !== undefined ) && (cfg !== null)) {
      this.noBarcodeEnable = cfg.payload.directPick.options.noBarcodeEnable || false;
      }
  } catch(err){
    console.log(err);
  }  
} 

reportScannedItem(workrequestid, scanneditem, qty, area, location, gs1data){
  //s1: report the scanned item on the back end
  this.errState = false;
  this.loading = true;
  let that = this;    

  setTimeout(function(){
    if (that.loading) {
      //that.loading = false; 
      that.errState = true;
      that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
    }, 6000);

  this.restApi.putWorkRequestItemScanned(workrequestid, scanneditem, qty, area, location, gs1data).subscribe((data: {}) => {    
    that.loading = false;
    that.errState = false;
    that.pageMessage = "";

    let wrdata = data as {topic:string, payload:any};

    //that.pickOrderDetailArray = wrdata.payload.messageData;
  });
}

scannedItemConfirmed(writem:InventoryPickItem){
  //s8: send the confirmed item (s7) to the back end - to create produce and data transactions
  this.errState = false;
  this.loading = true;
  let that = this;    
  
  console.log("scannedItemConfirmed");
  console.log(writem);

  setTimeout(function(){
    if (that.loading) {
      //that.loading = false; 
      that.errState = true;
      that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
    }, 6000);

  this.restApi.putWorkRequestScannedItem(writem).subscribe((data: {}) => {    
    that.loading = false;
    that.errState = false;
    that.pageMessage = "";

    let wrdata = data as {topic:string, payload:any};
    
    that.clearUIStagedItem();   
    //that.pickOrderDetailArray = wrdata.payload.messageData;  

  });
}

setActiveItem(data:any) {
  //s2: upon sending staged item to backend (s1:put), the item's location is commanded to light up, the led command 
  //is echoed via the web socket connection and processed here so that the corresponding row is highlighted on the UI
  let ledcmd = data.split("|");

  if(ledcmd.length > 1) {
    this.activeArea = ledcmd[0];
    this.activeLocation = ledcmd[1];

    let ledAction = ledcmd[2] || "on" ;

    //let targetStatus = "pending";
    //if(this.activePickOrder.mode === "expired") targetStatus = "expired";

    this.selectedRowIndex = this.dataSource.data.findIndex((obj => ((obj.area === this.activeArea)&&(obj.location === this.activeLocation))));
    if(!this.hasPending && ledAction === "on") this.hasPending = true;

    if(!(this.selectedRowIndex === -1) && ledAction === "on"){
      let invitem =  this.dataSource.data[this.selectedRowIndex]; 
      this.activePickItem =  <InventoryPickItem>invitem;
      /*{  inventoryid: 0,
        status:invitem.status,
        area:invitem.area,
        location:invitem.location,
        upc:invitem.upc,
        expiration:invitem.expiration,
        lot:invitem.lot,
        serialnumber:invitem.serialnumber,
        qty:invitem.qty,
        subqty: invitem.subqty,
        gtin:invitem.gtin,
        mfgdate:invitem.mfgdate,
        manufacturer:invitem.manufacturer,
        descriptor:invitem.descriptor,
        brand:invitem.brand,
      
        wrd_index_id:0,
        workqueueitemid:0,
        workrequestid:0,
      
        qtymax: invitem.subqty,
        qtypick: 0,
        qtyrtn: 0}; 
        */
      this.activePickItem.qtymax = (this.activePickItem.qty>this.activePickItem.subqty)?this.activePickItem.qty:this.activePickItem.subqty;
      this.activePickItem.wrd_index_id = 0;
      this.activePickItem.workqueueitemid = 0;
      this.activePickItem.workrequestid = 0;

      console.log("targetUPC: "+this.activePickItem.upc);
      console.log("activePickItem: ",this.activePickItem);
      
      this.itemPickQty.setValue(this.activePickItem.qtymax);
      this.itemReturnQty.setValue(0);
      this.pickWarningMessage = "";
    } else {
      this.activeArea = "";
      this.activeLocation = "";

      this.hasPending = false;
    
      console.log("Item (location) not in pick order detail.");
      this.loadInventory();
    }  
  }
}

userSlotEmpty(){
  //open the slot empty confirm dialogue
  //console.log("userSlotEmpty clicked.");
  this.modalManager("msgAction", "userSlotEmpty", "");
}

userNoBarcode(){
  //open the no barcode confirm dialogue
  //console.log("userSlotEmpty clicked.");
  this.modalManager("msgAction", "userNoBarcode", "");
}

confirmedSlotEmpty(eventCode = "userSlotEmpty", area=this.activeArea, location=this.activeLocation){  

      //send the confirmed item to the back end - to create produce and data transactions to empty the invenotry for the slot 
      this.errState = false;
      this.loading = true;
      let that = this;  
      
      that.hasPending = false;
    
      setTimeout(function(){
        if (that.loading) {
          //that.loading = false; 
          that.errState = true;
          that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
        }, 6000);

      let invref = {area:area, location:location, eventCode:eventCode, mode:"directPick"};
  
      this.restApi.putInventorySlotEmpty(invref).subscribe((data: {}) => {    
        that.loading = false;
        that.errState = false;
        that.pageMessage = "";
    
        let invdata = data as {topic:string, payload:any};  

        that.clearUIStagedItem();        
        //that.pickOrderDetailArray = wrdata.payload.messageData; 
      });

}

confirmedNoBarcode(eventCode = "userNoBarcode", area=this.activeArea, location=this.activeLocation){    

  //send the confirmed item to the back end - to create produce and data transactions to empty the invenotry for the slot 
  this.errState = false;
  this.loading = true;
  let that = this;  
  
  that.hasPending = false;

  setTimeout(function(){
    if (that.loading) {
      //that.loading = false; 
      that.errState = true;
      that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
    }, 6000);

  let invref = {area:area, location:location, eventCode:eventCode, mode:"directPick"};

  this.restApi.putInventoryNoBarcode(invref).subscribe((data: {}) => {    
    that.loading = false;
    that.errState = false;
    that.pageMessage = "";

    let invdata = data as {topic:string, payload:any};  

    that.clearUIStagedItem();        
    //that.pickOrderDetailArray = wrdata.payload.messageData; 
  });

}

clearUIStagedItem(){
  this.activeArea = "";
  this.activeLocation = "";

  this.activePickItem = null;  

  this.hasPending = false;

  this.lastItemScan = null;
  this.lastItemEntry = null;
  
  //close any modals if opened - manual entry modal
  this.modalManager("msgClose", "", "");

}

userManualEntry(){
  //open the upc manual entry dialogue
  console.log("userManualEntry clicked.");
  
  this.pinCaptured = ""; //clear the captured text

  //FOR TESTING
  //this.pinCaptured = "63017550699";

  this.modalManager("msgAction", "userManualEntry", "");
}

processKeyedInput(key:string){
//Using the single key(ed) input for demo/testing
//  let simscan = null;
//
//  if(this.activePickItem && this.activePickItem.upc)
//    simscan = "00888290026487112203301727030110V002X3301B";//this.activePickItem.upc;      
//
////  switch(key){
//    case "G":
//    case "g":  
//    case "A":
//    case "a":
//      //simulate a good scan from scanner          
//      if(simscan){
//        simscan = "01"+simscan;
//        console.log("processKeyedInput (emulate GOOD scan):"+simscan);
//        this.processScannedInput(simscan, "scanner"); 
//      }              
//      break;
//    case "E":
//    case "e":          
//      //simulate a good scan from scanner - but expired  
//      if(simscan){
//        simscan = "00888290026487112203301321030110V002X3301B"
//        simscan = "01"+simscan;        ;
//        console.log("processKeyedInput (emulate BAD scan):"+simscan);
//        this.processScannedInput(simscan, "scanner");           
//      } 
//      break;       
//   case "B":
//   case "b":          
//   case "Z":
//   case "z":
//     //simulate a bad scan from scanner  
//     if(simscan){
//       simscan = "01"+simscan;
//       simscan = simscan.slice(0, -1) + '0';
//       console.log("processKeyedInput (emulate BAD scan):"+simscan);
//       this.processScannedInput(simscan, "scanner");           
//     } 
//     break;  
//   case "M":
//   case "m":
//   case "X":
//   case "x":
//     //simulate manual entry (partial)        
//     if(simscan){
//       simscan = simscan.slice(0, -1);
//       console.log("processKeyedInput (emulate partial manual entry):"+simscan);
//       this.pinCaptured = simscan;          
//     } 
//     break;     
//   case "R":
//   case "r":
//     //reset the demo inventory and workrequests
//     simscan = "-"; //prevents warning message
//     console.log("processKeyedInput (emulate DEMO Reset)");
//     let demoMsg:DeviceMessage = new DeviceMessage("Reset", {prodEnv:environment.production});
//     
//     this.restApi.postDemoAction(demoMsg).subscribe((response: {}) => {    
//       console.log(response);
//     });        
//     break;  
//   case "Y":
//   case "y":
//   case "N":
//   case "n":
//     //simulate LLISA response on resolution request
//     //yes = in stock found
//     //no  = out of stock
//     simscan = "-"; //prevents warning message
//     
//     let option = true; //for yes
//     if(key == "n" || key =="N") option = false;
//     
//     console.log("processKeyedInput (emulate LLISA "+(option?"YES":"NO")+" Response)");
//     let demoMsgNo:DeviceMessage = new DeviceMessage("LLISAReply", {prodEnv:environment.production, LLISAReply:option});
//     
//     this.restApi.postDemoAction(demoMsgNo).subscribe((response: {}) => {    
//       console.log(response);
//     });        
//     break;                                    
//    default:
//      break;
//  }

//  if(!simscan) console.log("processKeyedInput - warning: no active item/upc to emulate scan.");

}

processScannedInput(scan:string, mode:string = "scanner"){
  //s3: when an item is scanned (or manually keyed) and upon pressing (or sensing) 
  //the "Enter" key, the code is processed for match
  //
  //let's check if the scanned information is valid GS1 data, 
  //if keyed manually, the entry and target upc need to macth
  //if GS1 code is scanned then AI code 01 data upc value and target upc need to macth

  //mode:
  //  scanner- a GS1 string from barcode scanner
  //  manual - likely upc only, entered via keyboard/modal-keypad

  let scanGS1:any = null;
  let validUPC:boolean = false;
  let result:any = null;
  //let upc:string = "";
 
  //for testing:
  //if(mode !== "manual") {
  //  //scan = "01195011015300031714070410AB-123"; //bad scan
  //  scan = "01095011015300031723022810AB-123";   //good matching scan
  //  console.log("testing..." + scan);      
  //}

  this.lastItemScan = null;
  this.lastItemEntry = null;

  this.forceManualMode = false;

  this.itemScan = new PickProduct;

  if(mode === "scanner" && scan.length > 1){
    try{
      scanGS1 = GS1Parser.parseBarcode(scan);
      console.log(scanGS1);
      //console.log(this.activePickItem);      

      //tell the device service/api of the scanned item - staged - data event
      if(this.activePickItem !== undefined && this.activePickItem !== null) {
        this.reportScannedItem(this.activePickItem.workrequestid, scan, this.activePickItem.qty, this.activeArea, this.activeLocation, scanGS1); 
      } else {
        this.reportScannedItem(0, scan, 0, this.activeArea, this.activeLocation, scanGS1); 
      }
    }catch(err){
      console.log(err);
      let msgerr = "";
      if(typeof err.replace === 'function'){
        msgerr = err.replace(/\'/g,""); //ToDo: temp fix - need solution on server side - SQLite issue with message containing single quotes
      } else {
        if(err.message && (typeof err.message.replace === 'function')){
          msgerr = err.message.replace(/\'/g,"");
        } else {
          msgerr = "processScannedInput - unknown error.";
        }
      }
      
      //tell the device service/api of the scanned item/error - staged - for auditing - data event
      if(this.activePickItem !== undefined && this.activePickItem !== null) {
        this.reportScannedItem(this.activePickItem.workrequestid, scan, this.activePickItem.qty, this.activeArea, this.activeLocation, msgerr); 
      } else {
        this.reportScannedItem(0, scan, 0, this.activeArea, this.activeLocation, msgerr); 
      }

    }

    if(scanGS1 && (this.activePickItem !== undefined && this.activePickItem !== null)) {
      if(scanGS1.parsedCodeItems){    

        result = scanGS1.parsedCodeItems.find(obj => {
          return obj.ai === '01'
        });

        if(result && result.data) {
          this.itemScan.upc = result.data;
          if(result) validUPC = true;
          
          this.lastItemScan = scanGS1;            
        }
        
       //if(result.data) {
       //  upc = result.data;
       //  if(result) validUPC = true;
       //  this.lastItemScan = scanGS1;            
       //}
      }  
    } else {
      this.forceManualMode = true;
      console.log("bad 2-D scan or 1-D scan for upc.");

      //ensure scan is set to max 14 digits padded with leading 0's
      scan = scan.padStart(14, '0');
    }

  } else {
    //assume manual entry
    // the manual input is only checked if enough charcaters entered for upc --> 11+
    if(scan.length >= 11) {
      this.itemScan.upc = scan;
      validUPC = true;  
      this.lastItemEntry = scan;  
    }
  }

  if(this.forceManualMode || mode !== "scanner") {      

    console.log("assume manual entry.");    
    //assume manual entry
    // the manual input is only checked if enough charcaters entered for upc --> 11+
    if(scan.length >= 12) {
      this.forceManualMode = true;

      this.itemScan.upc = scan;
      validUPC = (scan !== '00000000000000');  
      this.lastItemEntry = scan;  
          
      this.itemScan.expiration = null;
      this.itemScan.serialnumber = null;
      this.itemScan.lot = null;
      this.itemScan.mfgdate = null;
    }
  }   
  
  console.log(this.itemScan);

  if(validUPC) {
    //let's check if the valid upc is the matching upc to allow qty confirmation
    if(this.checkUPCMatch(this.itemScan.upc)) {
      //if matched, then request user to confirm upc qty's (pick/return)
      //show ui to confirm quantities picked/returned
      //
      
      //if(this.directPickRequest.mode === "directPick"){
      //  //for expired the entire item will removed - no need to confirm
        this.activePickItem.qtypick = this.activePickItem.qtymax;
        this.activePickItem.qtyrtn = 0;
        this.activePickItem.status = "completed";
      //
      //  //send the confirmed item to the back end - to create produce and data transactions
      //  this.scannedItemConfirmed(this.activePickItem);
      //} else {
        //normal/direcPick mode
        this.upcQtyConfirm();
      //}

    } else {
      //scanned/entered upc mismatch
      if(mode === "scanner"){
        //close any modals if opened - manual entry modal
        this.modalManager("msgClose", "", "");

        if(this.activeArea !== "" && this.activeLocation !== ""){
          //LLIDI Displays "Item Mismatch - Confirm Lens picked from [location]]"
          this.upcMismatchConfirmPick();
        } else {
          this.nothingStagedToPick();
        }
        
      } else {
        //manually entered via pin modal
        //manual entry modal is (assumed already) open - check this.modalRef
        this.upcMismatchErrorLabel("showErr");
        if(this.invalidUPCCount >= 3){

          //LLIDI Displays "Item Unreadable"
          //Technician Selects the “OK” Button and puts unreadable product in trash
          //Assume user pricked from correct slot - remove item from inventory

          this.upcUnreadableConfirmPick();            

          //test: this.modalYesNoManager("msgAction", "GenericOK", "ItemEntryTooManyAttempts - ToDo: Ask User to place in trash / Call BE to Empty Slot /");
        }
      }

    }
  } else {

    if(mode === "scanner") {
      //close any modals if opened - manual entry modal
      this.modalManager("msgClose", "", "");
      if(this.activePickItem === undefined || this.activePickItem === null)
        this.nothingStagedToPick();
      else
        this.modalYesNoManager("msgAction", "InvalidUPC", "");
    }
    
    console.log("invalid upc.");
  }
}


checkUPCMatch(upcEntry:string):boolean{
  //s4: check the entered/scanned upc macthes the expected target upc

  let match:boolean;   

  this.modalShowErrorMsg = false;
  this.errorMsg = ""

  if(upcEntry && (upcEntry === this.activePickItem.upc)) {
    console.log("upc MATCH! "+upcEntry);
   
    match = true;
    this.invalidUPCCount = 0;

  }
  else {
    match = false;      
    this.invalidUPCCount+=1;

    if(this.invalidUPCCount >= 3) 
    {
      this.invalidUPCCount = 3;        
    }  
    console.log("upc MIS-match! count:"+this.invalidUPCCount+" scan:"+upcEntry +" Expected:"+ this.activePickItem.upc);
  }

  return match;
}

upcUnreadableConfirmPick(){
  //After entering the upc manually wrong 3 times - instruct to dispose of item
  this.modalManager("msgClose", "", ""); // close the manual entry form
  this.modalYesNoManager("msgAction", "ItemUpcUnreadable", "");
}

upcUnreadableConfirmed(option:string){
  //After entering the upc manually wrong 3 times and confirming dispose - then empty the slot
  this.confirmedSlotEmpty("itemUnreadable");
}

upcMismatchConfirmPick(){
  //LLIDI Displays "Item Mismatch - Confirm Lens picked from [location]]" (Yes/No - Static) = ItemScanMismatch
  this.modalYesNoManager("msgAction", "ItemScanMismatch", "");
  
  //ToDo: timeout 10 seconds then assume YES/YES
}

nothingStagedToPick(){
  //LLIDI Displays "Nothing to Pick - Warning"
  this.modalYesNoManager("msgAction", "NothingToPick", "");
  
  //ToDo: timeout 10 seconds then assume YES/YES
}

upcMismatchConfirmed(option:string){
  if(option == "Yes"){
    //On YES: LLIDI Displays "Place Item in Restock Bin" - user picked from the active slot but invenotry is not correct - clear slot invenotyr data
    this.modalManager("msgAction", "placeItemOnRestock", "");

  } else {
    //On NO : LLIDI Displays Message "Return Picked Lens to Previous Slot" - user picked from another slot try again
    this.modalManager("msgAction", "returnPickedLens", "");

  }
} 

upcMismatchConfirmedPost(option:string){
  if(option == "Yes"){
    //On YES: LLIDI Displays "Place Item in Restock Bin" - user picked from the active slot but invenotry is not correct - clear slot invenotyr data
    //THEN: Clear the slot inventory (and generate transactions : itemMisplaced)
    this.confirmedSlotEmpty("itemMisplaced");

  } else {
    //On NO : LLIDI Displays Message "Return Picked Lens to Previous Slot" - user picked from another slot try again
    //THEN: generate data transaction : itemPickIncorrect (note: location may be inferred if item scan 
    //      had a serial number or IF it is the ONLY item (upc) that exists in inventory)

    let pickItemEvent:PickOrderEvent = {
      workrequest:this.directPickRequest, 
      workrequestitems:[this.activePickItem], 
      eventCode:"itemPickIncorrect", 
      eventData:{scan:this.lastItemScan, entry:this.lastItemEntry}
    };

    this.sendWorkRequestEvent(pickItemEvent);
  }
  
  //ToDo: clear timeout (from upcMismatchConfirmPick) after assuming YES
} 

sendWorkRequestEvent(dataItem:PickOrderEvent){
  //send request to generate event/data transaction record
  this.errState = false;
  this.loading = true;
  let that = this;    

  setTimeout(function(){
    if (that.loading) {
      //that.loading = false; 
      that.errState = true;
      that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
    }, 6000);

  this.restApi.putWorkRequestEvent(dataItem).subscribe((data: {}) => {    
    that.loading = false;
    that.errState = false;
    that.pageMessage = "";

    let wrdata = data as {topic:string, payload:any};

    //that.pickOrderDetailArray = wrdata.payload.messageData;  

  });
}

upcMismatchErrorLabel(option:string = "showErr"){
  if(option === "showErr") {
    this.modalShowErrorMsg = true;
    this.errorMsg = "Incorrect UPC entered"+((this.invalidUPCCount>1)?' (x'+this.invalidUPCCount+')':'');
  } else {
    this.modalShowErrorMsg = false;
    this.errorMsg = "";
  }
}

upcQtyConfirm(){
  //s5: display confirm modal to obtain user pick and return quantities for scanned upc
  this.modalTitle = "Scanned Item:";
  
  this.activePickItemPickQty = this.activePickItem.qtymax;
  this.activePickItemReturnQty = 0;

  //console.log("this.activePickItem.qtymax:this.activePickItem.qty   "+this.activePickItem.qtymax + ":"+this.activePickItem.qty);

  //close any prior modal dialogues
  if(this.modalRef) this.modalRef.close();

  //reset the invalid count
  this.invalidUPCCount = 0;

  this.modalRef = this.modalService.open(this.workrequestconfirmmodal, { centered:true, size:'lg', backdrop:'static' }); //

}

adjustConfirmQty(group:string = "pick", action:string){
  //s6: adjust quantities during confirm stage

  if(group == "return") {
    if(action == "sub") {
      this.activePickItemReturnQty-= 1;
    } else {
      //assumes return:add action
      this.activePickItemReturnQty+= 1;
    }
  } else {
    //assumes pick group
    //only allow to pick at max onhand or no less than 1
    //if(!(this.activePickItemPickQty < 2 || this.activePickItemPickQty === this.activePickItem.qtymax)){
      if(action == "sub") { 
        if((this.activePickItemPickQty > 1) && (this.activePickItemPickQty <= this.activePickItem.qtymax)){
          if(this.activePickItemPickQty > 0) this.activePickItemReturnQty+= 1;
          this.activePickItemPickQty-= 1;          
        }       

      } else {
        //assumes pick:add action
        if((this.activePickItemPickQty > 0) && (this.activePickItemPickQty < this.activePickItem.qtymax)){
          this.activePickItemPickQty+= 1;
          this.activePickItemReturnQty-= 1;          
        }
      }      
    //}
  }

  if(this.activePickItemPickQty <= 0) this.activePickItemPickQty = 0;
  if(this.activePickItemReturnQty <= 0) this.activePickItemReturnQty = 0;

  this.itemPickQty.setValue(this.activePickItemPickQty);
  this.itemReturnQty.setValue(this.activePickItemReturnQty);

  //if(this.activePickItemPickQty < this.activePickItem.qty)
  //  this.pickWarningMessage = "Quantity picked is less than ordered";
  //else if(this.activePickItemPickQty > this.activePickItem.qty)
  //  this.pickWarningMessage = "Quantity picked is more than ordered";
  //else
  //  this.pickWarningMessage = "";
}

upcInfoConfirmed(){
  //s7: user confirmed pick and return qty's from confirm modal
  //close modal and continue to next step
  if(this.modalRef) this.modalRef.close();  

  this.activePickItem.qtypick = this.activePickItemPickQty;
  this.activePickItem.qtyrtn = this.activePickItemReturnQty;
  this.activePickItem.qtyclear = 0;
  this.activePickItem.status = "completed";

  //if(this.activePickItem.qtypick < this.activePickItem.qty) {
  //  this.lastPickItemGap = new PickOrderDetail;
  //
  //  this.lastPickItemGap.area = this.activePickItem.area;
  //  this.lastPickItemGap.descriptor = this.activePickItem.descriptor;
  //  this.lastPickItemGap.location = this.activePickItem.location;
  //  this.lastPickItemGap.manufacturer = this.activePickItem.manufacturer;
  //  this.lastPickItemGap.qty = (this.activePickItem.qty - this.activePickItem.qtypick); //if user accepts will create detail record with remaining quantity
  //  this.lastPickItemGap.upc = this.activePickItem.upc;
  //  this.lastPickItemGap.workrequestid = this.activePickItem.workrequestid;
  //
  //  this.modalManager("msgStatic", "notOrderedQty", "");
  //} 
  
  //send the confirmed item to the back end - to create produce and data transactions
  this.scannedItemConfirmed(this.activePickItem);

}

pinCode(pin:string){
  switch(pin){
    case "Enter":
      this.pinSubmit();
      break;
    case "Back":
      this.pinBackCount+=1;
      this.modalShowErrorMsg = false;
      if(this.pinBackCount>5) {
        this.pinCaptured = "";
        this.pinBackCount = 0;
      }
      if(this.pinCaptured.length > 0) this.pinCaptured = this.pinCaptured.slice(0, -1);
      break;
    default:
      if(this.pinCaptured.length < 14)
      {
        this.pinCaptured+= pin;

        this.pinBackCount = 0;
      }
      break;
  }
  
}

pinSubmit(){
  var pinCapturedScannedUPC = this.pinCaptured.padStart(14, '0');
    
  this.processScannedInput(pinCapturedScannedUPC, "manual");
}

modalManager(action = "default", option, msg) {
  let openModal = true;
  
  this.modalButtonStyle = "normal";
  this.modalOkOption = true;
  this.modalYesNoOption = !this.modalOkOption;
  this.modalPinOption = false;

  if(option !== "userManualEntryOnError"){
    //clear for all others
    this.modalShowErrorMsg = false;
    this.errorMsg = "";      
  }

  //close any prior modal dialogues
  if(this.modalRef) this.modalRef.close();
  if(action === "msgClose") return;

  //console.log("option: ", option);
  switch(option){
    case "userSlotEmpty":
        this.modalTitle = "Slot Empty";
        this.modalMessage = "Press OK to confirm slot is empty.";   
        this.pinCaptured = "";  
        this.modalOkOption = true; 
        this.modalYesNoOption = false;   
      break;
    case "userNoBarcode":
        this.modalTitle = "No Barcode";
        this.modalMessage = "Confirm the requested lens is picked, if incorrect place in restock bin.";   
        this.pinCaptured = "";  
        this.modalOkOption = true; 
        this.modalYesNoOption = false;   
      break;
    case "notOrderedQty":
        this.modalOkOption = false;
        this.modalYesNoOption = true;
        this.modalTitle = "Quantity OK?";
        this.modalMessage = "Will picked lenses meet doctor's requirements?";   
        this.pinCaptured = "";    
      break;        
    case "userManualEntry":
    case "userManualEntryOnError":        
      this.modalOkOption = false;
      this.modalYesNoOption = false;
      this.modalPinOption = true;
      this.pinDisplayMasked = false;
      this.modalTitle = "Manual Entry";
      this.modalMessage = "Enter UPC:";         
      break; 
    case "tooManyScanAttempt":
      this.modalTitle = "Proceed";
      this.modalMessage = msg;   
      this.pinCaptured = "";  
      this.modalOkOption = true;
      this.modalYesNoOption = false;
      break;
    case "returnPickedLens":
      this.modalTitle = "Return Lens";
      this.modalMessage = "Return picked lens to previous slot";   
      this.modalOkOption = true;
      this.modalYesNoOption = false; 
      break;
    case "placeItemOnRestock":
      this.modalTitle = "Move to Restock";
      this.modalMessage = "Place item in Restock bin";   
      this.modalOkOption = true;
      this.modalYesNoOption = false;  
      break;            
    case "GenericOK":
      this.modalTitle = "Proceed";
      this.modalMessage = msg;   
      this.pinCaptured = "";  
      this.modalOkOption = true;
      this.modalYesNoOption = false;  
      console.log("GenericOK");    
      break;      
    default:
      openModal = false; //no valid option - prevent open
      break;
  }

  if(openModal) {
    let that = this;

    const modalOptions: Record<string, any> = {
      centered: true,
    };
    
    if(action == "msgStatic") modalOptions.backdrop = 'static' 
    //modalOptions.keyboard = false; //closable by hitting the ESC key if true

    this.modalRef = this.modalService.open(this.workrequestmodal, modalOptions);   
    this.modalRefArray.push(this.modalRef);

    this.modalRef.result.then((result) => {
      this.modalCloseResult = `Closed with: ${result}`;
      //Ok/Continue or Yes/No
      if(result) {
        switch(this.modalTitle){
          case "Slot Empty":
            this.confirmedSlotEmpty();
            break;
          case "No Barcode":
            this.confirmedNoBarcode();
            break;            
          //case "Quantity OK?":
          //  this.notOrderedQtyConfirmed(result);
          //  break;
          case "Move to Restock":
            this.upcMismatchConfirmedPost("Yes");
            break;               
          case "Return Lens":
            this.upcMismatchConfirmedPost("No");
            break;                                  
            
        }
        console.log("modalCloseResult:", result);        
      }
    }, (reason) => {
      this.modalCloseResult = `Dismissed ${this.getDismissReason(reason)}`;
      
      console.log("modalCloseResult:", this.modalCloseResult);
    
    });
  }
} 
//
private getDismissReason(reason: any): string {    
  if (reason === ModalDismissReasons.ESC) {
    return 'by pressing ESC';
  } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    return 'by clicking on backdrop';
  } else {
    return  `with: ${reason}`;
  }
}  
//
modalYesNoHandler(option:string){
  if(this.modalYesNoRef) this.modalYesNoRef.close();

  console.log("modalYesNoHandler with "+option+" for "+this.modalTitle);

  switch(this.modalTitle) {
    case "Quantity OK?":
      //this.notOrderedQtyConfirmed(option);
    break;
  case "Scanned Item Mismatch":
      this.upcMismatchConfirmed(option);
    break; 
  case "UPC Unreadable":
      this.upcUnreadableConfirmed(option);
    break; 
  }
}

modalYesNoManager(action, option, msg) {
  let openModal = true;
  
  this.modalButtonStyle = "normal";
  this.modalOkOption = false; //default to Yes/No option

  //close any prior modal dialogues
  if(this.modalYesNoRef) this.modalYesNoRef.close();

  //console.log("option: ", option);
  switch(option){
    case "QtyMismatchGapOk":
        this.modalTitle = "Request Complete";
        this.modalMessage = "The itme will be marked completed.  No new order";  
        this.modalOkOption = true;
        this.modalYesNoOption = false;           
      break; 
    case "QtyMismatchGapNewOrder":
        this.modalTitle = "Request Complete with New Order";
        this.modalMessage = "The item will be marked completed.  A new order will be generated.";   
        this.modalOkOption = true;
        this.modalYesNoOption = false;          
      break;      
    case "ItemScanMismatch":
        this.modalTitle = "Scanned Item Mismatch";
        this.modalMessage = "Confirm Lens picked from " + this.activeArea + "-" + this.activeLocation; 
        this.modalOkOption = false;
        this.modalYesNoOption = true;              
      break;  
    case "NothingToPick":
        this.modalTitle = "Nothing To Pick";
        this.modalMessage = "Please select an item to pick or choose restock to add items"; 
        this.modalOkOption = true;
        this.modalYesNoOption = false;              
      break;        
    case "InvalidUPC":
        this.modalTitle = "UPC Invalid";
        this.modalMessage = "The UPC entered/scanned is invalid.  Please try again."; 
        this.modalOkOption = true;
        this.modalYesNoOption = false;              
      break; 
    case "ItemUpcUnreadable":
        this.modalTitle = "UPC Unreadable";
        this.modalMessage = "The UPC is marked unreadable please discard."; 
        this.modalOkOption = true;
        this.modalYesNoOption = false;              
      break;                  
    case "UnavailableDetect":
        this.modalTitle = "Searching Inventory...";
        this.modalMessage = "Please wait while we check other units…"; 
        this.modalOkOption = true;
        this.modalYesNoOption = false;  
        //this.requestItemResolution();
        console.log("UnavailableDetect - NO ACTION!");
      break;                       
    case "GenericOK":
        this.modalTitle = "Continue...";
        this.modalMessage = msg;   
        this.pinCaptured = "";  
        this.modalOkOption = true;
        console.log("GenericOK-YesNo" + openModal);
      break;
    default:
      openModal = false; //no valid option
      break;
  }

  if(openModal) {
    let that = this;

    this.modalYesNoRef = this.modalService.open(this.workrequestyesnomodal, { centered:true, backdrop:'static' }); // 
    this.modalRefArray.push(this.modalYesNoRef);

    this.modalYesNoRef.result.then((result) => {
      this.modalYesNoCloseResult = `Closed with: ${result}`;
      //Yes/No
      if(result) {
        console.log("modalYesNoCloseResult:", result);        
      }
    }, (reason) => {
      this.modalYesNoCloseResult = `Dismissed ${this.getDismissReason(reason)}`;        
      console.log("modalYesNoCloseResult:", this.modalYesNoCloseResult);      
    });
  }    
}  
}
