import { Component, ElementRef, OnInit, QueryList, ViewChildren } from '@angular/core';
import { DeviceApiService } from "../../services/device-api.service";
import { Router} from '@angular/router';

import {ViewChild, TemplateRef} from '@angular/core';
import { HtmlUtils } from '../../shared/html-utils'

import { NgbModal, NgbModalRef, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import { EventService, EventServiceMessage } from '../../services/event.service';
import { environment } from 'src/environments/environment';

import * as GS1Parser from 'gs1-barcode-parser-mod';
import { FormControl, FormGroup } from '@angular/forms';
import { DeviceMessage } from 'src/app/models/DeviceMessage';

import { PutItemDetail, StockProduct, StorageLocation } from '../../models/PutItem';
import { ThisReceiver } from '@angular/compiler';


import * as _moment from 'moment';
import { MatDatepicker } from '@angular/material/datepicker';
import { Moment} from 'moment';

const moment = _moment;

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/YYYY',
  },
  display: {
    dateInput: 'MM/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-restock',
  templateUrl: './restock.component.html',
  styleUrls: ['./restock.component.css']
})
export class RestockComponent implements OnInit {
  private readonly _eventService: EventService;
  private eventServiceSubscription: any;
  public componentReference: string = "RestockComponent";

  public eventMessage: string;

  public deviceFull:boolean = true;

  public targetUPCProduct: PutItemDetail;

  public activePutItem: StockProduct;
  public activePutStorage: StorageLocation;
  public activePutItemQty: number =0;
  public activeArea: string;
  public activeLocation: string;  

  public lastItemScan: any;
  public lastItemEntry: string;  

  public pageMessage: string = "";
  public errState: boolean = false;
  public loading: boolean = false;

  public invalidUPCCount: number = 0;  
  public pinCodeOK: boolean = false;

  public modalRef: NgbModalRef;
  public modalYesNoRef: NgbModalRef;
  public modalRefArray: NgbModalRef[] = [];
  public modalTitle: string;
  public modalMessage: string;
  public modalButtonStyle: string;  
  public modalOkOption: boolean;
  public modalYesNoOption: boolean;
  public modalPinOption: boolean = false;  
  public modalCloseResult: string;
  public modalYesNoCloseResult: string;
  
  public itemScan:StockProduct = new StockProduct;

  public pinCaptured: string = "";
  public pinDisplayMasked: boolean = false;
  public pinBackCount: number = 0;  

  public forceManualMode: boolean = false;
  public allowConfirm: boolean= true;
  public manualExpiryStyle: string = "exp-date-list";

  public manualExpiryYear: number;
  public expiryYearList: number[];
  public manualExpiryMonth: number;
  public expiryMonthList: number[];  

  public modalShowErrorMsg: boolean = false;
  public errorMsg: string = "";  

  public activePutItemPutQty = new FormControl({value:'', disabled: false});  

  //public expdate = new FormControl({value:moment(), disabled: true});
  public expMinDate:Date = new Date(); 
  public expMaxDate:Date = new Date();

  public myGroup:FormGroup;
  public datepickerref:MatDatepicker<Moment>;

  @ViewChild("workrequestmodal") workrequestmodal: TemplateRef<any>;
  @ViewChild("restockconfirmmodal") restockconfirmmodal: TemplateRef<any>;
  @ViewChild("workrequestyesnomodal") workrequestyesnomodal: TemplateRef<any>;

  @ViewChildren('input') inputs: QueryList<ElementRef>;

  constructor(public router: Router, public restApi: DeviceApiService, private modalService: NgbModal, public htmlUtils: HtmlUtils, eventService: EventService) { 
    this._eventService =  eventService;
    this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});
   
    const navigation = this.router.getCurrentNavigation(); }

  ngOnInit(): void {
    this.loading = true;
    this.requestHeatbeat(); //let's check if device full (call chain --> updateRestockDisplay)

    this.expMaxDate.setFullYear(this.expMinDate.getFullYear() + 15);
    this.expMinDate.setFullYear(this.expMinDate.getFullYear());
    
    this.myGroup = new FormGroup({
      expdate: new FormControl({value:moment(), disabled: true}) //this.expdate
   });
  }

  ngOnDestroy(): void {    
    
    //unsubscribe/dispose
    this.eventServiceSubscription.unsubscribe();
  }

  broadcastComponentMessage(message:EventServiceMessage = null): void {   
    //console.log(this.componentReference+' sent Message...', message); 
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      //console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "app-idle-state-start":
          //close any/all modals
          this.closeModals();
          break;
        case "apptoolbar-heartbeat-relay":
          this.updateRestockDisplay(message.payload);
          break;          
        case "workrequest-endlocate":
          this.navigateHome();
          break;
        case "app-keyinput":
          console.log("restock received key:"+message.payload);
          this.processKeyedInput(message.payload); 
          break;            
        case "app-enteredinput":
          //this.navigateHome();
          console.log(message);
          if(message.payload.length > 1){
            console.log("received entered input (scanner):"+message.payload);
            this.processScannedInput(message.payload, "scanner");     
          }       
          break;          
      }
    }    
  } 
  
  setMonthAndYear(normalizedMonthAndYear: Moment, datepicker: MatDatepicker<Moment>) {
    var mymoment = moment(normalizedMonthAndYear, 'YYYY-MM-DD');

    this.manualExpiryMonth = mymoment.month()+1;
    this.manualExpiryYear = mymoment.year();

    this.manualExpiryChange();
    
    datepicker.close();
    this.datepickerref = datepicker;
  }

  setDatepickerReference($event:Event, obj:MatDatepicker<Moment>){
    this.datepickerref = obj;
  }

  navigateHome(){
    this.closeModals();
    this.router.navigateByUrl("/home");
  }


  navigateBack(){
    this.navigateHome();
  }  


  closeModals(){
    //ToDO: Static Modals may require default option to be auto accepted
    console.log(this.datepickerref);

    if(this.datepickerref) this.datepickerref.close();

    this.modalManager("msgAction", "Close", "");
    this.modalYesNoManager("msgAction", "Close", "");

    if(this.modalRef) this.modalRef.close();
    
    
  }  
  

  requestHeatbeat(){
    //Tell the app toolbar to (send) the system heartbeat.
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "send-heartbeat-now", null, ['AppToolbarComponent']);
    this.broadcastComponentMessage(message);
  }


  updateRestockDisplay(hbPayload:any){
    var msgdata = hbPayload;
    //console.log(msgdata);

    this.loading = false; //asumes no modals open and last call was to get hearbeat
    this.errorMsg = "";
    
    var occupiedCount = (msgdata.occupiedCount || msgdata.occupiedCount == 0) ? msgdata.occupiedCount : -1;
    var capacity = (msgdata.capacity || msgdata.capacity == 0) ? msgdata.capacity : -1;

    this.deviceFull = (occupiedCount >= capacity);

    if(this.deviceFull) {
      this.errorMsg = "No Empty Slots Available";
    }
    
    //close any prior modal dialogues if status is ready
    if(msgdata.machineState == "ready") {
      this.clearStagedItem(); //also close any open modals
    }
  }


  processKeyedInput(key:string){
    //Using the single key(ed) input for demo/testing
  
  //  let simscan = "00888290026487112203301721030110V002X3301B"; //valid item scan  
  //
  //  switch(key){
  //    case "G":
  //      case "g":  
  //      case "A":
  //      case "a":
  //        //simulate a good scan from scanner          
  //        if(simscan){
  //          simscan = "01"+simscan;
  //          console.log("processKeyedInput (emulate GOOD scan):"+simscan);
  //          this.processScannedInput(simscan, "scanner"); 
  //        }              
  //        break;
  //      case "E":
  //      case "e":          
  //        //simulate a good scan from scanner - but expired  
  //        if(simscan){
  //          simscan = "00888290026487112203301321030110V002X3301B"; //no exp date
  //          simscan = "00888290026487112203301721030110V002X3301B"; //expired date
  //          simscan = "01"+simscan;        ;
  //          console.log("processKeyedInput (emulate EXPIRED scan):"+simscan);
  //          this.processScannedInput(simscan, "scanner");           
  //        } 
  //        break;       
  //    case "G":
  //    case "g":  
  //    case "A":
  //    case "a":
  //      //simulate a good scan from scanner
  //      console.log("processKeyedInput (emulate GOOD scan):"+simscan);          
  //      if(simscan){    
  //        this.processScannedInput(simscan, "scanner"); 
  //      }              
  //      break;
  //    case "B":
  //    case "b":          
  //    case "Z":
  //    case "z":
  //      //simulate a bad scan from scanner  
  //      if(simscan){
  //        simscan = "00"+simscan + simscan.slice(2);
  //        console.log("processKeyedInput (emulate BAD scan):"+simscan);
  //        this.processScannedInput(simscan, "scanner");           
  //      } 
  //      break;  
  //    case "M":
  //    case "m":
  //    case "X":
  //    case "x":
  //      //simulate manual entry (partial)        
  //      if(simscan){
  //        simscan = simscan.slice(0, -1);
  //        console.log("processKeyedInput (emulate partial manual entry):"+simscan);
  //        this.pinCaptured = simscan;          
  //      } 
  //      break;     
  //    case "R":
  //    case "r":
  //      //reset the demo inventory and workrequests
  //      simscan = "-"; //prevents warning message
  //      console.log("processKeyedInput (emulate DEMO Reset)");
  //      let demoMsg:DeviceMessage = new DeviceMessage("Reset", {prodEnv:environment.production});
  //      
  //      this.restApi.postDemoAction(demoMsg).subscribe((response: {}) => {    
  //        console.log(response);
  //      });        
  //      break;  
  //    case "Y":
  //    case "y":
  //    case "N":
  //    case "n":
  //      //simulate LLISA response on resolution request
  //      //yes = in stock found
  //      //no  = out of stock
  //      simscan = "-"; //prevents warning message
  //      
  //      let option = true; //for yes
  //      if(key == "n" || key =="N") option = false;
  //      
  //      console.log("processKeyedInput (emulate LLISA "+(option?"YES":"NO")+" Response)");
  //      let demoMsgNo:DeviceMessage = new DeviceMessage("LLISAReply", {prodEnv:environment.production, LLISAReply:option});
  //      
  //      this.restApi.postDemoAction(demoMsgNo).subscribe((response: {}) => {    
  //        console.log(response);
  //      });        
  //      break;                                    
  //    default:
  //      break;
  //  }
  
  // if(!simscan) console.log("processKeyedInput - warning: no active item/upc to emulate scan.");
  }


  processScannedInput(scan:string, mode:string = "scanner"){
    //s1: when an item is scanned (or manually keyed) and upon pressing (or sesning) 
    //the "Enter" key, the code is processed for find product info and location to stock
    //
    //let's check if the scanned information is valid GS1 data, 
    //if keyed manually, the entry needs to be a valid upc
    //if GS1 code is scanned then AI code 01 data needs to be a valid upc
  
    //mode:
    //  scanner- a GS1 string from barcode scanner
    //  manual - likely upc only, entered via keyboard/modal-keypad

    let scanGS1:any = null;
    let validUPC:boolean = false;
    let result:any = null;

    this.lastItemScan = null;
    this.lastItemEntry = null;

    let expired: boolean = true;
    let expiration:number = 0;

    this.forceManualMode = false;

    if(this.deviceFull) return;

    this.itemScan = new StockProduct;

    if(mode === "scanner" && scan.length > 1){
      try{
        scanGS1 = GS1Parser.parseBarcode(scan);
        console.log(scanGS1);

        //tell the device service/api of the scanned item - staged - data event
        //this.stageScannedItem(this.activePutItem.workrequestid, scan, this.activePutItem.qty, this.activeArea, this.activeLocation, scanGS1); 
      }catch(err){
        console.log(err);
        let msgerr = "";
        if(typeof err.replace === 'function'){
          msgerr = err.replace(/\'/g,""); //ToDo: temp fix - need solution on server side - SQLite issue with message containing single quotes
        } else {
          if(err.message && (typeof err.message.replace === 'function')){
            msgerr = err.message.replace(/\'/g,"");
          } else {
            msgerr = "processScannedInput - unknown error.";
          }
        }
        //tell the device service/api of the scanned item/error - staged - for auditing - data event
        //this.stageScannedItem(this.activePutItem.workrequestid, scan, this.activePutItem.qty, this.activeArea, this.activeLocation, msgerr);        
      }

      if(scanGS1) {
        if(scanGS1.parsedCodeItems){    
          //gtin/upc (01)
          result = scanGS1.parsedCodeItems.find(obj => {
            return obj.ai === '01'
          });

          if(result && result.data) {
            this.itemScan.upc = result.data;
            if(result) validUPC = true;
            
            this.lastItemScan = scanGS1;            
          }

          scanGS1.parsedCodeItems.forEach(codeItem => {
            switch(codeItem.ai){
              case "17": //expiration     (17)
                this.itemScan.expiration = codeItem.data;
                //check expiration   
                try{
                  let expscan:Date = new Date(codeItem.data);
                  console.log(expscan);
                  expiration = expscan.getTime();
                  expired = ( expiration <  Date.now());                           
                  //throw new Error("This is the error message");        
                }catch {
                  expired = true;
                  expiration = new Date("01/01/1900").getTime();
                }
                break;
              case "21": //serial number  (21)
                this.itemScan.serialnumber = codeItem.data;
                break;
              case "10": //lot/batch      (10)
                this.itemScan.lot = codeItem.data;
                break;   
              case "11": //mfgdate        (11)
                this.itemScan.mfgdate = codeItem.data;
                break;                                         
            }
          });

        }  
      } else {
        this.forceManualMode = true;
        console.log("bad scan or 1-D scan for upc.");
        
      } 

    } 
    
    if(this.forceManualMode || mode !== "scanner") {      

      console.log("assume manual entry.");    
      //assume manual entry
      // the manual input is only checked if enough charcaters entered for upc --> 11+
      if(scan.length >= 12) {
        this.forceManualMode = true;

        this.itemScan.upc = scan;
        validUPC = (scan !== '00000000000000');  
        this.lastItemEntry = scan;  

        expired = false;

        var tmpdatebase = new Date(); // Now
        this.manualExpiryYear = tmpdatebase.getFullYear();
        this.expiryYearList = Array.from([0, 1, 2, 3, 4, 5, 6], x => x + this.manualExpiryYear);

        this.manualExpiryMonth = tmpdatebase.getMonth()+1;
        this.expiryMonthList = Array.from([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12], x => x);
             
        this.manualExpiryChange();  //call to set ui and itemScan.expiration

        this.itemScan.serialnumber = null;
        this.itemScan.lot = null;
        this.itemScan.mfgdate = null;
      }
    }   
    
    console.log(this.itemScan);

    if(validUPC) {
      console.log("upc valid!  expired:"+expired);
      if(expired){
        this.itemExpiredConfirm();
      } else {
        this.itemProcessContinue();
      }
    } else {
      if(mode === "scanner") {
        //close any modals if opened - manual entry modal
        //this.modalManager("msgClose", "", "");
        //this.modalYesNoManager("msgAction", "InvalidUPC", "");

        this.upcProductBad();
      }

      console.log("invalid upc.");
    }
  }

  itemProcessContinue(){
    console.log("itemProcessContinue... called.");
    this.upcMismatchErrorLabel("clearErr");
    this.setProductByUpcForRestock(this.itemScan);    
  }

  itemExpiredConfirm(){
    //s1a: the scanned item is expired - confirm to continue
    //open modal
    this.modalYesNoManager("msgAction", "ItemExpiredConfirmContinue", "");
  }

  itemExpiredContinue(option:boolean = false){
    //if yes (true)
    if(option){
        this.itemProcessContinue();
    }
    //otherwise nothing - close modals
  }

  manualExpiryChange(){  
    var tmpdate = new Date(this.manualExpiryYear, this.manualExpiryMonth-1, 1); 
    var tmpdatenow = new Date(); // Now

    var diff = (tmpdate.getTime() - tmpdatenow.getTime())/ (1000 * 60 * 60 * 24); //days

    if(diff >= 30) {
      this.allowConfirm = true;
      this.manualExpiryStyle = "exp-date-list-ok";
    } else {
      this.allowConfirm = false;      
      this.manualExpiryStyle = "exp-date-list";
    }

    this.itemScan.expiration = tmpdate;
    if(this.activePutItem) this.activePutItem.expiration = tmpdate; //sync active put/staged item expiration

    console.log("Diff:" + diff);
    console.log(tmpdate);    
  }
 
  clearStagedItem(){
    console.log("clearStagedItem");

    this.pinCaptured = "";

    this.activeArea = "";
    this.activeLocation = "";
  
    this.activePutItem = null;  
   
    this.lastItemScan = null;
    this.lastItemEntry = null;

    //this.activePutItem = new StockProduct;
    this.activePutStorage = new StorageLocation;
    this.activePutItemQty = 0;
    
    this.closeModals(); // close the confirm entry form  
  }

  processStockItem(restockItem:StockProduct, restockStorage:StorageLocation){

    console.log(restockItem);
    console.log(restockStorage);

    if(restockItem){
      if(restockStorage ){
        this.invalidUPCCount = 0;
        this.activePutItem = restockItem;
        this.activePutStorage = restockStorage;
        this.activePutItemQty = restockItem.sub_qty;

        this.activeArea = restockStorage.area;
        this.activeLocation = restockStorage.location;

        this.activePutItemPutQty.setValue(this.activePutItemQty);

        if(this.forceManualMode) {
          this.allowConfirm = false;  
        } else {
          this.allowConfirm = true;  
        }
              
        this.upcQtyConfirm();
      } 
      else {

        this.modalManager("msgAction", "noUpcCapacityAvailable", "");
      }
    }else {
        this.modalManager("msgAction", "productNotRecognized", "");
    }

  }


  upcProductBad(upcEntry:string = ""){
    //s3-b: determine if invalid 3 times           
    this.invalidUPCCount+=1;

    if(this.invalidUPCCount >= 3) 
    {
      this.invalidUPCCount = 3;
      this.modalManager("msgAction", "tooManyScanAttempt", "");  
      this.upcMismatchErrorLabel("clearErr");           
    } else {
      this.upcMismatchErrorLabel("showErr");
    }
    
    console.log("upc MIS-match! count:"+this.invalidUPCCount+" scan:"+upcEntry);    
  }


  upcMismatchErrorLabel(option:string = "showErr"){
    if(option === "showErr") {
      this.modalShowErrorMsg = true;
      this.errorMsg = "Incorrect UPC entered"+((this.invalidUPCCount>1)?' (x'+this.invalidUPCCount+')':'');
    } else {
      this.modalShowErrorMsg = false;
      this.errorMsg = "";
    }
  }  


  setProductByUpcForRestock(itemStock: StockProduct, getstocklocation:boolean = true){
    //s2: send the scanned item to the back end - to determine if it is a valid item
    this.errState = false;
    this.loading = true;
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        that.loading = false; 
        that.errState = true;
        that.errorMsg = "Sorry, something is not quite right.  Scan item not set.";
        that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
      }, 6000);

    this.restApi.putProductToRestock(itemStock, getstocklocation).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
      that.errorMsg = "";
  
      let itemdata = data as {topic:string, payload:any};
      let stockitem = itemdata.payload.messageData.stockItem as StockProduct;
      let storage = itemdata.payload.messageData.storage as StorageLocation;

      console.log(itemdata.payload);

      if(Object.keys(itemdata.payload).length === 0){
        //check if object empty (when no match)
        console.log("getProductByUpc: bad upc object");
        this.upcProductBad();
      } else {
        //object not empty -- proceed   
        //check if product can be stocked     
        that.processStockItem(stockitem, storage);
      }
    });
  }


  upcQtyConfirm(){
    //s4: display confirm modal to obtain user stock quantities for scanned upc
    this.modalTitle = "Confirm Restock";
    
    //this.activePutItemPutQty = this.targetUPCProduct.qty;

    //console.log("this.activePickItem.qtymax:this.activePickItem.qty   "+this.activePickItem.qtymax + ":"+this.activePickItem.qty);

    //close any prior modal dialogues
    if(this.modalRef) this.modalRef.close();

    //reset the invalid count
    this.invalidUPCCount = 0;

    this.modalRef = this.modalService.open(this.restockconfirmmodal, { centered:true, size:'lg', backdrop:'static' }); //
    
  }


  upcInfoConfirmed(option:string){
    //s5: user confirmed put qty or cancel or selected Not Empty
    //close modal and continue to next item
    switch(option){
      case 'Save':
        //Notify back end to save and stock item to invenotry generate consume and data trasnactions
        this.confirmedRestockAction('save');        
        break;
      case 'Cancel':
        //Notify back end of cancel event to turn off any leds - trigger state machine input
        this.confirmedRestockAction('cancel');        
        break;        
      case 'NotEmpty':
        //Notify back end (after showing Ok modal) of not empty event to generate data trasnaction
        this.modalManager("msgAction", "userSlotNotEmpty", "");        
        break;          
    }
  }  


  confirmedRestockAction(action){

    //send action to the back end - for the restock event
    this.errState = false;
    this.loading = true;
    let that = this;    

    setTimeout(function(){
      if (that.loading) {
        that.loading = false; 
        that.errState = true;
        that.errorMsg = "Sorry, something is not quite right.  No action set.";
        that.pageMessage = "Sorry, something is not quite right.  No action set.";}
      }, 6000);

    this.restApi.putRestockAction(this.activePutItem, action).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
      that.errorMsg = "";

      let itemdata = data as {topic:string, payload:any};

      if(action === "cancel" || action === "save"){
        that.clearStagedItem();
      } 
    });

  }


  adjustConfirmQty(group:string = "pick", action:string){
    //s6: adjust quantities during confirm stage    
    if(action == "sub") {
      this.activePutItemQty-= 1;
    } else {
      //assumes return:add action
      this.activePutItemQty+= 1;
    }
    
    if(this.activePutItemQty < 1) this.activePutItemQty = 1
    else if(this.activePutItemQty > 10) this.activePutItemQty = 10;

    this.activePutItemPutQty.setValue(this.activePutItemQty); //update form field
    this.activePutItem.sub_qty = this.activePutItemQty; //update staged object subqty
  }  


  confirmedSlotNotEmpty(eventCode = "userSlotNotEmpty", area=this.activeArea, location=this.activeLocation){    
    
    this.confirmedRestockAction('notempty');

    /*
    //send the event to the back end - to create data transaction for occupied slot 
    this.errState = false;
    this.loading = true;
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
      }, 6000);

    let invref = {area:area, location:location, eventCode:eventCode};

    this.restApi.putInventorySlotNotEmpty(invref).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
  
      let invdata = data as {topic:string, payload:any};

      //that.pickOrderDetailArray = wrdata.payload.messageData;
    });

    */
  }  
  

  pinCode(pin:string){
    switch(pin){
      case "Enter":
        this.pinSubmit();
        break;
      case "Back":
        this.pinBackCount+=1;
        this.modalShowErrorMsg = false;
        if(this.pinBackCount>5) {
          this.pinCaptured = "";
          this.pinBackCount = 0;
        }
        if(this.pinCaptured.length > 0) this.pinCaptured = this.pinCaptured.slice(0, -1);
        break;
      default:
        if(this.pinCaptured.length < 14)
        {
          this.pinCaptured+= pin;

          this.pinBackCount = 0;
        }
        this.pinCodeOK = (this.pinCaptured.length < 10); //allow Enter key to be enabled
        break;
    }
    
  }


  pinSubmit(){
    //if(this.modalRef) this.modalRef.close();
    var pinCapturedScannedUPC = this.pinCaptured.padStart(14, '0');
    
    if(!this.deviceFull) this.processScannedInput(pinCapturedScannedUPC, "manual");
  }


  modalManager(action = "default", option, msg) {
    let openModal = true;
    
    this.modalButtonStyle = "normal";
    this.modalOkOption = true;
    this.modalYesNoOption = !this.modalOkOption;
    this.modalPinOption = false;

    if(option !== "userManualEntryOnError"){
      //clear for all others
      this.modalShowErrorMsg = false;
      this.errorMsg = "";      
    }

    //close any prior modal dialogues
    if(this.modalRef) this.modalRef.close();

    //console.log("option: ", option);
    switch(option){
      case "userSlotNotEmpty":
          this.modalTitle = "Slot Not Empty";
          this.modalMessage = "Place Lens Currently in Slot into Restock Bin - Place New Lens in Identified Slot";   
          this.pinCaptured = "";  
          this.modalOkOption = true; 
          this.modalYesNoOption = false;   
        break;
      case "tooManyScanAttempt":
      case "productNotRecognized":
        this.modalTitle = "Product Not In Current Portfolio";
        this.modalMessage = "Manually enter or place box in reject bin.";   
        this.pinCaptured = "";  
        this.modalOkOption = true;
        this.modalYesNoOption = false;
        break;
      case "noUpcCapacityAvailable":
        this.modalTitle = "No Slot Available";
        this.modalMessage = "for size/lens package";   
        this.modalOkOption = true;
        this.modalYesNoOption = false;  
        break;                   
      case "GenericOK":
        this.modalTitle = "Proceed";
        this.modalMessage = msg;   
        this.pinCaptured = "";  
        this.modalOkOption = true;
        this.modalYesNoOption = false;  
        console.log("GenericOK");    
        break;      
      default:
        openModal = false; //no valid option
        break;
    }

    if(openModal) {
      let that = this;

      const modalOptions: Record<string, any> = {
        centered: true,
      };
      
      if(action == "msgStatic") modalOptions.backdrop = 'static' 
      //modalOptions.keyboard = false; //closable by hitting the ESC key if true

      this.modalRef = this.modalService.open(this.workrequestmodal, modalOptions);   
      this.modalRefArray.push(this.modalRef);

      this.modalRef.result.then((result) => {
        this.modalCloseResult = `Closed with: ${result}`;
        //Ok/Continue or Yes/No
        if(result) {
          switch(this.modalTitle){
            case "Slot Not Empty":
              this.confirmedSlotNotEmpty();
              break;              
          }
          console.log("modalCloseResult:", result);        
        }
      }, (reason) => {
        this.modalCloseResult = `Dismissed ${this.getDismissReason(reason)}`;
        
        console.log("modalCloseResult:", this.modalCloseResult);
      
      });
    }
  } 


  private getDismissReason(reason: any): string {    
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }  


  modalYesNoHandler(option:string){
    if(this.modalYesNoRef) this.modalYesNoRef.close();

    console.log("modalYesNoHandler with "+option);

    switch(this.modalTitle) {
      case "Quantity OK?":
        //this.notOrderedQtyConfirmed(option);
        break;
      case "Expired Item Detected":
        this.itemExpiredContinue(option==="Yes");
        break;
    }
  }


  modalYesNoManager(action, option, msg) {
    let openModal = true;
    
    this.modalButtonStyle = "normal";
    this.modalOkOption = false; //default to Yes/No option

    //close any prior modal dialogues
    if(this.modalYesNoRef) this.modalYesNoRef.close();

    //console.log("option: ", option);
    switch(option){
      case "InvalidUPC":
          this.modalTitle = "UPC Invalid";
          this.modalMessage = "The UPC entered/scanned is invalid.  Please try again."; 
          this.modalOkOption = true;
          this.modalYesNoOption = false;              
        break; 
      case "ItemUpcUnreadable":
          this.modalTitle = "UPC Unreadable";
          this.modalMessage = "The UPC is marked unreadable please discard."; 
          this.modalOkOption = true;
          this.modalYesNoOption = false;              
        break; 
      case "ItemExpiredConfirmContinue":
          this.modalTitle = "Expired Item Detected";
          this.modalMessage = "Continue storing expired item?"; 
          this.modalOkOption = false;
          this.modalYesNoOption = true;              
        break;                        
      case "GenericOK":
        this.modalTitle = "Continue...";
        this.modalMessage = msg;   
        this.pinCaptured = "";  
        this.modalOkOption = true;
        console.log("GenericOK-YesNo" + openModal);
        break;
      default:
        openModal = false; //no valid option
        break;
    }

    if(openModal) {
      let that = this;

      this.modalYesNoRef = this.modalService.open(this.workrequestyesnomodal, { centered:true, backdrop:'static' }); // 
      this.modalRefArray.push(this.modalYesNoRef);

      this.modalYesNoRef.result.then((result) => {
        this.modalYesNoCloseResult = `Closed with: ${result}`;
        //Yes/No
        if(result) {
          console.log("modalYesNoCloseResult:", result);        
        }
      }, (reason) => {
        this.modalYesNoCloseResult = `Dismissed ${this.getDismissReason(reason)}`;        
        console.log("modalYesNoCloseResult:", this.modalYesNoCloseResult);      
      });
    }    
  }   

}
