import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-message-indicator',
  templateUrl: './message-indicator.component.html',
  styleUrls: ['./message-indicator.component.css']
})
export class MessageIndicatorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
