import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { PickOrder } from 'src/app/models/PickOrder';
import { DeviceApiService } from 'src/app/services/device-api.service';
import { EventService, EventServiceMessage } from 'src/app/services/event.service';

@Component({
  selector: 'app-options-menu',
  templateUrl: './options-menu.component.html',
  styleUrls: ['./options-menu.component.css']
})
export class OptionsMenuComponent implements OnInit {

  private readonly _eventService: EventService;
  private eventServiceSubscription;
  public componentReference: string = "OptionsMenuComponent";

  public eventMessage: string;
  public buttonindex: number = 0;
  public purgeExpiredRequest:PickOrder;

  public errState:boolean = false;
  public loading:boolean = false;

  public pageMessage:string = "";
  public machineState:string = "unknown";

  public allowDirectPick = false;
  
  constructor(public router: Router, public restApi: DeviceApiService, eventService: EventService) { 
    this._eventService = eventService;
    this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});
  }
  
  ngOnInit(): void {
    this.loadHmiConfig(); 
    this.getHeartbeatLatest();
  }

  ngOnDestroy(): void {
    //unsubscribe/dispose
    this.eventServiceSubscription.unsubscribe();    
  }

  loadHmiConfig(){
    //leverage incoming hmi config and broadcast to other components
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "hmi-config-send", null, ['AppToolbarComponent']);
    this.broadcastComponentMessage(message);  
    console.log(this.componentReference + " loadHmiConfig called -- hmi-config-send");  
  }

  getHeartbeatLatest(){
    //get latest hearbeat to determine ui button states
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "send-heartbeat-latest", null, ['AppToolbarComponent']);
    this.broadcastComponentMessage(message);  
    console.log("getHeartbeatLatest...")
  }

  processHeartbeat(hb:any){
    console.log("processHeartbeat...");
    console.log(hb);
    try{      
      if((hb !== undefined ) && (hb !== null)) {
        this.machineState = hb.machineState.toLowerCase();
      }
    } catch(err){
      console.log(err);
    } 
  }

  broadcastComponentMessage(message:EventServiceMessage = null): void {   
    //console.log(this.componentReference+' sent Message...', message); 
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "hmi-config-relay":
          this.processHmiConfig(message.payload);        
          break;  
        case "apptoolbar-heartbeat-relay":
        case "apptoolbar-heartbeat-lastest":
          this.processHeartbeat(message.payload);
          break;            
      }
    }    
  }  

  processHmiConfig(cfg:any){    
    try{
      if((cfg !== undefined ) && (cfg !== null)) {
        console.log("OptionsMenuComponent GOT HMI CONFIGED!");
        console.log(cfg.payload.directPick.options.allowDirectPick);        
        this.allowDirectPick =(cfg.payload.directPick.options.allowDirectPick)?true:false;

        }
    } catch(err){
      console.log(err);
    }  
  } 

  navigateTo(route:string){
    this.router.navigateByUrl(route); 
  }

  requestPurgeExpired(){
    this.purgeExpiredRequest = new PickOrder;
    this.purgeExpiredRequest.mode = "expired";
    this.purgeExpiredRequest.workrequestid = 0;

    this.errState = false;
    this.loading = true;

    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.pageMessage = "Sorry, something is not quite right.";}
      }, 6000);

    this.restApi.putWorkRequest(this.purgeExpiredRequest.workrequestid, this.purgeExpiredRequest.mode).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
  
      let wrdata = data as {topic:string, payload:any};
      
      console.log('activateWorkRequest --> wrdata: ',wrdata)

      var workrequestref = that.purgeExpiredRequest;

      that.router.navigate(['/workrequest-active'], { state: workrequestref});
      //that.pickOrderArray = wrdata.payload.messageData;
      //this.router.navigateByUrl("/home"); 
    });     
  }

  navigateSetIndex(url:any, navigate:boolean=true){
    console.log(url);

    switch(url){
      case "/inventory": 
        this.buttonindex = 1;
        if(navigate) this.navigateTo("/inventory");
        break; 
      case "/pickExpired": 
        //throw new Error('HMI App Exception-Error Test!!!'); return;
        this.buttonindex = 2;
        this.requestPurgeExpired();
        break;    
      case "/reloadApp": 
        this.buttonindex = 3;
        //window.location.reload();
        let dtx = Date.now().toFixed();
        window.location.assign("/?dt="+dtx);
        break;   
      case "/direct-pick": 
        this.buttonindex = 4;
        if(navigate) this.navigateTo("/direct-pick");
        break; 
      case "/synchronize": 
        this.buttonindex = 5;
        if(navigate) this.navigateTo("/synchronize");
        break;            
      default:
        this.buttonindex = 0;
        console.log("AppSidenavComponent url: "+url);
        break;
    }
  }

}
