import { Component, OnDestroy, OnInit, SimpleChanges } from '@angular/core';
import { Event, RouterEvent, NavigationEnd, Router } from '@angular/router';
//import { WebsocketService } from "./../../services/websocket.service";
import { DeviceApiService } from "../../services/device-api.service";
import { NetworkMonitorService } from "./../../services/network-monitor.service"
import { MachineStateMonitorService } from "./../../services/machinestate-monitor.service"
import { DeviceMessage } from 'src/app/models/DeviceMessage';
import { HmiAction } from './../../shared/hmi-action';
import { EventService, EventServiceMessage } from '../../services/event.service';
import { NgbModal, NgbModalRef, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { HostListener, TemplateRef, ViewChild, Renderer2} from '@angular/core';

//import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-app-toolbar',
  templateUrl: './app-toolbar.component.html',
  styleUrls: ['./app-toolbar.component.css'],
  providers: [NetworkMonitorService, MachineStateMonitorService]
})
export class AppToolbarComponent implements OnInit, OnDestroy {
  private readonly _eventService: EventService;
  private eventServiceSubscription;
  public componentReference: string = "AppToolbarComponent";

  public eventMessage: string;

  //private wsSubscription: Subscription;

  private _imgbaseurl = "assets/images/";

  public msgDisplay: string = "";
  public userStatusImageSrc: string = this._imgbaseurl+'user_ok.png';
  public userNameDisplay: string = "..."; //"None";

  public devcieTimeDisplay: string = "...";
  public deviceNameDisplay: string = "...";  
  public deviceStatusDisplay: string = "...";
  public deviceStatusStyle: string = "status-ok";
  public deviceConnectionStatus: string = "";
  public lastDeviceHeartbeat: DeviceMessage;

  public hmiConfig: any;

  public netStatusImageSrc: string = '';
  public msgArray: Array<string> = [];

  public hmiAction: HmiAction = new HmiAction(); 
  public startUp = true;

  private message: DeviceMessage  = {
    topic: "iotedge",
    payload: "this is a test message"
  };

  public closeResult: string;
  public modalTitle: string;
  public modalMessage: string;
  public targetLocation: string;
  public targetLocationBad: string;
  public targetLocationNext: string;
  public targetLocationLabel: string = "Next Location:";

  public TargetExpiredItems: string = "";
  public targetLocationOk: boolean = false;  //determines which location to display based on the event that opened the modal

  public modalGenericTitle: string;
  public modalGenericMessage: string;  

  public errorCode: string = "";
  public errorMsg: string = "";
  public modalShowErrorCode: boolean = false;
 
  public modalRef: NgbModalRef;
  public modalRefArray: NgbModalRef[] = [] ;
 
  public modalOkOption: boolean;
  public modalContinueOption: boolean;
  public modalShutdownOption: boolean;    
  public modalButtonStyle: string;
  public modalShowTargetLocation: boolean;
 
  public modalCapturePin: boolean = false;
  public pinCaptured: string = "";
   
  public lastMState: string;
  public lastMAlert: string;

  public machineState: string = ""
  public navActionEnable: boolean = false;  

  public shutdownRequested: boolean = false;
  
  public toolbarTimer;

  public keysInputBuffer = "";
  public lastSingleKeyInput = "";
  public lastKeysEnteredInput = "";

  public lastArea: string;
  public lastLocation: string;

  public noScanRequested: boolean = false;  
  public allowNoScanAlertTS: number = 0;

  public lastWorkRequestMode: string = "directPick";
  public currentApplicationVersion = environment.appVersion;
  
  //listen to keyboard/wedge scanner key events
  @HostListener('document:keypress', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) { 
    this.keyboardScannerInput(event);
  }

  @HostListener('touchstart', ['$event'])
  documentTouch(event: Event) {
    this.touchInput(event);
  }

  @HostListener('document:click', ['$event'])
  documentClick(event: MouseEvent) {
    this.mouseInput(event);
  }

  @ViewChild("hmimodalcontent") hmiModalContent: TemplateRef<any>;

  constructor(public router: Router, public restApi: DeviceApiService, public networkMonitorService: NetworkMonitorService,
    public machineStateMonitorService: MachineStateMonitorService, private modalService: NgbModal, eventService: EventService,
    //public websocketService: WebsocketService, 
    private renderer: Renderer2) { 
    this._eventService = eventService;
    this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});
  }

  ngOnInit(): void {
    //this.websocketService.openWebSocket(); //using appmodule websocket (static)
    //this.websocketService.deviceMessageChange.subscribe((m:string) => {this.deviceIncomingMessage(m)});
    //this.websocketService.deviceConnectionChange.subscribe((m:string) => {this.deviceConnectionState(m)});
    this.getDeviceStatus();

    this.netStatusImageSrc = this._imgbaseurl + "net_unk.png";      //

    //this.router.events.subscribe((val) => {
    //  // see also 
    //  console.log(val);       
    //  //console.log(val instanceof NavigationEnd); 
    //});

    this.router.events.pipe(
      filter((e: Event): e is NavigationEnd => e instanceof NavigationEnd)
      ).subscribe((e: NavigationEnd) => {
        let url = e.url;
        if(this.deviceConnectionStatus == 'opened') {
          this.sendMessage("HMINav", "nav"+url); // notify the backend of navigation event to set the machineState to Ready or as needed nav/
          console.log(url);
        }

        //Tell target components, like side-bar, to update nav status
        this.notifyNavUpdate(e.url);
      });
    
    this.checkNetStatus();
    //this.getDeviceStatus();
    
    this.updateTimeDisplay();
  }

  deviceConnectionState(status:string){
    var connstate = status.toLowerCase();
    console.log("app toolbar - deviceConnectionState: ws---> "+connstate)

    this.deviceConnectionStatus = connstate;

    if(connstate == 'opened') {
      this.sendMessage("MState","sendMState");
      this.getHmiConfig();
      this.sendMessage("hmiVersion", this.currentApplicationVersion);
    }

    if(connstate == 'closed') {
      this.deviceStatusDisplay = "?";

      this.lastDeviceHeartbeat = new DeviceMessage('','');

      //notify other components
      const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "apptoolbar-device-connection", status, 
                    ['HomeComponent','FooterComponent','RestockComponent',,'ProductFinderComponent','SplashIdleScreenComponent','AppSidenavComponent']);
      this.broadcastComponentMessage(message);      
    }
  }

  ngOnDestroy(): void {
    // remove websocket
    //this.wsSubscription.unsubscribe();
    //this.websocketService.closeWebSocket();

    //unsubscribe/dispose
    this.eventServiceSubscription.unsubscribe();
  }

  broadcastComponentMessage(message:EventServiceMessage = null): void { 
    //console.log(this.componentReference+' sent Message...', message);  
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      //console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "shutdownInitiate":
          this.shutdownInitiate();
          break;
        case "send-heartbeat-now":
          this.getDeviceStatus();
          break;
        case "send-heartbeat-latest": 
          this.sendLastDeviceHeartbeat();
          break;          
        case "hmi-config-send":
          if((this.hmiConfig !== undefined) && (this.hmiConfig !== null))
          {
            this.notifyHmiConfig(); //send loaded/last received hmi config
          } else {
            this.getHmiConfig(); //get hmi config --> then sned
          }
          break;
        case "device-incomingmessage":
          this.deviceIncomingMessage(message.payload);
          break;     
        case "device-connectionstatus":
          this.deviceConnectionState(message.payload);
          break;       
      }
    }    
  }

  updateTimeDisplay(){
    var ts = new Date();

    //this.devcieTimeDisplay = ts.toLocaleTimeString([], {year:'numeric', month:'numeric', day:'numeric', hour:'numeric', minute:'2-digit'}) //ts.toLocaleString();
    this.devcieTimeDisplay = (ts.getMonth()+1)+"/"+ts.getDate()+"/"+ts.getFullYear()+" "+ts.toLocaleString('en-US', { hour: 'numeric', minute: 'numeric', hour12: true }) 
    if(this.toolbarTimer) clearTimeout(this.toolbarTimer);
    let that = this;
    this.toolbarTimer = setTimeout(function() { that.updateTimeDisplay(); }, 5000);

  }

  keyboardScannerInput(event:KeyboardEvent){  
    
    if(event.key === 'Enter' || event.key === 'Tab') {
      console.log("Enter Key Detected...");
      event.preventDefault();
      this.lastKeysEnteredInput = this.keysInputBuffer;
      this.keysInputBuffer = "";
      this.notifyKeysInput("app-enteredinput");
      //console.log(this.lastKeysEnteredInput);
    } else {
      this.keysInputBuffer+= event.key;
      this.lastSingleKeyInput = event.key;
      this.notifyKeysInput("app-keyinput");
    }

    if(this.keysInputBuffer.length > 64) this.keysInputBuffer = "";  
    //console.log(this.lastSingleKeyInput);
  }

  mouseInput(event:any){
    //detect mouse click events on UI page component(s) to prevent actions during specififc states (such as trying to navigate away during locate)
    console.log("mouseInput: "+event.target.nodeName+"     this.lastMState: "+this.lastMState );
    console.log(event);
    var targetId = (event.target && event.target.id)?event.target.id:"";

    var navButtonClicked: boolean = (targetId.includes("navBtnSideBar") || targetId.includes("navMenuBtnAnchorReset"));  //allow user to click side nav or reset buttons
    var navMenuButtonClicked: boolean = (targetId.includes("navMenuBtn")) && !navButtonClicked;
    var optionButtonClicked: boolean = targetId.includes("optionBtn");  //no need to call no Scan Confirm, user clicked on an option button (no Scan Confirm already showing or reset option (ex: optionBtnShutdown))
    var divResetContentClicked: boolean = targetId.includes("divResetContent");  //no need to call no Scan Confirm, if shutdown in process
    //var slotOptionClicked: boolean = targetId.includes("slotOptionBtn");  //no need to call no Scan Confirm, if selection a slot option in process
    //var manualPinClicked: boolean = targetId.includes("slotOptionBtn");  //no need to call no Scan Confirm, if selection a slot option in process

    //during locate or locatenoscan (loate timedout) 
    //call no Scan Confirm to display no scan pop-up
    if(!this.shutdownRequested && (this.lastMState === "mstate:locate" || this.lastMState === "mstate:locatenoscan") && (event.target.nodeName !== "BUTTON" || navMenuButtonClicked) && (event.target.nodeName !== "SPAN")){
      console.log("Mouse event..."+this.lastMState);     

      //allow the side menu to be clicked, ok button from pop up and the restart option if on/off button clicked otherwise call no Scan Confirm
      if(!navButtonClicked && !optionButtonClicked && !divResetContentClicked )  this.noScanConfirm();
    }
  }

  noScanConfirm(){
    //show modal when a pick to locate and no item scanned (timeout) or user touches away during locate or locate* (timed out)
    //prevent navigation during locate - requires user 

    console.log("noScanConfirm called!");

    if((this.machineState != "locatenoscan") && (Date.now() < this.allowNoScanAlertTS)) return;
    
    let that = this;

    this.restApi.getWorkRequestsItemsActive().subscribe((data: any) => {  
      
      var itemActive = data.payload.messageData;
      /* 
      {
          workRequestMode:workRequestMode,
          inventoryMode:inventoryMode,
          machineState:machineState,
          workRequestItemActiveNoScanCountToEmpty:workRequestItemActiveNoScanCountToEmpty,
          workRequestItemActive:workRequestItemActive,
          workRequestItemActiveLast:workRequestItemActiveLast,
          inventoryOnActiveLocation:inventoryOnActiveLocation
      };
      */

      console.log("itemActive:",itemActive);

      if(((itemActive.inventoryOnActiveLocation.status !== "empty") || (itemActive.workRequestMode == "normal")) && itemActive.machineState.includes("locate")) {
        //that.forceEmptyOnNoScan = (itemActive.inventoryOnActiveLocation.status !== "empty");

        that.lastArea = itemActive.workRequestItemActiveLast.area;
        that.lastLocation = itemActive.workRequestItemActiveLast.location;

        that.lastWorkRequestMode = itemActive.workRequestMode;

        that.machineState = itemActive.machineState.toLowerCase(); //force machine state - ToDo: call processHaeartbeat() instead

        that.lastMAlert = "malert:locatenoscan"; //simualte alert
        that.noScanRequested = true;
        that.modalManager("msgAction", "", [itemActive.workRequestItemActiveNoScanCountToEmpty] );       
      } 
    });

  }

  touchInput(event:Event){  
    console.log("Touch event..."+this.lastMState);
    console.log(event);
  }

  //handle websocket message (from app compoennet)
  deviceIncomingMessage(msg: string){
    
    console.log("incoming message:", msg);
    
    this.msgArray = msg.split(':'); //msg.split(',')[0]; ---- GROUP:ACTION/VALUE
    let act = false;

    //console.log(this.msgArray);

    switch(this.msgArray[0]){
      case "MState":
        if(this.msgArray[1] == "EndLocate")
        {
          //this.navigateHome();
          this.notifyEndLocate();
        } else {
          //assume state change
          this.hmiAction = this.machineStateMonitorService.getMachineStateIndicatorState(this.msgArray);
          act = true;
        }
        break;
      case "WorkRequest":
        if(this.msgArray[1] == "Queued" && this.machineState == "ready"){
          if (this.router.url === "/home")
          {
             //Tell the home component to refresh the workrequest list
            const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "apptoolbar-workrequest-queued", null, ['HomeComponent']);
            this.broadcastComponentMessage(message);
          } else {
            this.navigateHome();
          }
        }
        break;
      case "NavHomeRequested":     
        this.navigateHome();
        break;    
      case "RestartForced":     
        this.shutdownExecute("restart");
        break;              
      case "MAlert":
        act = true;
        break;         
      case "Network":
        this.hmiAction = this.networkMonitorService.getNetworkIndicatorState(this.msgArray);
        //this.netStatusImageSrc = this._imgbaseurl + this.hmiAction.imageSrc;
        this.checkNetStatus();
        act = true;
        break;
      case "WorkRequestItems":
      //Assumes Update (default) action
        this.notifyWorkRequestItemsUpdate(this.msgArray[1]);
        break;
      case "LedCmdLocation":
        this.notifyLocationLedCmd(this.msgArray[1]);
        break;
      //case "WorkRequest": IGNORE - Home componenet already consuming web socket messages
      //  this.notifyWorkRequestUpdate(this.msgArray[1]);      
      //  break;           
      case "TargetLocationNext": 
        this.targetLocationNext = this.msgArray[1] || null;   
        if(this.targetLocationOk) this.targetLocation = this.targetLocationNext; //update location to display if message was updated/sent later      
        break;     
      case "TargetLocationBad":
        this.targetLocationBad = this.msgArray[1] || null;   
        if(!this.targetLocationOk) this.targetLocation = this.targetLocationBad; //update location to display if message was updated/sent later     
        break;  
      case "TargetExpiredItems":
        console.log("TargetExpiredItems called and last alert is "+this.lastMAlert);
        console.log("TargetExpiredItems called and last state is "+this.lastMState);

        let lastMstate = (this.lastMState) ? this.lastMState.toLowerCase() : "";
        let lastMalert = (this.lastMAlert) ? this.lastMAlert.toLowerCase() : "";

        if((lastMstate === "mstate:locate") && (lastMalert !== "malert:invalidretrieval")) {
          this.targetLocationOk = false;  //Force locator display to bad

          this.TargetExpiredItems = (this.msgArray[1] || "").replace("//",":");   
          this.targetLocationLabel = "";
          if(!this.targetLocationOk) this.targetLocation = this.TargetExpiredItems; //update location to display if message was updated/sent later     
  
        }

        break;          
      case "ErrorCode":
        let errcode = this.msgArray[1];
        this.errorCode = errcode.replace(/OErr-/g, '') || "";   
        this.errorMsg = this.msgArray[2] || "";
        break;                 
      default:
        break;
    }

    //this.sendMessage();
    if(act) {
      //this.msgDisplay = msg;
      if(this.hmiAction && this.hmiAction.display != null) {
        this.msgDisplay = this.hmiAction.display;
        //this.deviceStatusDisplay = this.hmiAction.display; 
        this.getDeviceStatus(); //get the heartbeat and update other variables and relay to components
      }

      if(this.hmiAction.route) if(this.router.url !== "/"+this.hmiAction.route ){
        if(!this.startUp) this.router.navigateByUrl(this.hmiAction.route);
      }
  
      var opt = msg.toLowerCase();

      if(msg.includes("MState:")) {
        this.lastMState = opt; 

        console.log("act:"+opt);

        if(opt.includes("mstate:locate")){
          // for locatenoscan and locate
          console.log("opt for noScanConfirm: "+opt);
          if(opt == "mstate:locatenoscan") this.noScanConfirm();
          return;
        }      
      }

      if(msg.includes("MAlert:")) {        

        if(this.router.url === "/splashidle" ){
          if(!this.startUp) this.router.navigateByUrl("/home");
        }

        if(msg.includes("MAlert:Generic")){
          opt = "malert:generic"; //force lowercase for modal manager processing

          //For MAlert:Generic
          //  [0]-MAlert
          //  [1]-Generic
          //  [2]-(Message Title)
          //  [3]-(Message Content)

          this.modalGenericTitle = (this.msgArray[2] || "Alert").replace("//",":");;
          this.modalGenericMessage = (this.msgArray[3] || "Unknown - Test").replace("//",":");;
         
        }

        this.lastMAlert = opt; 
      }       


      this.modalManager("msgAction", opt, this.msgArray);      
    }

    //on first call assume starting up and end startup
    if(!this.startUp) this.startUp = false;
  }

  modalManager(action, option, msg) {
    let openModal;
    this.modalButtonStyle = "normal";
    
    //close any prior modal dialogues
    if(this.modalRef) this.modalRef.close();

    //if(this.modalRefArray) {
    //  this.modalRefArray.forEach(function(item, index, object) {
    //    if(item) item.close();    
    //    object.splice(index, 1);  
    //  });
    //}

    //options: NeedFullScan, Ready, NoRead/InvalidScan, InvalidRetrieval
    //  MState:NeedFullScan, MState:Ready, MAlert:InvalidScan, MAlert:InvalidRetrieval

    //MState:NeedFullScan   
    openModal = true;
    this.modalOkOption = true;
    this.modalContinueOption = false;
    this.modalShutdownOption = false;    
    this.modalCapturePin = false;
    this.modalShowTargetLocation = false;
    this.shutdownRequested = false;

    //console.log("option: ", option);
    switch(option){
      case "mstate:ready":
        this.modalTitle = "Ready";
        this.modalMessage = "Scan complete.";  
        this.lastMAlert = "";   
        openModal = false;   
        this.targetLocation = "";
        this.errorCode = "";
        this.errorMsg = "";
        break;
      case "mstate:needfullscan":
      case "mstate:locatescan":
      case "mstate:activecasescan":                      
        this.modalTitle = "Please wait...";
        this.modalMessage = "We're updating inventory.";  
        this.lastMAlert = "";  
        this.targetLocation = "";
        this.errorCode = "";
        this.errorMsg = "";
        break;   
      case "mstate:needfullscan:wait_continue":
      case "mstate:locatescan:wait_continue":
      case "mstate:activecasescan:wait_continue":  
        this.modalTitle = "Scanning will resume...";
        this.modalMessage = "Press Continue to scan now or wait a few moments to automatically resume.";  
        this.lastMAlert = "";  
        this.modalOkOption = false;
        this.modalContinueOption = true;  
        this.targetLocation = "";  
        this.errorCode = "";  
        this.errorMsg = "";  
        break;         
      //case "mstate:locate":
      //case "mstate:activecase":
      //  this.modalTitle = "Locating items...";
      //  this.modalMessage = "Please visually confirm that the item(s) located match the item removed.";
      //  this.targetLocationLabel = "Pick Location:";
      //  this.targetLocation = ""; //this.targetLocationNext;
      //  this.errorCode = "";
      //  this.modalShowTargetLocation = true;
      //  this.modalShowErrorCode = false;
      //  this.targetLocationOk = true;
      //  this.lastMAlert = "";  
      //  break; 
      case "mstate:error":
      case "mstate:hardwareerror":
        this.modalTitle = "Hardware error detected.  ";
        this.modalMessage = "Please call customer support.";
        this.modalShowErrorCode = true;
        this.lastMAlert = "";  
        this.modalButtonStyle = "danger";
        break;  
      case "network:nonet":
        this.modalTitle = "No Network";
        this.modalMessage = "The network connection was lost.";   
        this.lastMAlert = ""; 
        break;    
      case "capturePin":
        if(this.router.url !== "/diagengr") {
          this.modalCapturePin = true;
          this.modalTitle = "Diagnostics Center";
          this.modalMessage = "Access to this feature requires a PIN.";   
          this.lastMAlert = ""; 
          this.pinCaptured = "";
          this.modalShowTargetLocation = false;
          this.modalShowErrorCode = false;
        } else {
          openModal = false;
        }
        break;   
      case "shutdownConfirm":
        this.modalTitle = "Shutdown?";
        this.modalMessage = "Please select an option for reset.";
        this.shutdownRequested = true;
        this.modalOkOption = false;
        this.modalShutdownOption = true;
        break;              
      default:
        switch(this.lastMAlert){
          case "malert:invalidretrieval":
            this.modalTitle = "WARNING!";
            this.modalMessage = "An incorrect or unexpected item was removed. \n Please reinsert box.";
            this.modalShowTargetLocation = true;
            this.modalShowErrorCode = false;
            this.targetLocationLabel = "At Location:";  
            this.targetLocation = ""; //this.targetLocationBad; 
            this.errorCode = "";
            this.targetLocationOk = false;
            this.modalButtonStyle = "danger";
            break;   
          case "malert:invalidscan":
            this.modalTitle = "WARNING!";
            this.modalMessage = "One or more items could not be scanned. \n Please reposition or remove box(es).";   
            break;     
          case "malert:nothingtolocate":
            this.modalTitle = "Nothing to Locate";
            this.modalMessage = "There are no items to locate.";   
            break;   
          case "malert:featurenotavailable":
            this.modalTitle = "Feature Unavailable";
            this.modalMessage = "This feature is either not supported or not available.";   
            break;              
          case "malert:generic":
            this.modalTitle = this.modalGenericTitle;
            this.modalMessage = this.modalGenericMessage;   
            break;                       
          case "malert:netwifisetupfail":
            this.modalTitle = "Unable to connect WiFi";
            this.modalMessage = "Incorrect SSID or passphrase. \n Please try again.";   
            break; 
          case "malert:netwifisetupsuccess":
            this.modalTitle = "Success.";
            this.modalMessage = "Wi-Fi configuration saved.";   
            break;  
          case "malert:netlansetupsuccess":
            this.modalTitle = "Success.";
            this.modalMessage = "Network configuration saved.";   
            break; 
          case "malert:netlansetupfail":
            this.modalTitle = "Unable to connect";
            this.modalMessage = "An error occurred while saving. \n Please try again.";   
            break;     
          case "malert:reboot":
            this.modalTitle = "Restarting...";
            this.modalMessage = "Please standby while we reset.";   
            break;  
          case "malert:rebootfailed":
            this.modalTitle = "Restarting...";
            this.modalMessage = "The reboot did not complete.  Please power the system down and then power back up."; 
            this.modalButtonStyle = "danger";  
            break;  
          case "malert:locatenoscan":
            this.modalTitle = "Looks like we missed something"; //+msg[0];
            if( (this.lastWorkRequestMode != "normal") && ((this.lastMState === "mstate:locatenoscan") || (this.machineState == "locatenoscan"))){
              this.modalMessage = "<strong>Please confirm slot"+(this.lastArea?" "+this.lastArea:"")+(this.lastLocation?":"+this.lastLocation:"")+" is empty.</strong>  <br />"; 
              this.modalMessage += "If there's product"+(this.lastArea?" in "+this.lastArea:"")+(this.lastLocation?":"+this.lastLocation:"") + ", <br />please remove it for restocking."         
            } else {     
              this.modalMessage = "Please select an option if scanning is not possible"+(this.lastArea?" for slot "+this.lastArea:".")+(this.lastLocation?":"+this.lastLocation:"");              }
            break;                                                                          
          default:
            openModal = false;
            break;
        } 
        break;
    }

    if(openModal) {
      let that = this;

      this.modalRef = this.modalService.open(this.hmiModalContent, { centered: true });   
      this.modalRefArray.push(this.modalRef);

      this.modalRef.result.then((result) => {
          this.closeResult = `Closed with: ${result}`;
          //Ok or Continue 
          console.log(this.modalRef);

          if(result) {

            if(this.noScanRequested && !this.shutdownRequested) {
              this.sendItemNoScanConfirmed();
              this.noScanRequested = false;
              return;
            }

            if(this.shutdownRequested) {
              this.shutdownExecute(result);
              return;
            }

            if(this.modalCapturePin) {
              this.navigateDiagEngr(true);
            } else {
              this.sendMessage("hmiEvent", result);
            }          
            console.log("closeResult:", result);        
          }
         
        }, (reason) => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
          this.sendMessage(null, null);
          console.log("closeResult:", this.closeResult);
              
        });
    }
  }

  private getDismissReason(reason: any): string {    
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      if(this.shutdownRequested ) this.shutdownRequested = false;
      return 'by clicking on backdrop';
    } else {
      return  `with: ${reason}`;
    }
  } 
    
  navigateHome(){
    this.router.navigateByUrl("/home"); 
    this.getDeviceStatus();
  }

  navigateSplashIdle(){
    if(this.navActionEnable) {
      this.router.navigateByUrl('/splashidle', { state: { splashType:"idlerHome"} }); 
    
      //Tell the app component to (force) close the sidebar
      const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "sidebar-closeforced", null, ['AppComponent']);
      this.broadcastComponentMessage(message);
    }
  }

  sendItemNoScanConfirmed(){
    //remove the item (currenlty active/highlighted from pick action) from inventory (if not already removed)
    console.log("sendItemNoScanConfirmed called.")
    this.restApi.putWorkRequestItemNoScan("", this.lastArea, this.lastLocation).subscribe((data: {}) => { 
      //that.router.navigateByUrl("/shutdown"); 
    });
  }

  notifyNavUpdate(url:string){
    //Tell the work request active component to (force) update the work request items list
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "nav-update-relay", url, ['AppSidenavComponent']);
    this.broadcastComponentMessage(message);  
    console.log(this.componentReference + " notifyNavUpdate called -- nav-update-relay");  
  }

  notifyWorkRequestItemsUpdate(option:String){
    if(option === "Update") {
      //Tell the work request active component to (force) update the work request items list or in direct pick to refresh invenotry list
      const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "workrequestitems-refresh", null, 
                    ['WorkrequestActiveComponent','ProductFinderComponent']);
      this.broadcastComponentMessage(message);  
      console.log(this.componentReference + " notifyWorkRequestItemsUpdate called -- workrequestitems-refresh");    
    }
  }

  notifyLocationLedCmd(location:String){    
    //Tell the work request active component to (force) update the work request items list
    
    let ledcmd = location.split("|");

    if(ledcmd.length > 1) {
      this.lastArea = ledcmd[0];
      this.lastLocation = ledcmd[1];
    }

    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "workrequestitems-locationledcmd", location, 
                  ['WorkrequestActiveComponent','ProductFinderComponent']);
    this.broadcastComponentMessage(message);  
    //console.log("notifyWorkRequestItemsUpdate called -- workrequestitems-locationledcmd");    
  }

  notifyEndLocate(){    
    //Tell the work request active component to go home after locate end
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "workrequest-endlocate", null, 
                  ['WorkrequestActiveComponent','ProductFinderComponent']);
    this.broadcastComponentMessage(message);    
  }  

  notifyKeysInput(option:string = "app-keyinput"){    
    //Notify target components of key pressed events
    let message:EventServiceMessage; 

    switch(option){
      case "app-enteredinput":
        message = new EventServiceMessage(this.componentReference, "app-enteredinput", this.lastKeysEnteredInput, 
                      ['WorkrequestActiveComponent','ProductFinderComponent','RestockComponent']);
        break;
      default:
        //app-keyinput message
        message = new EventServiceMessage(this.componentReference, "app-keyinput", this.lastSingleKeyInput, 
                      ['HomeComponent','WorkrequestActiveComponent','ProductFinderComponent','RestockComponent']);
        break;
    }

    this.broadcastComponentMessage(message);    
  }  


  navigateNetworkConfig(){
    this.checkNetStatus();
    this.router.navigateByUrl("/neteditor");
  }

  navigateDiagEngr(confirmable:boolean = false){
    if(confirmable) {
      if(this.pinCaptured === "7500") {
        this.router.navigateByUrl("/diagengr");
      }
      this.pinCaptured = "";
    } else {
      this.modalManager("usrAction", "capturePin", this.msgArray); 
    }
  }

  pinCode(pin:string){
    this.pinCaptured+= pin;
  }

  sendMessage(topic: string, msg: string){
    if(!topic && !msg) {topic = "genericHmiEvent"; msg = null;}
    const monitorMsg = new DeviceMessage(topic, msg);

    //this.websocketService.sendMessage(monitorMsg);
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "device-sendmessage", monitorMsg, ['AppComponent']);
    this.broadcastComponentMessage(message);
  }

  sendLastDeviceHeartbeat(){   
    console.log("Apptoolbar (request) Sending latest heartbeat..");
    //re-broadcast heartbeat on-demand to other components
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "apptoolbar-heartbeat-lastest", this.lastDeviceHeartbeat, 
                  ['HomeComponent','FooterComponent','RestockComponent','ProductFinderComponent','SplashIdleScreenComponent','AppSidenavComponent','OptionsMenuComponent']);
    this.broadcastComponentMessage(message);
  }

  checkNetStatus(){
    let that = this;
    //console.log('checkNetStatus called. ');
    this.restApi.getNetworkStatus().subscribe((data: {}) => { 
      let cdata:DeviceMessage = <DeviceMessage>data;    

      that.hmiAction = this.networkMonitorService.getNetworkIndicatorFromStatus(cdata.payload.messageData.payload);
      if(this.hmiAction.imageSrc) that.netStatusImageSrc = this._imgbaseurl + this.hmiAction.imageSrc;
      console.log('checkNetStatus result: ',that.netStatusImageSrc);
    });
  }

  getHmiConfig(){
    let that = this;

    this.restApi.getHmiConfig().subscribe((data: {}) => { 
      let cdata:DeviceMessage = <DeviceMessage>data;    

      that.hmiConfig = cdata;
      that.notifyHmiConfig();
      console.log(that.hmiConfig);  
    });
  }

  notifyHmiConfig(){     
      //leverage incoming hmi config and broadcast to other components
      const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "hmi-config-relay", this.hmiConfig, 
                    ['AppSidenavComponent','ProductFinderComponent','RestockComponent','OptionsMenuComponent', 'WorkrequestActiveComponent']);
      this.broadcastComponentMessage(message);  
      console.log(this.componentReference + " notifyHmiConfig called -- hmi-config-relay");  
  }  
  
  getDeviceStatus(){
    let that = this;

    this.restApi.getHeartbeat().subscribe((data: {}) => { 
      let cdata:DeviceMessage = <DeviceMessage>data;    

      //update display values
      that.userNameDisplay = cdata.payload.messageData.currentUser;
      that.deviceNameDisplay = cdata.payload.messageData.deviceName;

      that.lastDeviceHeartbeat = cdata.payload.messageData;
      
      that.deviceStatusDisplay = that.machineStateMonitorService.getMachineStateIndicatorState(["mstate",cdata.payload.messageData.machineState]).display;
      that.processHeartbeat(that.lastDeviceHeartbeat);
      
      //leverage incoming device heartbeat and broadcast to other components
      const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "apptoolbar-heartbeat-relay", that.lastDeviceHeartbeat, 
                    ['AppComponent','HomeComponent','FooterComponent','RestockComponent','ProductFinderComponent','WorkrequestActiveComponent','SplashIdleScreenComponent','AppSidenavComponent','OptionsMenuComponent']);
      that.broadcastComponentMessage(message);

    });
  }

  processHeartbeat(hb:any){
    console.log("processHeartbeat...");
    console.log(hb);
    try{
      
      if((hb !== undefined ) && (hb !== null)) {
        this.machineState = hb.machineState.toLowerCase();

        var t = new Date();
        this.allowNoScanAlertTS = t.setSeconds(t.getSeconds() + 2);

        this.navActionEnable = ((this.machineState !== "locate") && (this.machineState !== "locatenoscan"));
      }
    } catch(err){
      console.log(err);
    } 
  }

  shutdownInitiate(){
    console.log("shutdownInitiate");

    var opt = "shutdownConfirm";
    this.modalManager("msgAction", opt, this.msgArray);  
  }

  shutdownExecute(option){
    //option ==> restart OR shutdown
    console.log("shutdownExecute:"+option);
    //Tell the app component to (force) close the sidebar
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "sidebar-closeforced", null, ['AppComponent']);
    this.broadcastComponentMessage(message);    

    let that = this;

    this.restApi.shutdownDevice(option,5).subscribe((data: {topic:string, payload:any}) => { 
      that.router.navigateByUrl("/shutdown",data.payload); 
    });

    //this.router.navigateByUrl("/shutdown");
  }
}
