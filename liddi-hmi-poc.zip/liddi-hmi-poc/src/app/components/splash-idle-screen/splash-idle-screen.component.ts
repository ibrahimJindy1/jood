import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import {Title} from "@angular/platform-browser";
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs/operators';
import { EventService, EventServiceMessage } from '../../services/event.service';

@Component({
  selector: 'app-splash-idle-screen',
  templateUrl: './splash-idle-screen.component.html',
  styleUrls: ['./splash-idle-screen.component.css']
})
export class SplashIdleScreenComponent implements OnInit {
  private readonly _eventService: EventService;
  private eventServiceSubscription;
  public componentReference: string = "SplashIdleScreenComponent";

  public eventMessage: string;

  public defaultPickMode: string = "";

  bgImageRef:string = "/assets/images/brand_transition_singleplay.png?dt=";
  bgImageRef2:string = "/assets/images/brand_transition_singleplay_cmlogoonly_md.png?dt=";
  bgImage:string = ""; //this.bgImageRef;

  splashType:string = "";
  state$: Observable<object>;

  screenWipeTimer;
  bgType:string = "normal";
  screenWipeDelay = 900000; //15 min

  constructor(public router: Router, private route: ActivatedRoute, private titleService:Title, public activatedRoute: ActivatedRoute, eventService: EventService) { 
        this._eventService = eventService;        
        this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});
        this.titleService.setTitle("IMS HMI");
  }

  ngOnInit(): void {  

    this.state$ = this.activatedRoute.paramMap
      .pipe(map(() => window.history.state))

    this.splashType = history.state;
    //console.log(history.state) 
    console.log(history.state) ;

    this.setImage();

    //this.route.queryParams.subscribe(params => {
    //  this.splashType = params['splashType'];
    //  console.log(this.splashType);
    //});

  }

  ngOnDestroy(): void {
    //unsubscribe/dispose
    this.eventServiceSubscription.unsubscribe();
  }

  broadcastComponentMessage(message:EventServiceMessage = null): void {   
    //console.log(this.componentReference+' sent Message...', message); 
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "apptoolbar-heartbeat-relay":
          this.capturePickMode(message.payload);
          break; 
      }
    }    
  }

  capturePickMode(hbPayload:any){
    //console.log(hbPayload);   
    this.defaultPickMode = (hbPayload.defaultPickMode) ? hbPayload.defaultPickMode : "unknown";
    console.log(this.defaultPickMode); 
  }

  navclick(){
    if(this.screenWipeTimer) clearTimeout(this.screenWipeTimer);
    if(this.bgType ==='dark') {
      let dt = Date.now();  
      this.bgType = "normal";
      //on click and if in dark mode then stay in splah screen with 
      //active mode.  User would click again to navigate (otherwise
      // wipe screen to dark on timeout)
      this.setImage(true);
    } else {
      var tgt_route = "/direct-pick";

      if(this.defaultPickMode === "normal"){ var tgt_route = "/home"; }      

      this.router.navigateByUrl(tgt_route);
      
      //Tell the app component to open the sidebar
      const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "sidebar-openwithmonitor", null, ['AppComponent']);
      this.broadcastComponentMessage(message);
    }
      
  }

  setImage(splashOption=false){
    let dt = Date.now();

    if(history.state.splashType === "idler" || splashOption) {      
      this.bgImage = this.bgImageRef2+dt;
      
    } else if (history.state.splashType !== "idlerHome") {
      let that = this;
      
      //On start up the page loads a cover div hides the animation/image
      //let's load the animation/image with a delay so that we don't miss 
      //the first part of the animation
      setTimeout(function(){
        that.bgImage = that.bgImageRef+dt;
      }, 3100);     
    }

    if(this.bgImage.length < 1) {
      this.bgImage = this.bgImageRef2+dt;
    }

    //let screenWipeTimer = setTimeout(function refreshImg() {
    //  let dtx = Date.now();
    //  that.bgImage = that.bgImageRef2+dtx;
    let that = this;
    this.screenWipeTimer = setTimeout(this.screenWipe, this.screenWipeDelay, that); // (*)
    //}, 10000);

  }

  screenWipe(it){
    console.log('called screenWipe.');
    it.bgType = "dark";
    it.bgImage = "/assets/images/brand_wipe.gif";
  }

}
