import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SplashIdleScreenComponent } from './splash-idle-screen.component';

describe('SplashIdleScreenComponent', () => {
  let component: SplashIdleScreenComponent;
  let fixture: ComponentFixture<SplashIdleScreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SplashIdleScreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplashIdleScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
