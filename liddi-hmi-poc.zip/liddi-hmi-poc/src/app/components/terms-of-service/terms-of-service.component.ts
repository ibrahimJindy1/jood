import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { DomSanitizer } from '@angular/platform-browser';
import { DeviceApiService } from '../../services/device-api.service';

import { HtmlUtils } from '../../shared/html-utils';

@Component({
  selector: 'app-terms-of-service',
  templateUrl: './terms-of-service.component.html',
  styleUrls: ['./terms-of-service.component.css']
})
export class TermsOfServiceComponent implements OnInit {
  htmlData:any = '';
  htmlString :any = '';
  loading:boolean = true;
  termsMessage:string = "Loading...";
  errState:boolean = false;

  constructor(public http: HttpClient, private sanitizer: DomSanitizer, public restApi: DeviceApiService, private htmlUtils:HtmlUtils) { }

  ngOnInit(): void {
    this.getHmiConfig();
  }

  setContent(countrycode:any = "us"){
    let htmlsrcurl;

    htmlsrcurl = this.buildSrcURL(countrycode);
    console.log('htmlsrcurl: '+htmlsrcurl);
    
    this.http.get(htmlsrcurl,{responseType: 'text'})
    .subscribe((result)=>{
        this.htmlString=this.htmlUtils.removeHrefFromAnchor(result);;
        this.htmlData = this.sanitizer.bypassSecurityTrustHtml(this.htmlString); // this line bypasses angular security - loading local content
        this.errState = false;
        this.loading = false;
      },err=>{
        console.log(err); 
        if(countrycode.toLowerCase() != 'us'){
          this.setDefaultContent();
        }
      }); 
  }

  setDefaultContent(){
    //this.htmlData = "Content Unavailable!";
    this.setContent();
  }

  buildSrcURL(countrycode:any = null):string{
    if(!countrycode) countrycode = 'us';

    return "assets/terms/termofservice_"+countrycode.toLowerCase()+".html";
  }

  getHmiConfig(){
    //gets the hmi "help" page configuration 
    this.errState = false;
    this.loading = true;
  
    let that= this;
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.termsMessage = "Sorry, something is not quite right.";}
        //that.setDefaultContent();
    }, 6000);
  
    this.restApi.getHmiConfig().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.termsMessage = "";

      //console.log(that);
      console.log(data);
  
      let hmicfg = data as {topic:string, payload:any};
      
      if(hmicfg.payload && hmicfg.payload.countrycode ) {
        that.setContent(hmicfg.payload.countrycode);         
      } else {
        that.setDefaultContent();       
      }            
    });  
  }  
}
