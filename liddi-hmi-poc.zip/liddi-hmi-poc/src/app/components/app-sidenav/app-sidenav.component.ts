import { Component, OnInit, EventEmitter, Output, ViewChild, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { EventService, EventServiceMessage } from '../../services/event.service';

@Component({
  selector: 'app-app-sidenav',
  templateUrl: './app-sidenav.component.html',
  styleUrls: ['./app-sidenav.component.css']
})
export class AppSidenavComponent implements OnInit {
  
  //Map event emitter output from parent app.component hosting mat-drawer-container to child app-sidenav component
  @Output("navigateBySidebar") navigateBySidebar: EventEmitter<any> = new EventEmitter();
  @ViewChild("hmimodalcontent") hmiModalContent: TemplateRef<any>;

  private readonly _eventService: EventService;
  private eventServiceSubscription;
  public componentReference: string = "AppSidenavComponent";

  public eventMessage: string;
 
  public defaultPickMode: string = "";

  public machineState: string = ""
  public navActionEnable: boolean = false;  

  constructor(public router: Router, eventService: EventService) { 
    this._eventService = eventService;
    this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});
  }
  
  buttonindex: number = 1;
 
  ngOnInit(): void {

  }

  ngOnDestroy(): void {
    //unsubscribe/dispose
    this.eventServiceSubscription.unsubscribe();
  }

  broadcastComponentMessage(message:EventServiceMessage = null): void {   
    //console.log(this.componentReference+' sent Message...', message); 
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      console.log(this.componentReference+' received Message...', message)

      switch(message.topic){
        case "nav-update-relay":
          this.navigateSetIndex(message.payload, false);
          break;   
        case "apptoolbar-heartbeat-relay":
          this.processHeartbeat(message.payload);
          this.capturePickMode(message.payload);
          break;                  
      }      
    }    
  }

  processHeartbeat(hb:any){
    console.log("processHeartbeat...");
    console.log(hb);
    try{
      
      if((hb !== undefined ) && (hb !== null)) {
        this.machineState = hb.machineState.toLowerCase();
        this.navActionEnable = ((this.machineState !== "locate") && (this.machineState !== "locatenoscan"));
      }
    } catch(err){
      console.log(err);
    } 
  }

  capturePickMode(hbPayload:any){
    //console.log(hbPayload);   
    this.defaultPickMode = (hbPayload.defaultPickMode) ? hbPayload.defaultPickMode : "unknown";
    console.log(this.defaultPickMode); 
  }

  navigateSetIndex(url:any, navigate:boolean=true){
    console.log("navigateSetIndex: "+url);

    //check if navigation allowed ("locate" or "locate no scan" may be active)
    if(!this.navActionEnable){
      //ToDo: Display option to confirm/recover

      return;
    }

    console.log("navActionEnable: "+this.navActionEnable);
    console.log("machineState: "+this.machineState );

    switch(url){
      case "/home":
      case "/workrequest-active":
      case "/direct-pick":
        this.buttonindex = 1;
        if(navigate) {
          var tgt_route = "/direct-pick";
          if(this.defaultPickMode === "normal"){ var tgt_route = "/home"; } 

          this.navigateFromSidebar(tgt_route);
        }
        break;
      case "/restock":
        this.buttonindex = 2;
        if(navigate) this.navigateFromSidebar("/restock");
        break;
      case "/other":
      case "/inventory": 
        this.buttonindex = 3;
        if(navigate) this.navigateFromSidebar("/other");
        break; 
      case "/settings": 
        this.buttonindex = 4;
        //this.navigateFromSidebar("/home");
        break; 
      case "/signout": 
        this.buttonindex = 5;
        if(navigate) this.navigateSplashIdle();
        break;                                          
      default:
        this.buttonindex = 0;
        console.log("AppSidenavComponent url: "+url);
        break;
    }
  }

  navigateHome(){
    this.router.navigateByUrl("/home"); 
  }

  navigateFromSidebar(route:string){
    this.router.navigateByUrl(route); 

    //emit event to parent app.module hosting mat-drawer-container
    this.navigateBySidebar.emit(); //toggle drawer/sidebar to close (if opened);
  }

  navigateSplashIdle(){
    this.router.navigateByUrl('/splashidle', { state: { splashType:"idlerHome"} }); 
   
    //Tell the app component to (force) close the sidebar
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "sidebar-closeforced", null, ['AppComponent']);
    this.broadcastComponentMessage(message);
  }

  shutdownInitiate(){
    //alert('NotImplemented!'); 
    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "shutdownInitiate", null, ['AppToolbarComponent']);
    this.broadcastComponentMessage(message);
  }

}
