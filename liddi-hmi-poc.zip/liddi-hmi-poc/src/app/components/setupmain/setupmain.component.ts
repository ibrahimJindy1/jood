import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-setupmain',
  templateUrl: './setupmain.component.html',
  styleUrls: ['./setupmain.component.css']
})
export class SetupmainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
