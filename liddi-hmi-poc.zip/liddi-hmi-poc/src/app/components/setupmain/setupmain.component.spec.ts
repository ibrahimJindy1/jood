import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SetupmainComponent } from './setupmain.component';

describe('SetupmainComponent', () => {
  let component: SetupmainComponent;
  let fixture: ComponentFixture<SetupmainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SetupmainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupmainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
