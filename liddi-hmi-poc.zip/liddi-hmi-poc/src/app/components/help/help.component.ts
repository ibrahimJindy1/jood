import { Component, OnInit } from '@angular/core';
import { DeviceApiService } from "../../services/device-api.service";
import { Router } from '@angular/router';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {
  loading:boolean = true;
  helpMessage:string = "Loading...";
  errState:boolean = false;

  errorCodes: string[] = [];
  
  phone:string = "1-855-888-8808";
  email:string = "admin@email.com";
  phoneImgUrl:string = "assets/images/qrcode_call_support.png";
  emailImgUrl:string = "assets/images/qrcode_email_support.png";  
  phoneSection:boolean = false;
  phoneImgSection:boolean = false;
  emailSection:boolean = false;
  emailImgSection:boolean = false;

  privacyShowLink:boolean = false;
  termsShowLink:boolean = false;

  systemID:string = "";
  registrationID:string = "";
  sysVersion:string = "";

  constructor(public router: Router, public restApi: DeviceApiService) { }
  //QR Code (content):
  //  https://imsinventory.com/pages/contact-us?s=imscabv2
  //  MATMSG:TO:admin@email.com;SUB:IMS Support;BODY:Need support on IMS cabinet.  Please contact us.;
  //  tel:1-800-888-8808

  ngOnInit(): void {
    this.getDeviceInfo();
    this.getHmiConfig();
    this.getDeviceErrors();
  }

  getDeviceInfo(){
    //gets the defice specific info from edge runtime to display software version(s)  
    this.errState = false;
    this.loading = true;
  
    let that= this;
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.helpMessage = "Sorry, something is not quite right.";}
    }, 6000);
  
    this.restApi.getDeviceInfo().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.helpMessage = "";
      //console.log(that);
      console.log(data);
  
      let devinfdata = data as {topic:string, payload:any};
      that.setFields(devinfdata.payload);
      // this.router.navigate(['/employees-list'])
    });  
  }

  getDeviceErrors(){
    //gets the defice specific info from edge runtime to display software version(s)  
    this.errState = false;
    this.loading = true;
  
    let that= this;
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.helpMessage = "Sorry, something is not quite right.";}
    }, 6000);
  
    this.restApi.getErrorQueue().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.helpMessage = "";
     
      //console.log(data);
  
      let deverrdata = data as {topic:string, payload:any};

      let deverr = "";
      
      if(deverrdata.payload.major.length > 0) {
        deverr= "Major ("+deverrdata.payload.major.length+"):";
        let errstr = deverrdata.payload.major.map((a) => " "+a).join(",");
        deverr+=errstr;

        that.errorCodes[0] = deverr.replace(/OErr-/g, '');
      }

      if(deverrdata.payload.minor.length > 0) {
        deverr= "Minor ("+deverrdata.payload.minor.length+"):";
        let errstr = deverrdata.payload.minor.map((a) => " "+a).join(",");
        deverr+=errstr;

        that.errorCodes[that.errorCodes.length] = deverr.replace(/OErr-/g, '');
      }      

      //console.log(that.errorCodes);

    });  
  }

  getHmiConfig(){
    //gets the hmi "help" page configuration 
    this.errState = false;
    this.loading = true;
  
    let that= this;
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.helpMessage = "Sorry, something is not quite right.";}
    }, 6000);
  
    this.restApi.getHmiConfig().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.helpMessage = "";
    
      //console.log(data);
  
      let hmicfg = data as {topic:string, payload:any};
      
      //display phone section details
      if(hmicfg.payload && hmicfg.payload.content.help.phone ) {
        that.phoneSection = true;
        if(hmicfg.payload.content.help.phone != "default"){
          that.phone = hmicfg.payload.content.help.phone;            
          that.checkImage('phoneImgUrl', hmicfg.payload.content.help.phoneImgUrl);  
        } else {
          that.phoneImgSection = true;
        }        
      } else {
        that.phoneSection = false;   
        that.phoneImgSection = false;     
      }
      
      //display email section details 
      if(hmicfg.payload && hmicfg.payload.content.help.email ) {
        that.emailSection = true;
        if(hmicfg.payload.content.help.email != "default"){
          that.email = hmicfg.payload.content.help.email; 
          that.checkImage('emailImgUrl', hmicfg.payload.content.help.emailImgUrl);
          that.emailImgSection = false;           
        } else {
          that.emailImgSection = true;
        }          
      } else {
        that.emailSection = false;   
        that.emailImgSection = false;          
      }   
      
      //display privacy/ToS links
      if(hmicfg.payload && hmicfg.payload.content.help.privacy && hmicfg.payload.content.help.privacy.display !== "none" ) {
        this.privacyShowLink = true;
      } else {
        this.privacyShowLink = false;
      }
      
      //display privacy/ToS links
      if(hmicfg.payload && hmicfg.payload.content.help.terms && hmicfg.payload.content.help.terms.display !== "none" ) {
        this.termsShowLink = true;
      } else {
        this.termsShowLink = false;
      }

    });  
  }

  setFields(devinfodata){
    this.systemID = devinfodata.systemID;
    this.registrationID = devinfodata.registrationID;
    this.sysVersion = (devinfodata.currentVersion ? devinfodata.currentVersion + " ":"")
    this.sysVersion += "(" + (devinfodata.ccsVersion ? devinfodata.ccsVersion : (devinfodata.firmwareVersion ? devinfodata.firmwareVersion : "")) + ")";
  }   
  
  checkImage(ref:string, src:string) {
    let img = new Image();
    
    img.src = src; 
 
    img.onload = () => {
      if(ref == 'emailImgUrl') { 
        this.emailImgSection = true;
        this.emailImgUrl = src;
      } else if(ref == 'phoneImgUrl') { 
        this.phoneImgSection = true;
        this.phoneImgUrl = src;}
        //console.log('loaded');
    }

    img.onerror = () => {
      if(ref == 'emailImgUrl') { 
        this.emailImgSection = false;
        //this.emailImgUrl = src;
      } else if(ref == 'phoneImgUrl') { 
        this.phoneImgSection = false;
        //this.phoneImgUrl = src;}
        console.log('bad image src - load failed.');
      }
    }
  }

  navigatePage(target:any){
    if(target == 'privacy') {this.router.navigateByUrl("/privacy-policy");}
    else if(target == 'tos') {this.router.navigateByUrl("/terms-of-service");}
  }

}
