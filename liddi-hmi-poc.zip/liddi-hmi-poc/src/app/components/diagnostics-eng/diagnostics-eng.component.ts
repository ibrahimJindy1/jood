import { Component, OnInit, AfterViewChecked, ElementRef, ViewChild } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { DeviceMessage } from 'src/app/models/DeviceMessage';
import { DeviceApiService } from '../../services/device-api.service';

@Component({
  selector: 'app-diagnostics-eng',
  templateUrl: './diagnostics-eng.component.html',
  styleUrls: ['./diagnostics-eng.component.css']
})
export class DiagnosticsEngComponent implements OnInit {

  constructor(public restApi: DeviceApiService ) { }

  loading: boolean = true;
  statMessage: string = "Loading...";
  errState: boolean = false;

  loggerdata: string = "";

  keepLedActive: boolean = true;
  //ledCycleBasePattern: string = "Red";

  ledCycleGroup = new FormGroup({
    ledCycleBasePattern: new FormControl()
  }); 

  @ViewChild('logggerContent') loggerContent: ElementRef;

  ngOnInit(): void {
    this.loadLog();

    this.ledCycleGroup.setValue({ledCycleBasePattern:'g'});
  }

  sendConfig(){
    return;
  }

  sendConfigId(){
    return;
  }

  loadLog(){
    return;
  }  

  ledCycleToggle(){
    return;
  }

  ledCycleSetLatch(latch: boolean){
    return;
  } 
  
  locateExpired(){
    return;
  }
  /*
  loadLog(){
    //gets the logger log from iot edge 
    this.errState = false;
    this.loading = true;
    this.loggerdata = "";
    this.statMessage = "Loading...";

    let that= this;  
    this.scrollBottom(true);  
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.statMessage = "Sorry, something is not quite right.";}
      }, 6000);
  
    this.restApi.getLog().subscribe((data: string) => {    
      that.loading = false;
      that.errState = false;    

      //console.log(data);
  
      //let logdata = data as {topic:string, payload:[]};
      that.loggerdata = data;
      //that.scrollBottom(false, that);
    });
  }

  scrollBottom(delay:boolean = false, it = this){
    if(delay) {
      //let it= this;
      setTimeout(function(){
        it.loggerContent.nativeElement.scrollTop = it.loggerContent.nativeElement.scrollHeight;
        }, 1500);
    } else {  
      this.loggerContent.nativeElement.scrollTop = this.loggerContent.nativeElement.scrollHeight;
    }    
  }

  sendConfig(){
    this.restApi.sendConfig().subscribe((data: DeviceMessage) => {    
      let msgdata = data;
      console.log(msgdata);   
    });
  }

  sendConfigId(){
    this.restApi.sendConfigId().subscribe((data: DeviceMessage) => {    
      let msgdata = data;
      console.log(msgdata);   
    });
  }

  locateExpired(){
    //gets the invenotry summary  configuration for both wifi and lan 
    this.errState = false;
    //this.loading = true;
  
    let that= this;
  
    setTimeout(function(){
      if (that.loading) {
        that.loading = false; 
        that.errState = true;
        that.statMessage = "Sorry, something is not quite right.";}
      }, 6000);
  
    this.restApi.locateExpired().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.statMessage = "";

      let msgdata = data as DeviceMessage;
      console.log(msgdata);   
    });  
  }


  ledCycleToggle(){
    let pattern:string = "pattern" + this.ledCycleGroup.get('ledCycleBasePattern').value;
    pattern+= (this.keepLedActive)?"1":"0";
    pattern = pattern.toLowerCase();
    //console.log("keepLedActive:"+this.keepLedActive);
    //console.log("ledCycleBasePattern:"+this.ledCycleGroup.get('ledCycleBasePattern').value);
    
    this.restApi.toggleLedCycle(pattern).subscribe((data: DeviceMessage) => {    
      let msgdata = data;
      console.log(msgdata);   
    });
  }

  ledCycleSetLatch(latch: boolean){
    this.keepLedActive = latch;
  }
  */
 
}
