import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DiagnosticsEngComponent } from './diagnostics-eng.component';

describe('DiagnosticsEngComponent', () => {
  let component: DiagnosticsEngComponent;
  let fixture: ComponentFixture<DiagnosticsEngComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DiagnosticsEngComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DiagnosticsEngComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
