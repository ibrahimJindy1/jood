import { Component, ElementRef, EventEmitter, OnInit, QueryList, ViewChildren, ViewEncapsulation, TemplateRef} from '@angular/core';
import { DeviceApiService } from '../../services/device-api.service';
import {Title} from "@angular/platform-browser";

import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';

import { DeviceMessage } from 'src/app/models/DeviceMessage';

import { FormGroup, FormControl, Validators } from '@angular/forms';
import { EventService, EventServiceMessage } from '../../services/event.service';


import { Router } from '@angular/router';

import { InventoryItem } from '../../models/Inventory';
import { HtmlUtils } from '../../shared/html-utils'

const ELEMENT_EMPTY: InventoryItem[] = [];

@Component({
  selector: 'app-inventory',
  templateUrl: './inventory.component.html',
  styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {
  private readonly _eventService: EventService;
  private eventServiceSubscription;
  public componentReference: string = "InventoryComponent";
  
  public eventMessage: string;

  public activeArea:string;
  public activeLocation:string;

  public loading: boolean = true;
  public invMessage: string = "Loading...";
  public errState: boolean = false;
 
  public displayedColumns: string[] = ['area', 'location',  'upc', 'subqty', 'status', 'expiration'];
  public dataSource: MatTableDataSource<InventoryItem> = new MatTableDataSource<InventoryItem>(ELEMENT_EMPTY);
  //public noData = this.dataSource.connect().pipe(map(data => data.length === 0));

  public filterText = new FormControl({value:'', disabled: false});
  public diopterFilterText = new FormControl('');
 
  public pickOrderArray = ELEMENT_EMPTY;
  public inventoryRefreshAllowNext: Date = new Date();
 
  public selectedRowIndex: string = "";

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChildren('input') inputs: QueryList<ElementRef>;

  constructor(public router: Router, public restApi: DeviceApiService, public htmlUtils: HtmlUtils, eventService: EventService) { 
    this._eventService = eventService;
    this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});

   }
   
  ngOnInit(): void {

    this.htmlUtils = new HtmlUtils;
    this.dataSource.paginator = this.paginator;

    //get inventory list
    this.loadInventory();
     
  }

  ngOnDestroy(): void {
    //unsubscribe/dispose
    this.eventServiceSubscription.unsubscribe();
  }

  ngAfterViewInit() {
    //Note: ngAfterViewInit fires on init but there may not be a data source ready/loaded
    this.configDatasource();
  }

  configDatasource(){
    if(this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;   
    }

    this.dataSource.filterPredicate = (data, filter) => {
      const dataStr = data; // data.position + data.details.name + data.details.symbol + data.details.weight;
      //console.log(dataStr,filter );
      
      let filterval = filter; //.split(':');

      let upcfilter = filterval; //(filterval[0]) ? filterval[0] : null;
      let locfilter = filterval; //(filterval[1]) ? filterval[1] : null;
      let statusfilter = filterval; //(filterval[1]) ? filterval[1] : null;

      let filtermatch = true;
      if(filterval.length > 0) filtermatch = false;

      let filtermatch1 = false;
      if(upcfilter && dataStr.upc) filtermatch1 = (dataStr.upc.trim().toLowerCase().includes(upcfilter.trim().toLowerCase()));

      let filtermatch2 = false;
      if(locfilter) filtermatch2 = (dataStr.location.trim().toLowerCase().includes(locfilter.trim().toLowerCase()));        

      let filtermatch3 = false;
      if(statusfilter) filtermatch3 = (dataStr.status.trim().toLowerCase().startsWith(statusfilter.trim().toLowerCase()));   

      return (filtermatch || filtermatch1 || filtermatch2 || filtermatch3); 
    } 
  }

  applyFilter(event: Event) {  
    this.setFilter();
  }

  setFilter(){

    let skuLocFilter = this.filterText.value;
     
    let filterValue = skuLocFilter.trim().toLowerCase(); 
    this.dataSource.filter = filterValue;

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();    
    }
  }

  loadInventory(){
    this.dataSource = new MatTableDataSource(ELEMENT_EMPTY);
   
    this.errState = false;
    this.loading = true;
  
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.invMessage = "Sorry, something is not quite right.";}
      }, 6000);

    this.restApi.getInventory().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.invMessage = "";
  
      let wrdata = data as {topic:string, payload:any};

      that.pickOrderArray = wrdata.payload.messageData;

      that.dataSource = new MatTableDataSource(that.pickOrderArray);

      //ngAfterViewInit not firing - safe call here instead
      that.configDatasource();

    });     
  }
  
  locateInventory(item:InventoryItem){

  }

  onRowClicked(row:InventoryItem) {
    console.log('Row clicked: ', row); //, ' this.lastMState:', this.lastMState);
    
    this.locateInventory(row);
  }

  refresh(){

      //on second/successive clicks clear/reload form  
      let refreshNow = Date.now();
      var diff = this.inventoryRefreshAllowNext.getTime() - refreshNow;
  
      if(diff < 0) {
        this.inventoryRefreshAllowNext = new Date(Date.now() + 1500);
        
        //get invenotry
        this.loadInventory();
      }
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      //console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "workrequestitems-locationledcmd":
          let ledcmd = message.payload.split("|");
          this.activeArea = ledcmd[0];
          this.activeLocation = ledcmd[1];
          break;
      }
    }    
  }  

}
