import { Component, OnInit } from '@angular/core';
import { EventService, EventServiceMessage } from '../../services/event.service';
import { Router } from '@angular/router';
import {environment} from '../../../environments/environment';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.css']
})
export class FooterComponent implements OnInit {
  private readonly _eventService: EventService;
  private eventServiceSubscription;
  public componentReference: string = "FooterComponent";

  public eventMessage: string;

  public currentApplicationVersion = environment.appVersion;
  public currentDeviceRuntimeVersion = "0.00";
  public productsDbVersion: string = "--"

  capacityDisplayMsg:String = "...";
  expiredDisplayMsg:String = "...";
  otherDisplayMsg:String = "0";

  constructor(public router: Router, eventService: EventService) { 
    this._eventService = eventService;
    this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});
  }

  ngOnInit(): void {

  }

  ngOnDestroy(): void {
    //unsubscribe/dispose
    this.eventServiceSubscription.unsubscribe();
  }

  broadcastComponentMessage(message:EventServiceMessage = null): void {   
    //console.log(this.componentReference+' sent Message...', message); 
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      //console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "apptoolbar-heartbeat-relay":
          this.updateFooterDisplay(message.payload);
          break;
      }
    }    
  }

  updateFooterDisplay(hbPayload:any){
    console.log("updateFooterDisplay");
    console.log(hbPayload);

    var expiredCount = (hbPayload.expiredCount || hbPayload.expiredCount == 0) ? hbPayload.expiredCount : -1;
    var occupiedCount = (hbPayload.occupiedCount || hbPayload.occupiedCount == 0) ? hbPayload.occupiedCount : -1;
    var otherCount = (hbPayload.otherCount || hbPayload.otherCount == 0) ? hbPayload.otherCount : -1;

    var capacity = (hbPayload.capacity || hbPayload.capacity == 0) ? hbPayload.capacity : -1;

    var occupiedPct = (capacity > 0) ? (occupiedCount / capacity ) * 100 : 0;

    this.capacityDisplayMsg = `${occupiedCount} of ${capacity} (${occupiedPct.toFixed(0)}%)` //"201 of 225 (89%)";  // = "... of ... (..%)"; 
    this.expiredDisplayMsg = expiredCount;
    this.otherDisplayMsg = otherCount;

    this.currentDeviceRuntimeVersion = hbPayload.systemVersion;
    this.productsDbVersion = hbPayload.productsDbVersion;

  }

}
