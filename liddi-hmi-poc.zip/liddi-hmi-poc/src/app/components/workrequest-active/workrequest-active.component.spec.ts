import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WorkrequestActiveComponent } from './workrequest-active.component';

describe('WorkrequestActiveComponent', () => {
  let component: WorkrequestActiveComponent;
  let fixture: ComponentFixture<WorkrequestActiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ WorkrequestActiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(WorkrequestActiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
