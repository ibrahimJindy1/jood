import { Component, ElementRef, OnInit, QueryList, ViewChildren } from '@angular/core';
import { DeviceApiService } from "../../services/device-api.service";
import { Router} from '@angular/router';

import {ViewChild, TemplateRef} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

import { PickOrder, PickOrderDetail, PickOrderDetailEvent, PickOrderEvent, PickProduct } from '../../models/PickOrder';
import { HtmlUtils } from '../../shared/html-utils'

import { NgbModal, NgbModalRef, ModalDismissReasons, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import { EventService, EventServiceMessage } from '../../services/event.service';
import { environment } from 'src/environments/environment';

import * as GS1Parser from 'gs1-barcode-parser-mod';
import { FormControl } from '@angular/forms';
import { DeviceMessage } from 'src/app/models/DeviceMessage';

const ELEMENT_EMPTY: PickOrderDetail[] = [];

@Component({
  selector: 'app-workrequest-active',
  templateUrl: './workrequest-active.component.html',
  styleUrls: ['./workrequest-active.component.css']
})
export class WorkrequestActiveComponent implements OnInit {
  private readonly _eventService: EventService;
  private eventServiceSubscription: any;
  public componentReference: string = "WorkrequestActiveComponent";

  public eventMessage: string;

  public modeDisplayTitle:string = "Pick Order";

  public backButtonOK: boolean = true;

  public activePickOrder: PickOrder;
  public activePickItem: PickOrderDetail;
  public activePickItemPickQty: number = 0;
  public activePickItemReturnQty: number = 0;
  public activePickItemClearQty: number = 0;  
  public activeArea: string;
  public activeLocation: string;

  public lastItemScan: any;
  public lastItemEntry: string;

  public lastPickItemGap: PickOrderDetail;
  public pickWarningMessage: string = "";

  public displayedColumns: string[] = ['manufacturer', 'descriptor',  'area', 'location', 'qty', 'status'];
  public dataSource: MatTableDataSource<PickOrderDetail> = new MatTableDataSource<PickOrderDetail>(ELEMENT_EMPTY);
  
  public pickOrderDetailArray = ELEMENT_EMPTY;

  public pageMessage: string = "";
  public errState: boolean = false;
  public loading: boolean = true;

  public selectedRowIndex: number = 0;
  public invalidUPCCount: number = 0;

  public modalRef: NgbModalRef;
  public modalYesNoRef: NgbModalRef;
  public modalRefArray: NgbModalRef[] = [];
  public modalTitle: string;
  public modalMessage: string;
  public modalButtonStyle: string;  
  public modalOkOption: boolean;
  public modalYesNoOption: boolean;
  public modalPinOption: boolean = false;  
  public modalCloseResult: string;
  public modalYesNoCloseResult: string;   

  public itemScan:PickProduct = new PickProduct;

  public pinCaptured: string = "";
  public pinDisplayMasked: boolean = true;
  public pinBackCount: number = 0;

  public forceManualMode: boolean = false;

  public modalShowErrorMsg: boolean = false;
  public errorMsg: string = "";

  public hasPending: boolean = false;
  public hasUnavailable: boolean = false;
  public hasUnavailableCycle: number = 0;

  public NormalMode:boolean = true;

  public itemPickQty = new FormControl({value:'', disabled: false});
  public itemReturnQty = new FormControl({value:'', disabled: false});  

  public machineState:string = "";
  public allowBackNavigation: boolean = true;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild("workrequestmodal") workrequestmodal: TemplateRef<any>;
  @ViewChild("workrequestconfirmmodal") workrequestconfirmmodal: TemplateRef<any>;
  @ViewChild("workrequestyesnomodal") workrequestyesnomodal: TemplateRef<any>;

  @ViewChildren('input') inputs: QueryList<ElementRef>;
  
  constructor(public router: Router, public restApi: DeviceApiService, private modalService: NgbModal, public htmlUtils: HtmlUtils, eventService: EventService) { 
    this._eventService =  eventService;
    this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});
   
    const navigation = this.router.getCurrentNavigation();

    if(typeof navigation.extras.state === "undefined") {
      this.navigateHome();
    }      
    else {
      this.activePickOrder = navigation.extras.state as PickOrder;
      if(this.activePickOrder.mode === "expired") {
        this.modeDisplayTitle = "Expired / Other";
        this.NormalMode = false;
        //this.backButtonOK = false;
      } else {
        //on normal mode allow back option
        //this.backButtonOK = true;
      }
    }      
   }

  ngOnInit(): void {
    this.htmlUtils = new HtmlUtils;
    this.loading = true;
    this.hasUnavailableCycle = 0; //on page open ensure the cycle is reset
  }

  ngAfterViewInit() {
    //Note: ngAfterViewInit fires on init but there may not be a data source ready/loaded
    //this.loadWorkRequestDetails();
    //this.configDatasource();
  }

  ngOnDestroy(): void {
    //unsubscribe/dispose    
    this.eventServiceSubscription.unsubscribe();
  }
  
  broadcastComponentMessage(message:EventServiceMessage = null): void {   
    //console.log(this.componentReference+' sent Message...', message); 
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      //console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "app-idle-state-start":
          //close any/all modals
          if(this.modalRef) this.modalRef.close();
          break;
        case "workrequestitems-refresh":
          this.loadWorkRequestDetails();
          break;
        case "workrequestitems-locationledcmd":
          this.setActiveItem(message.payload);
          break;
        case "workrequest-endlocate":
          this.navigateHome();
          break;
        case "apptoolbar-heartbeat-relay":
          this.processHeartbeat(message.payload);
          break;
        case "app-keyinput":
          console.log("work-req-ative received key:"+message.payload);
          this.processKeyedInput(message.payload); 
          break;            
        case "app-enteredinput":
          //this.navigateHome();
          if(message.payload.length > 1){
            console.log("received entered input (scanner):"+message.payload);
            this.processScannedInput(message.payload, "scanner");     
          }       
          break;          
      }
    }    
  }  

  processHeartbeat(hb:any){
    console.log("processHeartbeat...");
    console.log(hb);
    try{
      
      if((hb !== undefined ) && (hb !== null)) {
        this.machineState = hb.machineState.toLowerCase();

        //this.allowBackNavigation = (this.machineState !== "locatenoscan");
      }
    } catch(err){
      console.log(err);
    } 
  }

  navigateHome(){
    this.closeModals();
    this.router.navigateByUrl("/home");
  }

  navigateBack(){
    this.navigateHome();
  }

  configDatasource(){
    if(this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;   
    }

    if(this.hasUnavailable && !this.hasPending) {
      if(!this.hasUnavailableCycle) this.modalYesNoManager("msgAction", "UnavailableDetect", "");
      this.hasUnavailableCycle += 1; //prevent multiple checks on list refresh/update
    }    
  }

  closeModals(){
    //ToDO: Static Modals may require default option to be auto accepted
    this.modalManager("msgAction", "Close", "");
    this.modalYesNoManager("msgAction", "Close", "");
  }

  loadWorkRequestDetails(){
    this.dataSource = new MatTableDataSource(ELEMENT_EMPTY);
   
    this.errState = false;
    this.loading = true;
    this.hasPending = false;
    this.hasUnavailable = false;

    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.pageMessage = "Sorry, something is not quite right.";}
      }, 6000);

    this.restApi.getWorkRequestsItemsStaged().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";

      console.log(data);
  
      let wrdata = data as {topic:string, payload:any};

      that.pickOrderDetailArray = wrdata.payload.messageData;

      that.dataSource = new MatTableDataSource(that.pickOrderDetailArray);

      if(that.pickOrderDetailArray.find((po_item) => (po_item.status == "pending" || po_item.status == "expired" || po_item.status == "unknown" || po_item.status == "other" || po_item.status == "purge"))) that.hasPending = true;
      if(that.pickOrderDetailArray.find((po_item) => po_item.status == "unavailable")) that.hasUnavailable = true;
      //ngAfterViewInit not firing - safe call here instead
      that.configDatasource();

    });     

  }

  stageScannedItem(workrequestid, scanneditem, qty, area, location, gs1data){
    //s1: stage the scanned item on the back end
    this.errState = false;
    this.loading = true;
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
      }, 6000);

    this.restApi.putWorkRequestItemScanned(workrequestid, scanneditem, qty, area, location, gs1data).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
  
      let wrdata = data as {topic:string, payload:any};

      //that.pickOrderDetailArray = wrdata.payload.messageData;
    });
  }

  scannedItemConfirm(writem:PickOrderDetail, resolveItem:PickOrderDetailEvent){
    //send the confirmed item to the back end - to create produce and data transactions
    this.errState = false;
    this.loading = true;
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
      }, 6000);

    this.restApi.putWorkRequestScannedItem(writem).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
  
      let wrdata = data as {topic:string, payload:any};

      //that.pickOrderDetailArray = wrdata.payload.messageData;  
      //for s8 - after sending pick actions, confirm to resolve
      if(resolveItem) that.resolveOrderedItem(resolveItem);

    });
  }


  onRowClicked(row:PickOrderDetail){
    console.log("row clicked:", row);
    //this.activeArea = row.area;
    //this.activeLocation = row.location;

    //For testing
    //ELEMENT_DATA[this.selectedRowIndex].status = "completed";
    //this.selectedRowIndex = ELEMENT_DATA.findIndex((obj => obj.workqueueitemid == row.workqueueitemid));
  }

  setActiveItem(data:any) {
    //s2: upon sending staged item to backend (put), the item location is commanded to licght up, the command 
    //is echoed via the seb socket and processed here so that the corresponding row is highlighted
    let ledcmd = data.split("|");
 
    if(ledcmd.length > 1) {
      this.activeArea = ledcmd[0];
      this.activeLocation = ledcmd[1];

      let targetStatus = "pending";
      if(this.activePickOrder.mode === "expired")
      { 
        this.selectedRowIndex = this.dataSource.data.findIndex((obj => ((obj.area === this.activeArea)&&(obj.location === this.activeLocation)&&(obj.status === "expired" || obj.status === "unknown" || obj.status === "other" || obj.status === "purge"))));
      } else
        this.selectedRowIndex = this.dataSource.data.findIndex((obj => ((obj.area === this.activeArea)&&(obj.location === this.activeLocation)&&(obj.status === targetStatus))));

      if(!(this.selectedRowIndex === -1)){
        this.activePickItem =  this.dataSource.data[this.selectedRowIndex]; 

        this.itemPickQty.setValue(this.activePickItem.qty);
        this.itemReturnQty.setValue(this.activePickItem.qtymax - this.activePickItem.qty || 0);
        this.pickWarningMessage = "";

        console.log("targetUPC: "+this.activePickItem.upc);
        //console.log(this.activePickItem);
      } else {
        this.activeArea = "";
        this.activeLocation = "";

        console.log("Item (location) not in pick order detail.");
      }  
    }
  }

  userSlotEmpty(){
    //open the slot empty confirm dialogue
    //console.log("userSlotEmpty clicked.");
    this.modalManager("msgAction", "userSlotEmpty", "");
  }

  confirmedSlotEmpty(eventCode = "userSlotEmpty", area=this.activeArea, location=this.activeLocation){    

        //send the confirmed item to the back end - to create produce and data transactions to empty the invenotry for the slot 
        this.errState = false;
        this.loading = true;
        let that = this;    
      
        setTimeout(function(){
          if (that.loading) {
            //that.loading = false; 
            that.errState = true;
            that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
          }, 6000);

        let invref = {area:area, location:location, eventCode:eventCode};
    
        this.restApi.putInventorySlotEmpty(invref).subscribe((data: {}) => {    
          that.loading = false;
          that.errState = false;
          that.pageMessage = "";
      
          let invdata = data as {topic:string, payload:any};
    
          //that.pickOrderDetailArray = wrdata.payload.messageData;
        
    
        });

  }

  userManualEntry(){
    //open the upc manual entry dialogue
    console.log("userManualEntry clicked.");

    this.pinCaptured = ""; //clear the captured text

    this.modalManager("msgAction", "userManualEntry", "");
  }

  processKeyedInput(key:string){
  //Using the single key(ed) input for demo/testing
  //
  //  let simscan = null;
  //
  //  if(this.activePickItem && this.activePickItem.upc)
  //    simscan = this.activePickItem.upc;      
  //
  //  switch(key){
  //    case "G":
  //    case "g":  
  //    case "A":
  //    case "a":
  //      //simulate a good scan from scanner          
  //      if(simscan){
  //        simscan = "01"+simscan;
  //        console.log("processKeyedInput (emulate GOOD scan):"+simscan);
  //        this.processScannedInput(simscan, "scanner"); 
  //      }              
  //      break;
  //    case "B":
  //    case "b":          
  //    case "Z":
  //    case "z":
  //      //simulate a bad scan from scanner  
  //      if(simscan){
  //        simscan = "01"+simscan;
  //        simscan = simscan.slice(0, -1) + '0';
  //        console.log("processKeyedInput (emulate BAD scan):"+simscan);
  //        this.processScannedInput(simscan, "scanner");           
  //      } 
  //      break;  
  //    case "M":
  //    case "m":
  //    case "X":
  //    case "x":
  //      //simulate manual entry (partial)        
  //      if(simscan){
  //        simscan = simscan.slice(0, -1);
  //        console.log("processKeyedInput (emulate partial manual entry):"+simscan);
  //        this.pinCaptured = simscan;          
  //      } 
  //      break;     
  //    case "R":
  //    case "r":
  //      //reset the demo inventory and workrequests
  //      simscan = "-"; //prevents warning message
  //      console.log("processKeyedInput (emulate DEMO Reset)");
  //      let demoMsg:DeviceMessage = new DeviceMessage("Reset", {prodEnv:environment.production});
  //      
  //      this.restApi.postDemoAction(demoMsg).subscribe((response: {}) => {    
  //        console.log(response);
  //      });        
  //      break;  
  //    case "Y":
  //    case "y":
  //    case "N":
  //    case "n":
  //      //simulate LLISA response on resolution request
  //      //yes = in stock found
  //      //no  = out of stock
  //      simscan = "-"; //prevents warning message
  //      
  //      let option = true; //for yes
  //      if(key == "n" || key =="N") option = false;
  //      
  //      console.log("processKeyedInput (emulate LLISA "+(option?"YES":"NO")+" Response)");
  //      let demoMsgNo:DeviceMessage = new DeviceMessage("LLISAReply", {prodEnv:environment.production, LLISAReply:option});
  //      
  //      this.restApi.postDemoAction(demoMsgNo).subscribe((response: {}) => {    
  //        console.log(response);
  //      });        
  //      break;                                    
  //    default:
  //      break;
  //  }
  //
  //  if(!simscan) console.log("processKeyedInput - warning: no active item/upc to emulate scan.");
  }

  processScannedInput(scan:string, mode:string = "scanner"){
    //s3: when an item is scanned (or manually keyed) and upon pressing (or sesning) 
    //the "Enter" key, the code is processed for match
    //
    //let's check if the scanned information is valid GS1 data, 
    //if keyed manually, the entry and target upc need to macth
    //if GS1 code is scanned then AI code 01 data upc value and target upc need to macth
  
    //mode:
    //  scanner- a GS1 string from barcode scanner
    //  manual - likely upc only, entered via keyboard/modal-keypad
  
    let scanGS1:any = null;
    let validUPC:boolean = false;
    let result:any = null;
    //let upc:string = "";
   
    //for testing:
    //if(mode !== "manual") {
    //  //scan = "01195011015300031714070410AB-123"; //bad scan
    //  scan = "01095011015300031723022810AB-123";   //good matching scan
    //  console.log("testing..." + scan);      
    //}
  
    this.lastItemScan = null;
    this.lastItemEntry = null;
  
    this.forceManualMode = false;
  
    this.itemScan = new PickProduct;
  
    if(mode === "scanner" && scan.length > 1){
      try{
        scanGS1 = GS1Parser.parseBarcode(scan);
        console.log(scanGS1);
        //console.log(this.activePickItem);      
  
        //tell the device service/api of the scanned item - staged - data event
        if(this.activePickItem !== undefined && this.activePickItem !== null) {
          this.stageScannedItem(this.activePickItem.workrequestid, scan, this.activePickItem.qty, this.activeArea, this.activeLocation, scanGS1); 
        } else {
          this.stageScannedItem(0, scan, 0, this.activeArea, this.activeLocation, scanGS1); 
        }
      }catch(err){
        console.log(err);
        let msgerr = "";
        if(typeof err.replace === 'function'){
          msgerr = err.replace(/\'/g,""); //ToDo: temp fix - need solution on server side - SQLite issue with message containing single quotes
        } else {
          if(err.message && (typeof err.message.replace === 'function')){
            msgerr = err.message.replace(/\'/g,"");
          } else {
            msgerr = "processScannedInput - unknown error.";
          }
        }
        
        //tell the device service/api of the scanned item/error - staged - for auditing - data event
        if(this.activePickItem !== undefined && this.activePickItem !== null) {
          this.stageScannedItem(this.activePickItem.workrequestid, scan, this.activePickItem.qty, this.activeArea, this.activeLocation, msgerr); 
        } else {
          this.stageScannedItem(0, scan, 0, this.activeArea, this.activeLocation, msgerr); 
        }
  
      }
  
      if(scanGS1 && (this.activePickItem !== undefined && this.activePickItem !== null)) {
        if(scanGS1.parsedCodeItems){    
  
          result = scanGS1.parsedCodeItems.find(obj => {
            return obj.ai === '01'
          });
  
          if(result && result.data) {
            this.itemScan.upc = result.data;
            if(result) validUPC = true;
            
            this.lastItemScan = scanGS1;            
          }
          
         //if(result.data) {
         //  upc = result.data;
         //  if(result) validUPC = true;
         //  this.lastItemScan = scanGS1;            
         //}
        }  
      } else {
        this.forceManualMode = true;
        console.log("bad 2-D scan or 1-D scan for upc.");
  
        //ensure scan is set to max 14 digits padded with leading 0's
        scan = scan.padStart(14, '0');
      }
  
    } else {
      //assume manual entry
      // the manual input is only checked if enough charcaters entered for upc --> 11+
      if(scan.length >= 11) {
        this.itemScan.upc = scan;
        validUPC = true;  
        this.lastItemEntry = scan;  
      }
    }
  
    if(this.forceManualMode || mode !== "scanner") {      
  
      console.log("assume manual entry.");    
      //assume manual entry
      // the manual input is only checked if enough charcaters entered for upc --> 11+
      if(scan.length >= 12) {
        this.forceManualMode = true;
  
        this.itemScan.upc = scan;
        validUPC = (scan !== '00000000000000');  
        this.lastItemEntry = scan;  
            
        this.itemScan.expiration = null;
        this.itemScan.serialnumber = null;
        this.itemScan.lot = null;
        this.itemScan.mfgdate = null;
      }
    }   
    
    console.log(this.itemScan);
  
    if(validUPC) {
      //let's check if the valid upc is the matching upc to allow qty confirmation
      if(this.checkUPCMatch(this.itemScan.upc)) {
        //if matched, then request user to confirm upc qty's (pick/return)
        //show ui to confirm quantities picked/returned
        //
        
        //if(this.directPickRequest.mode === "directPick"){
        //  //for expired the entire item will removed - no need to confirm
          this.activePickItem.qtypick = this.activePickItem.qtymax;
          this.activePickItem.qtyrtn = 0;
          this.activePickItem.status = "completed";
        //
        //  //send the confirmed item to the back end - to create produce and data transactions
        //  this.scannedItemConfirm(this.activePickItem);
        //} else {
          //normal/direcPick mode
          this.upcQtyConfirm();
        //}
  
      } else {
        //scanned/entered upc mismatch
        if(mode === "scanner"){
          //close any modals if opened - manual entry modal
          this.modalManager("msgClose", "", "");
  
          if(this.activeArea !== "" && this.activeLocation !== ""){
            //LLIDI Displays "Item Mismatch - Confirm Lens picked from [location]]"
            this.upcMismatchConfirmPick();
          } else {
            this.nothingStagedToPick();
          }
          
        } else {
          //manually entered via pin modal
          //manual entry modal is (assumed already) open - check this.modalRef
          this.upcMismatchErrorLabel("showErr");
          if(this.invalidUPCCount >= 3){
  
            //LLIDI Displays "Item Unreadable"
            //Technician Selects the “OK” Button and puts unreadable product in trash
            //Assume user pricked from correct slot - remove item from inventory
  
            this.upcUnreadableConfirmPick();            
  
            //test: this.modalYesNoManager("msgAction", "GenericOK", "ItemEntryTooManyAttempts - ToDo: Ask User to place in trash / Call BE to Empty Slot /");
          }
        }
  
      }
    } else {
  
      if(mode === "scanner") {
        //close any modals if opened - manual entry modal
        this.modalManager("msgClose", "", "");
        if(this.activePickItem === undefined || this.activePickItem === null)
          this.nothingStagedToPick();
        else
          this.modalYesNoManager("msgAction", "InvalidUPC", "");
      }
      
      console.log("invalid upc.");
    }
  }
  
  checkUPCMatch(upcEntry:string):boolean{
    //s4: check the entered/scanned upc macthes the expected target upc

    let match:boolean;   

    this.modalShowErrorMsg = false;
    this.errorMsg = ""

    if(upcEntry && (upcEntry === this.activePickItem.upc)) {
      console.log("upc MATCH! "+upcEntry);
     
      match = true;
      this.invalidUPCCount = 0;

    }
    else {
      match = false;      
      this.invalidUPCCount+=1;

      if(this.invalidUPCCount >= 3) 
      {
        this.invalidUPCCount = 3;        
      }  
      console.log("upc MIS-match! count:"+this.invalidUPCCount+" scan:"+upcEntry +" Expected:"+ this.activePickItem.upc);
    }

    return match;
  }

  upcUnreadableConfirmPick(){
    //After entering the upc manually wrong 3 times - instruct to dispose of item
    this.modalManager("msgClose", "", ""); // close the manual entry form
    this.modalYesNoManager("msgAction", "ItemUpcUnreadable", "");
  }

  upcUnreadableConfirmed(option:string){
    //After entering the upc manually wrong 3 times and confirming dispose - then empty the slot
    this.confirmedSlotEmpty("itemUnreadable");
  }

  upcMismatchConfirmPick(){
    //LLIDI Displays "Item Mismatch - Confirm Lens picked from [location]]" (Yes/No - Static) = ItemScanMismatch
    this.modalYesNoManager("msgAction", "ItemScanMismatch", "");
    
    //ToDo: timeout 10 seconds then assume YES/YES
  }

  nothingStagedToPick(){
    //LLIDI Displays "Nothing to Pick - Warning"
    this.modalYesNoManager("msgAction", "NothingToPick", "");
    
    //ToDo: timeout 10 seconds then assume YES/YES
  }

  upcMismatchConfirmed(option:string){
    if(option == "Yes"){
      //On YES: LLIDI Displays "Place Item in Restock Bin" - user picked from the active slot but invenotry is not correct - clear slot invenotyr data
      this.modalManager("msgAction", "placeItemOnRestock", "");

    } else {
      //On NO : LLIDI Displays Message "Return Picked Lens to Previous Slot" - user picked from another slot try again
      this.modalManager("msgAction", "returnPickedLens", "");

    }
  } 

  upcMismatchConfirmedPost(option:string){
    if(option == "Yes"){
      //On YES: LLIDI Displays "Place Item in Restock Bin" - user picked from the active slot but invenotry is not correct - clear slot invenotyr data
      //THEN: Clear the slot inventory (and generate transactions : itemMisplaced)
      this.confirmedSlotEmpty("itemMisplaced");

    } else {
      //On NO : LLIDI Displays Message "Return Picked Lens to Previous Slot" - user picked from another slot try again
      //THEN: generate data transaction : itemPickIncorrect (note: location may be inferred if item scan 
      //      had a serial number or IF it is the ONLY item (upc) that exists in inventory)

      let pickItemEvent:PickOrderEvent = {
        workrequest:this.activePickOrder, 
        workrequestitems:[this.activePickItem], 
        eventCode:"itemPickIncorrect", 
        eventData:{scan:this.lastItemScan, entry:this.lastItemEntry}
      };

      this.sendWorkRequestEvent(pickItemEvent);
    }
    
    //ToDo: clear timeout (from upcMismatchConfirmPick) after assuming YES
  } 

  sendWorkRequestEvent(dataItem:PickOrderEvent){
    //send request to generate event/data transaction record
    this.errState = false;
    this.loading = true;
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
      }, 6000);

    this.restApi.putWorkRequestEvent(dataItem).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
  
      let wrdata = data as {topic:string, payload:any};

      //that.pickOrderDetailArray = wrdata.payload.messageData;  

    });
  }

  upcMismatchErrorLabel(option:string = "showErr"){
    if(option === "showErr") {
      this.modalShowErrorMsg = true;
      this.errorMsg = "Incorrect UPC entered"+((this.invalidUPCCount>1)?' (x'+this.invalidUPCCount+')':'');
    } else {
      this.modalShowErrorMsg = false;
      this.errorMsg = "";
    }
  }

  upcQtyConfirm(){
    //s5: display confirm modal to obtain user pick and return quantities for scanned upc
    this.modalTitle = "Scanned Item:";
    
    this.activePickItemPickQty = this.activePickItem.qty;
    this.activePickItemReturnQty = this.activePickItem.qtymax - this.activePickItem.qty;
    this.activePickItemClearQty = 0;

    //console.log("this.activePickItem.qtymax:this.activePickItem.qty   "+this.activePickItem.qtymax + ":"+this.activePickItem.qty);

    //close any prior modal dialogues
    if(this.modalRef) this.modalRef.close();

    //reset the invalid count
    this.invalidUPCCount = 0;

    this.modalRef = this.modalService.open(this.workrequestconfirmmodal, { centered:true, size:'lg', backdrop:'static' }); //
    
  }

  adjustConfirmQty(group:string = "pick", action:string){
    //s6: adjust quantities during confirm stage

    if(group == "return") {
      if(action == "sub") {
        this.activePickItemReturnQty-= 1;
      } else {
        //assumes return:add action
        this.activePickItemReturnQty+= 1;
      }
      //can not return more than qtymax (inventory) minus pick
      var returnmax = this.activePickItem.qtymax - this.activePickItemPickQty;
      if (this.activePickItemReturnQty > returnmax) this.activePickItemReturnQty = returnmax;

    } else {
      //assumes pick group
      if(action == "sub") { 
        if((this.activePickItemPickQty > 1) && (this.activePickItemPickQty <= this.activePickItem.qtymax)){
          if(this.activePickItemPickQty > 0) this.activePickItemReturnQty+= 1;
          this.activePickItemPickQty-= 1;          
        }       

      } else {
        //assumes pick:add action
        if((this.activePickItemPickQty > 0) && (this.activePickItemPickQty < this.activePickItem.qtymax)){
          this.activePickItemPickQty+= 1;
          this.activePickItemReturnQty-= 1;          
        }
      } 
    }

    if(this.activePickItemPickQty <= 0) this.activePickItemPickQty = 0;
    if(this.activePickItemReturnQty <= 0) this.activePickItemReturnQty = 0;

    this.itemPickQty.setValue(this.activePickItemPickQty);
    this.itemReturnQty.setValue(this.activePickItemReturnQty);

    //if the pick and return do not match what is available then need to clear difference
    //user has determined there is a sync issue and needs to be corrected
    //    this.activePickItem.qtymax    --- inventory last reported available for pick
    //    this.activePickItemPickQty    --- quantity intended to be picked
    //    this.activePickItemReturnQty  --- quantity intended to be returned
    if(this.activePickItem.qtymax !== (this.activePickItemPickQty+this.activePickItemReturnQty)){
      this.activePickItemClearQty = this.activePickItem.qtymax - (this.activePickItemPickQty+this.activePickItemReturnQty);
      console.log("Need to sync... will remove an additional "+ this.activePickItemClearQty);
    }

    if(this.activePickItemPickQty < this.activePickItem.qty)
      this.pickWarningMessage = "Quantity picked is less than ordered";
    else if(this.activePickItemPickQty > this.activePickItem.qty)
      this.pickWarningMessage = "Quantity picked is more than ordered";
    else
      this.pickWarningMessage = "";
  }

  upcInfoConfirmed(){
    //s7: user confirmed pick and return qty's from confirm modal
    //close modal and continue to next item
    if(this.modalRef) this.modalRef.close();  

    this.activePickItem.qtypick = this.activePickItemPickQty;
    this.activePickItem.qtyrtn = this.activePickItemReturnQty;
    this.activePickItem.qtyclear = this.activePickItemClearQty;
    this.activePickItem.status = "completed";

    if(this.activePickItem.qtypick < this.activePickItem.qty) {
      this.lastPickItemGap = new PickOrderDetail;

      this.lastPickItemGap.area = this.activePickItem.area;
      this.lastPickItemGap.descriptor = this.activePickItem.descriptor;
      this.lastPickItemGap.location = this.activePickItem.location;
      this.lastPickItemGap.manufacturer = this.activePickItem.manufacturer;
      this.lastPickItemGap.qty = (this.activePickItem.qty - this.activePickItem.qtypick); //if user accepts will create detail record with remaining quantity
      this.lastPickItemGap.sku = this.activePickItem.sku;
      this.lastPickItemGap.upc = this.activePickItem.upc;
      this.lastPickItemGap.workrequestid = this.activePickItem.workrequestid;

      //s8 the picked qty was less than what was ordered - is it ok?
      this.modalManager("msgStatic", "notOrderedQty", "");
    } else {
      //send the confirmed item to the back end - to create produce and data transactions
      this.scannedItemConfirm(this.activePickItem, null);
    }  
  }

  notOrderedQtyConfirmed(option:string){

    console.log("notOrderedQtyConfirmed with "+option);

    //stage the reconcile/resolve record to be sent
    let pickItemEvent:PickOrderDetailEvent = new PickOrderDetailEvent(this.lastPickItemGap);

    pickItemEvent.status = "resolved";
    pickItemEvent.area = null;
    pickItemEvent.location = null;
    pickItemEvent.eventData = {qtyreq:this.activePickItem.qty, qtymax:this.activePickItem.qtymax, qtypick:this.activePickItem.qtypick, qtyrtn:this.activePickItem.qtyrtn};

    if( option === "Yes" ) {
      //LLIDI updates inventory (done via previous call to scannedItemConfirm) and...
      //Sends LLISA an "Error" Notification (data transaction)
      //QtyMismatchGapOk - “Quantity available in Slot Less than Current Inventory expected in Slot xxxx – Order OK” 

      //call backend for:
      //  - workqueue item creation use this.lastPickItemGap - qty is remaining qty with status resolved;  
      //  - data transaction - use this.lastPickItemGap (ensures item is in fact item for which event was triggered)   

      pickItemEvent.eventCode = "QtyMismatchGapOk";
      //this.resolveOrderedItem(pickItemEvent);
    } else {
      //No
      //LIDI updates inventory (done via previous call to scannedItemConfirm) and...
      //Sends LLISA an "Error" Notification – (data transaction)
      //QtyMismatchGapNewOrder - Quantity available in Slot Less than Current Inventory expected in Slot xxxx –- Order not OK – Create new order for Lenses 
      //Required to fill order.

      //IMPORTANT: Allow the normal process to detect unavailable and contact LLISA

      //ToDo: call backend and create new order to cover for qty gap - use this.lastPickItemGap
      //Note: requires timeout or resposne from LLISA 
      
      //this.modalYesNoManager("msgAction", "GenericOK", "QtyMismatchGapNewOrder - ToDo: Contact LLISA for new Order (ONLY IF Unavailable)");
      
      //call backend for:
      //  - data transaction - use this.lastPickItemGap (ensures item is in fact item for which event was triggered)   

      pickItemEvent.eventCode = "QtyMismatchGapNewOrder";
      //this.resolveOrderedItem(pickItemEvent);
    }
    this.scannedItemConfirm(this.activePickItem, pickItemEvent);
  }

  resolveOrderedItem(writem:PickOrderDetail){
    //send the resolved item to the back end - to create resolved detail record and data transaction
    this.errState = false;
    this.loading = true;
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.pageMessage = "Sorry, something is not quite right.  Scan item not set.";}
      }, 6000);

    this.restApi.putWorkRequestItemResolved(writem).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
  
      let wrdata = data as {topic:string, payload:any};

      //that.pickOrderDetailArray = wrdata.payload.messageData;  
      //send the confirmed item to the back end - to create produce and data transactions
    });
  }

  requestItemResolution(){
    //send request to back end to resolve unavailable items
    //build item list/event

    //get all unavailable items
    let unavailableItems = this.pickOrderDetailArray.filter((item) => (item.status == "unavailable"));;

    let pickItemsUnavailableEvent:PickOrderEvent = {
      workrequest:this.activePickOrder, 
      workrequestitems:unavailableItems, //UNAVAIABLE items here for LLISA to process
      eventCode:"ItemResolutionRequest", 
      eventData:{}
    };

    //initialize modal features    
    this.errState = false;
    this.loading = true;
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        that.loading = false; 
        that.errState = true;
        that.pageMessage = "Sorry, something is not quite right. LLISA is not Responding!";
        that.modalMessage = "There was no response from the local device-to-cloud service.";
       }
      }, 12000);

    this.restApi.putWorkRequestResolution(pickItemsUnavailableEvent).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.pageMessage = "";
      
      let wrdata = data as {topic:string, payload:any};

      if(wrdata.payload.messageData) {
        that.modalMessage = wrdata.payload.messageData.response_message;
        that.loadWorkRequestDetails();
      }
      else that.modalMessage = "The response to the request was not valid.  Try again.";      

    });
  }

  pinCode(pin:string){
    switch(pin){
      case "Enter":
        this.pinSubmit();
        break;
      case "Back":
        this.pinBackCount+=1;
        this.modalShowErrorMsg = false;
        if(this.pinBackCount>5) {
          this.pinCaptured = "";
          this.pinBackCount = 0;
        }
        if(this.pinCaptured.length > 0) this.pinCaptured = this.pinCaptured.slice(0, -1);
        break;
      default:
        if(this.pinCaptured.length < 14)
        {
          this.pinCaptured+= pin;

          this.pinBackCount = 0;
        }
        break;
    }
    
  }
  
  pinSubmit(){
    var pinCapturedScannedUPC = this.pinCaptured.padStart(14, '0');
    
    this.processScannedInput(pinCapturedScannedUPC, "manual");
  }

  modalManager(action = "default", option, msg) {
    let openModal = true;
    
    this.modalButtonStyle = "normal";
    this.modalOkOption = true;
    this.modalYesNoOption = !this.modalOkOption;
    this.modalPinOption = false;

    if(option !== "userManualEntryOnError"){
      //clear for all others
      this.modalShowErrorMsg = false;
      this.errorMsg = "";      
    }

    //close any prior modal dialogues
    if(this.modalRef) this.modalRef.close();

    //console.log("option: ", option);
    switch(option){
      case "userSlotEmpty":
          this.modalTitle = "Slot Empty";
          this.modalMessage = "Press OK to confirm slot is empty.";   
          this.pinCaptured = "";  
          this.modalOkOption = true; 
          this.modalYesNoOption = false;   
        break;
      case "notOrderedQty":
          this.modalOkOption = false;
          this.modalYesNoOption = true;
          this.modalTitle = "Quantity OK?";
          this.modalMessage = "Will picked lenses meet doctor's requirements?";   
          this.pinCaptured = "";    
        break;        
      case "userManualEntry":
      case "userManualEntryOnError":        
        this.modalOkOption = false;
        this.modalYesNoOption = false;
        this.modalPinOption = true;
        this.pinDisplayMasked = false;
        this.modalTitle = "Manual Entry";
        this.modalMessage = "Enter UPC:";         
        break; 
      case "tooManyScanAttempt":
        this.modalTitle = "Proceed";
        this.modalMessage = msg;   
        this.pinCaptured = "";  
        this.modalOkOption = true;
        this.modalYesNoOption = false;
        break;
      case "returnPickedLens":
        this.modalTitle = "Return Lens";
        this.modalMessage = "Return picked lens to previous slot";   
        this.modalOkOption = true;
        this.modalYesNoOption = false; 
        break;
      case "placeItemOnRestock":
        this.modalTitle = "Move to Restock";
        this.modalMessage = "Place item in Restock bin";   
        this.modalOkOption = true;
        this.modalYesNoOption = false;  
        break;            
      case "GenericOK":
        this.modalTitle = "Proceed";
        this.modalMessage = msg;   
        this.pinCaptured = "";  
        this.modalOkOption = true;
        this.modalYesNoOption = false;  
        console.log("GenericOK");    
        break;      
      default:
        openModal = false; //no valid option
        break;
    }

    if(openModal) {
      let that = this;

      const modalOptions: Record<string, any> = {
        centered: true,
      };
      
      if(action == "msgStatic") modalOptions.backdrop = 'static' 
      //modalOptions.keyboard = false; //closable by hitting the ESC key if true

      this.modalRef = this.modalService.open(this.workrequestmodal, modalOptions);   
      this.modalRefArray.push(this.modalRef);

      this.modalRef.result.then((result) => {
        this.modalCloseResult = `Closed with: ${result}`;
        //Ok/Continue or Yes/No
        if(result) {
          switch(this.modalTitle){
            case "Slot Empty":
              this.confirmedSlotEmpty();
              break;
            case "Quantity OK?":
              this.notOrderedQtyConfirmed(result);
              break;
            case "Move to Restock":
              this.upcMismatchConfirmedPost("Yes");
              break;               
            case "Return Lens":
              this.upcMismatchConfirmedPost("No");
              break;                                  
              
          }
          console.log("modalCloseResult:", result);        
        }
      }, (reason) => {
        this.modalCloseResult = `Dismissed ${this.getDismissReason(reason)}`;
        
        console.log("modalCloseResult:", this.modalCloseResult);
      
      });
    }
  } 

  private getDismissReason(reason: any): string {    
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }  

  modalYesNoHandler(option:string){
    if(this.modalYesNoRef) this.modalYesNoRef.close();

    console.log("modalYesNoHandler with "+option);

    switch(this.modalTitle) {
      case "Quantity OK?":
        this.notOrderedQtyConfirmed(option);
      break;
    case "Scanned Item Mismatch":
        this.upcMismatchConfirmed(option);
      break; 
    case "UPC Unreadable":
        this.upcUnreadableConfirmed(option);
      break; 
    }
  }

  modalYesNoManager(action, option, msg) {
    let openModal = true;
    
    this.modalButtonStyle = "normal";
    this.modalOkOption = false; //default to Yes/No option

    //close any prior modal dialogues
    if(this.modalYesNoRef) this.modalYesNoRef.close();

    //console.log("option: ", option);
    switch(option){
      case "QtyMismatchGapOk":
          this.modalTitle = "Request Complete";
          this.modalMessage = "The itme will be marked completed.  No new order";  
          this.modalOkOption = true;
          this.modalYesNoOption = false;           
        break; 
      case "QtyMismatchGapNewOrder":
          this.modalTitle = "Request Complete with New Order";
          this.modalMessage = "The item will be marked completed.  A new order will be generated.";   
          this.modalOkOption = true;
          this.modalYesNoOption = false;          
        break;      
      case "ItemScanMismatch":
          this.modalTitle = "Scanned Item Mismatch";
          this.modalMessage = "Confirm Lens picked from " + this.activeArea + "-" + this.activeLocation; 
          this.modalOkOption = false;
          this.modalYesNoOption = true;              
        break;  
      case "InvalidUPC":
          this.modalTitle = "UPC Invalid";
          this.modalMessage = "The UPC entered/scanned is invalid.  Please try again."; 
          this.modalOkOption = true;
          this.modalYesNoOption = false;              
        break; 
      case "ItemUpcUnreadable":
          this.modalTitle = "UPC Unreadable";
          this.modalMessage = "The UPC is marked unreadable please discard."; 
          this.modalOkOption = true;
          this.modalYesNoOption = false;              
        break;                  
      case "UnavailableDetect":
          this.modalTitle = "Searching Inventory...";
          this.modalMessage = "Please wait while we check other units…"; 
          this.modalOkOption = true;
          this.modalYesNoOption = false;  
          this.requestItemResolution();
        break;                       
      case "GenericOK":
        this.modalTitle = "Continue...";
        this.modalMessage = msg;   
        this.pinCaptured = "";  
        this.modalOkOption = true;
        console.log("GenericOK-YesNo" + openModal);
        break;
      default:
        openModal = false; //no valid option
        break;
    }

    if(openModal) {
      let that = this;

      this.modalYesNoRef = this.modalService.open(this.workrequestyesnomodal, { centered:true, backdrop:'static' }); // 
      this.modalRefArray.push(this.modalYesNoRef);

      this.modalYesNoRef.result.then((result) => {
        this.modalYesNoCloseResult = `Closed with: ${result}`;
        //Yes/No
        if(result) {
          console.log("modalYesNoCloseResult:", result);        
        }
      }, (reason) => {
        this.modalYesNoCloseResult = `Dismissed ${this.getDismissReason(reason)}`;        
        console.log("modalYesNoCloseResult:", this.modalYesNoCloseResult);      
      });
    }    
  }  
}


/*
 
ITEM STATES:

* = End States

I1  - Pending                - normal(white) if active (green)
I2* - Complete               - light grey
I3  - Unavailable            - light grey
I4* - Resolved               - light grey
I5* - UnavailableResolved    - light grey
I6* - Inactive               - light grey

Active: The slot led is actively lit

Option: PendingActive - workrequestdetialid for item with led lit

activeArea - the detail row with matching drawer of lit led
activeLocation - the detail row with matching location of lit led

((modalButtonStyle=='danger')?'btn-danger':'btn-secondary')+((!modalOkOption)?' hideButton':'')
((row.area == activeArea && row.location == activeLocation) ? 'pending-active-state' : ((row.status == 'pending') ? 'pending-state' : 'pending-non-state'))

*/