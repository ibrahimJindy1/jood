import { Component, OnInit, Input, ɵConsole } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { DeviceApiService } from "../../services/device-api.service";
import { NetworkConfig } from './../../models/NetworkConfig'
import { identifierModuleUrl } from '@angular/compiler';
import { of } from 'rxjs';

const ipPattern = "^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";

@Component({
  selector: 'app-network-editor',
  templateUrl: './network-editor.component.html',
  styleUrls: ['./network-editor.component.css']
})
export class NetworkEditorComponent implements OnInit {
  
 // @Input() networkDetails = [{
 //   id: "wifi",
 //   network: "",
 //   primary: true,
 //   config: {
 //       ssid: "",
 //       pass: "",
 //       type: "",       
 //       ip: "",
 //       mask: "",
 //       gwy: ""
 //   }
 // }, {
 //   id: "lan",
 //   network: "",
 //   primary: false,
 //   config: {
 //       ssid: null,
 //       pass: null,
 //       type: "",       
 //       ip: "",
 //       mask: "",
 //       gwy: ""
 //   }
 // }];

  constructor(
    public restApi: DeviceApiService, 
    public router: Router
  ) { 
    //of(this.loadSSIDList()).subscribe(wifilist => {
    //  this.wifissidlist = wifilist;
    //  //this.form.controls.orders.patchValue(this.orders[0].id);
    //});
  }


  loading:boolean = true;
  netCfgMessage:string = "Loading...";
  errState:boolean = false;

  wifissidlist:any = {topic:"", payload:[]};

  NetworkOptions: any = ["WiFi", "LAN"]
  NetworkScheme: string = "none"; //wifi, lan, wifilan, (Empty)||none

  wifitype:string;
  lantype:string;

  netCfgModel = new NetworkConfig();
  primaryNetwork = new FormControl(); 
  wifiSsidSelect = new FormControl(); 

  networkConfigForm = new FormGroup({
    wifissid: new FormControl(''),
    wifipass: new FormControl(''),
    wifitype: new FormControl(''),
    wifiip: new FormControl('', Validators.pattern(ipPattern)),
    wifimask: new FormControl('', Validators.pattern(ipPattern)),
    wifigwy: new FormControl('', Validators.pattern(ipPattern)),

    lanssid: new FormControl(''),
    lanpass: new FormControl(''),
    lantype: new FormControl(''),
    lanip: new FormControl('', Validators.pattern(ipPattern)),
    lanmask: new FormControl('', Validators.pattern(ipPattern)),
    langwy: new FormControl('', Validators.pattern(ipPattern))
  });

  ngOnInit() {
    this.getConfig();
    this.loadSSIDList();

    this.networkConfigForm.get('wifitype').valueChanges.subscribe(val => {
      this.wifitype = val;

      if(val=="DHCP"){
        this.networkConfigForm.controls['wifiip'].disable();
        this.networkConfigForm.controls['wifimask'].disable();
        this.networkConfigForm.controls['wifigwy'].disable();
      } else {
        this.networkConfigForm.controls['wifiip'].enable();
        this.networkConfigForm.controls['wifimask'].enable();
        this.networkConfigForm.controls['wifigwy'].enable();
      }
    });

    this.networkConfigForm.get('lantype').valueChanges.subscribe(val => {
      this.lantype = val;

      if(val=="DHCP"){
        this.networkConfigForm.controls['lanip'].disable();
        this.networkConfigForm.controls['lanmask'].disable();
        this.networkConfigForm.controls['langwy'].disable();
      } else {
        this.networkConfigForm.controls['lanip'].enable();
        this.networkConfigForm.controls['lanmask'].enable();
        this.networkConfigForm.controls['langwy'].enable();
      }
    });
    
  }

changeNetwork(e){
  //console.log(e.target.value);
  //console.log(e);
}
 
wifiSelectChange(){
  //on UI, handles the selection of SSID 
  let wifisel = this.wifiSsidSelect.value;
  this.networkConfigForm.controls['wifissid'].setValue(wifisel);
}
  
getConfig(){
  //gets the network configuration fro both wifi and lan 
  this.errState = false;
  this.loading = true;

  let that= this;

  setTimeout(function(){
    if (that.loading) {
      //that.loading = false; 
      that.errState = true;
      that.netCfgMessage = "Sorry, something is not quite right.";}
    }, 6000);

  this.restApi.getNetworkConfig().subscribe((data: {}) => {    
    that.loading = false;
    that.errState = false;
    that.netCfgMessage = "";
    //console.log(that);
    console.log(data);

    let ncfgdata = data as {topic:string, payload:any};
    that.setForm(ncfgdata.payload);
    // this.router.navigate(['/employees-list'])
    });

  }

  loadSSIDList(){
    //On start up, load list of SSID's for selection
    this.restApi.getWifiSSIDList().subscribe((data: {}) => { 
     this.wifissidlist = data as {topic:string, payload:any};
    });
  }

  setForm(netcfgdata){
    //sets the form fields based on configuration 
    let wifidata;
    let landata; 

    if(netcfgdata.interface[0].id == "wifi") {
      wifidata = netcfgdata.interface[0];
    } else if(netcfgdata.interface[1].id == "wifi") {
      wifidata = netcfgdata.interface[1];
    }

    if(netcfgdata.interface[1].id == "lan") {
      landata = netcfgdata.interface[1];
    } else if(netcfgdata.interface[0].id == "lan") {
      landata = netcfgdata.interface[0];
    }

    if(wifidata.config.type) {wifidata.config.type = wifidata.config.type.toUpperCase();} 
    if(landata.config.type) {landata.config.type = landata.config.type.toUpperCase();}

    if(wifidata.primary) {
      this.primaryNetwork.setValue('WiFi');
    } else {
      this.primaryNetwork.setValue('LAN');
    }
    //ToDo: Use model or object for databinging instead of manual

    this.networkConfigForm.controls['wifissid'].setValue(wifidata.config.ssid);
    this.networkConfigForm.controls['wifipass'].setValue(wifidata.config.pass);
    this.networkConfigForm.controls['wifitype'].setValue(wifidata.config.type);
    this.networkConfigForm.controls['wifiip'].setValue(wifidata.config.ip);
    this.networkConfigForm.controls['wifimask'].setValue(wifidata.config.mask);
    this.networkConfigForm.controls['wifigwy'].setValue(wifidata.config.gwy);

    this.networkConfigForm.controls['lanssid'].setValue(landata.config.ssid);
    this.networkConfigForm.controls['lanpass'].setValue(landata.config.pass);
    this.networkConfigForm.controls['lantype'].setValue(landata.config.type);
    this.networkConfigForm.controls['lanip'].setValue(landata.config.ip);
    this.networkConfigForm.controls['lanmask'].setValue(landata.config.mask);
    this.networkConfigForm.controls['langwy'].setValue(landata.config.gwy);

    this.NetworkScheme = (netcfgdata.networkScheme && netcfgdata.networkScheme == "wifilan") ? "wifilan" : "none";
  }

  updateConfig(){ 
    // sends the slected network configuraiton via api service
    this.loading = true;
    this.netCfgMessage = "Updating...";
    let that = this;

    let netcgf;
    
    if(this.primaryNetwork.value == "WiFi") {
      netcgf = {
        "id": "wifi",
        "network": "wsx01",
        "primary": this.primaryNetwork.value == "WiFi",
        "config": {
          "ssid": this.networkConfigForm.get('wifissid').value,
          "pass": this.networkConfigForm.get('wifipass').value,
          "type": this.networkConfigForm.get('wifitype').value,
          "ip": this.networkConfigForm.get('wifiip').value,
          "mask": this.networkConfigForm.get('wifimask').value,
          "gwy": this.networkConfigForm.get('wifigwy').value,
        }
      };
    } else {
      netcgf = {
        "id": "lan",
        "network": "ens33",
        "primary": this.primaryNetwork.value != "WiFi",
        "config": {
          "ssid": null,
          "pass": null,
          "type": this.networkConfigForm.get('lantype').value,
          "ip": this.networkConfigForm.get('lanip').value,
          "mask": this.networkConfigForm.get('lanmask').value,
          "gwy": this.networkConfigForm.get('langwy').value,
        }
      };
    }

    this.restApi.updateNetworkConfig(netcgf.id, netcgf).subscribe((data: {}) => {
      console.log("updateNetworkConfig", data);
      setTimeout(function(){
        if (that.loading) {
          that.loading = false;
          that.errState = false;
          that.netCfgMessage = "";
        }
      }, 1000);
    });

    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.netCfgMessage = "Sorry, something is not quite right.";
      }
    }, 20000);
  }

  onSubmit() {
    //this.netCfgModel.primaryNetwork = this.networkConfigForm.value.PrimaryNet;
    this.updateConfig();
  }


  get wifiip(){
    return this.networkConfigForm.get('wifiip');
  }

  get wifimask(){
    return this.networkConfigForm.get('wifimask');
  }

  get wifigwy(){
    return this.networkConfigForm.get('wifigwy');
  }

  get lanip(){
    return this.networkConfigForm.get('lanip');
  }  

  get lanmask(){
    return this.networkConfigForm.get('lanmask');
  }  

  get langwy(){
    return this.networkConfigForm.get('langwy');
  }  

}
