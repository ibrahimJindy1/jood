import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loginpin',
  templateUrl: './loginpin.component.html',
  styleUrls: ['./loginpin.component.css']
})
export class LoginpinComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
