import { Component, OnDestroy, OnInit } from '@angular/core';
import { timer } from 'rxjs';

@Component({
  selector: 'app-synchronize',
  templateUrl: './synchronize.component.html',
  styleUrls: ['./synchronize.component.css']
})
export class SynchronizeComponent implements OnInit, OnDestroy {

  public timerCount:number = 8;
  public subscription:any;
  public timeoutDone:boolean = false;

  constructor() { }

  ngOnInit(): void {
    this.subscription = timer(0, 1000).subscribe((res) => {
      if(res){
        this.checkCount();
      }
    })
  }
  checkCount(){
    if(this.timerCount > -45) 
    {
      this.timerCount -= 1;
    }
    else 
    {
      this.timerCount = -45;
      this.timeoutDone = true;
    }
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

}
