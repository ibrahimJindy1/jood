import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SplashShutdownScreenComponent } from './splash-shutdown-screen.component';

describe('SplashShutdownScreenComponent', () => {
  let component: SplashShutdownScreenComponent;
  let fixture: ComponentFixture<SplashShutdownScreenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SplashShutdownScreenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SplashShutdownScreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
