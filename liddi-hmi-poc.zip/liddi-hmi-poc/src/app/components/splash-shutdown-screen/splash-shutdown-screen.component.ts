import { Component, OnInit } from '@angular/core';
import { DeviceApiService } from '../../services/device-api.service';

import { DeviceMessage } from 'src/app/models/DeviceMessage';
import { Router } from '@angular/router';

@Component({
  selector: 'app-splash-shutdown-screen',
  templateUrl: './splash-shutdown-screen.component.html',
  styleUrls: ['./splash-shutdown-screen.component.css']
})
export class SplashShutdownScreenComponent implements OnInit {
  windowWidth: string;
  showSplash = true;
  countDown = 5;
  interval;

  public resetType = "shutdown";
  public resetStr1 = "We are shutting things down...";
  public resetStr2 = "Turn off the main power switch ";
  public resetStr3 = "after this page is cleared.";

  constructor(public router: Router, public restApi: DeviceApiService) { 
    const navigation = this.router.getCurrentNavigation();

    console.log("SplashShutdownScreenComponent navigation.extras:");
    console.log(navigation.extras);
    console.log(navigation.extras.state);

    if(typeof navigation.extras !== "undefined") {

      console.log("SplashShutdownScreenComponent navigation.extras:"+navigation.extras);
      var resetTypeRequested = (navigation.extras as {type:string}).type || null;
      if(resetTypeRequested) this.resetType = resetTypeRequested;

      if(this.resetType === "restart"){
        this.resetStr1 = "We are starting things over...";
        this.resetStr2 = "Just need a moment to";
        this.resetStr3 = "clean things up.";
      }
    } 
    
  }

  public unitGroupName: string = "inventory";

  ngOnInit(): void {
    let that = this;

    this.interval = setInterval(function(){ 
      that.countDown--;
      if(that.countDown <= 0) clearInterval(that.interval);
    }, 1000);
    
  }

  getDeviceStatus(){
    let that = this;

    this.restApi.getHeartbeat().subscribe((data: {}) => { 
      let cdata:DeviceMessage = <DeviceMessage>data;    
      
      //check invenotry mode to adjust displayed columns      
      let invMode: string = "default";
      
      if(cdata.payload.messageData && cdata.payload.messageData.inventoryMode) 
      {
        invMode = cdata.payload.messageData.inventoryMode.toLowerCase();
      }    
      
      console.log(cdata);
      console.log(invMode);
      //for xyz mode display alternate unit group name
      //if (invMode === "xyz") this.unitGroupName = "IMS";      
    });
  }
}
