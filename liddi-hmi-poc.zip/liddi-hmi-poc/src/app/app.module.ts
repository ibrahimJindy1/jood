import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './material.module';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { SplashScreenComponent } from './components/splash-screen/splash-screen.component';
import { SplashIdleScreenComponent } from './components/splash-idle-screen/splash-idle-screen.component';
import { HomeComponent } from './home/home.component';
import { AppToolbarComponent } from './components/app-toolbar/app-toolbar.component';
import { MessageIndicatorComponent } from './components/message-indicator/message-indicator.component';
import { NetworkEditorComponent } from './components/network-editor/network-editor.component';
import { HelpComponent } from './components/help/help.component';

import { WebsocketService } from "./services/websocket.service";

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule  } from '@angular/material/form-field';
import { FormsModule } from '@angular/forms';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule} from '@angular/material/datepicker';
import { MatNativeDateModule} from '@angular/material/core';

import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { IKeyboardLayouts, keyboardLayouts, MAT_KEYBOARD_LAYOUTS, MatKeyboardModule, KeyboardClassKey } from 'angular-onscreen-material-keyboard';
import { SetupmainComponent } from './components/setupmain/setupmain.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DiagnosticsEngComponent } from './components/diagnostics-eng/diagnostics-eng.component';
import { FooterComponent } from './components/footer/footer.component';
import { PrivacyPolicyComponent } from './components/privacy-policy/privacy-policy.component';
import { TermsOfServiceComponent } from './components/terms-of-service/terms-of-service.component';

import { NgIdleKeepaliveModule } from '@ng-idle/keepalive'; // this includes the core NgIdleModule but includes keepalive providers for easy wireup
import { MomentModule } from 'angular2-moment';
import { SplashShutdownScreenComponent } from './components/splash-shutdown-screen/splash-shutdown-screen.component';
import { AppSidenavComponent } from './components/app-sidenav/app-sidenav.component'; // optional, provides moment-style pipes for date formatting
import { EventService } from './services/event.service';
import { LoginpinComponent } from './components/loginpin/loginpin.component';
import { WorkrequestActiveComponent } from './components/workrequest-active/workrequest-active.component';
import { InventoryComponent } from './components/inventory/inventory.component';
import { RestockComponent } from './components/restock/restock.component';
import { OptionsMenuComponent } from './components/options-menu/options-menu.component';
import { ProductFinderComponent } from './components/product-finder/product-finder.component';

import { CustomErrorHandlerService } from './services/custom-error-handler.service';
import { SynchronizeComponent } from './components/synchronize/synchronize.component'


const customLayouts: IKeyboardLayouts = {
  ...keyboardLayouts,
  'IMSNumericLayout': {
    'name': 'General Numeric Pad',
    'keys': [
      [
        ['1', '!'],
        ['2', '@'],
        ['3', '#']
      ],
      [
        ['4', '$'],
        ['5', '%'],
        ['6', '^']
      ],
      [
        ['7', '&'],
        ['8', '*'],
        ['9', '(^)']
      ],
      [       
        [KeyboardClassKey.Bksp, KeyboardClassKey.Bksp],    //css issue with backspce ToDo: fix css 
        ['0', ')'],
        ['.', '>']
      ]      
    ],
    'lang': ['en']
  },
  'IMSNumericLayout2': {
    'name': 'General Numeric Pad2',
    'keys': [
      [
        ['1', '!'],
        ['2', '@'],
        ['3', '#']
      ],
      [
        ['4', '$'],
        ['5', '%'],
        ['6', '^']
      ],
      [
        ['7', '&'],
        ['8', '*'],
        ['9', '(^)']
      ],
      [       
        ['-', '='],    //temp fix: css issue with backspce ToDo: fix css   
        ['0', ')'],
        ['.', '>']
      ]      
    ],
    'lang': ['en']
  },  
};

@NgModule({
  declarations: [
    AppComponent,
    SplashScreenComponent,
    HomeComponent,
    MessageIndicatorComponent,
    SplashIdleScreenComponent,
    AppToolbarComponent,
    NetworkEditorComponent,
    HelpComponent,
    SetupmainComponent,
    DiagnosticsEngComponent,
    FooterComponent,
    PrivacyPolicyComponent,
    TermsOfServiceComponent,
    SplashShutdownScreenComponent,
    AppSidenavComponent,
    LoginpinComponent,
    WorkrequestActiveComponent,
    InventoryComponent,
    RestockComponent,
    OptionsMenuComponent,
    ProductFinderComponent,
    SynchronizeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatRadioModule,
    MatCheckboxModule,
    MatSelectModule,
    MatSlideToggleModule,
    FormsModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatFormFieldModule,
    MatKeyboardModule,
    MaterialModule,
    MatSidenavModule,
    NgbModule,
    NgIdleKeepaliveModule.forRoot(),
    MomentModule,
    MatProgressBarModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  providers: [{provide: ErrorHandler, useClass: CustomErrorHandlerService}, WebsocketService, EventService, { provide: MAT_KEYBOARD_LAYOUTS, useValue: customLayouts }],
  bootstrap: [AppComponent]
})
export class AppModule {
  static websocketService;
  constructor(private websocketService: WebsocketService) { 
    console.log("AppModule: Open HMI Websocket...");
    this.websocketService.openWebSocket();
  }
 }
