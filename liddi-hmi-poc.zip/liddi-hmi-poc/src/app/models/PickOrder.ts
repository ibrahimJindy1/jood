export interface IPickOrder {
    //AKA Work Request
    workrequestid:number;
    requestor:string;
    destination: string;  
    recipient: string;
    items: number;
    status: string;
    action: any;
    request: any;  
  }

export class PickOrder implements IPickOrder{
    workrequestid:number;
    requestor:string;
    destination: string;  
    recipient: string;
    items: number;
    status: string;
    action: any;
    request: any;  
    mode:string;

    constructor(){        
    }
  }


export interface IPickOrderDetail {
    //AKA Work Request Item\Detail
    wrd_index_id:number,
    workqueueitemid:number;
    workrequestid:number; 
    sku: string;   
    upc: string;       
    manufacturer: string;  
    descriptor: string;
    area: string;
    location: string;
    qty: number;
    qtymax: number;
    qtypick: number;
    qtyrtn: number;
    qtyclear: number;    
    status: string;
  }

export class PickOrderDetail implements IPickOrderDetail{
    public wrd_index_id:number;
    public workqueueitemid:number;
    public workrequestid:number;
    public sku: string;
    public upc: string;    
    public manufacturer: string;  
    public descriptor: string;
    public area: string;
    public location: string;
    public qty: number;
    public qtymax: number;
    public qtypick: number;
    public qtyrtn: number;
    public qtyclear: number;    
    public status: string;

    constructor(){        
    }
  }

  export class PickOrderDetailEvent implements IPickOrderDetail{
    public wrd_index_id:number;
    public workqueueitemid:number;
    public workrequestid:number;
    public sku: string;
    public upc: string;    
    public manufacturer: string;  
    public descriptor: string;
    public area: string;
    public location: string;
    public qty: number;
    public qtymax: number;
    public qtypick: number;
    public qtyrtn: number;
    public qtyclear: number;    
    public status: string;
    public eventCode: string;
    public eventData: any;    

    constructor(pid:PickOrderDetail){    
      this.wrd_index_id = pid.wrd_index_id;
      this.workqueueitemid = pid.workqueueitemid;
      this.workrequestid = pid.workrequestid;
      this.sku = pid.sku;
      this.upc = pid.upc;      
      this.manufacturer = pid.manufacturer;  
      this.descriptor = pid.descriptor;
      this.area = pid.area;
      this.location = pid.location;
      this.qty = pid.qty;
      this.qtymax = pid.qtymax;
      this.qtypick = pid.qtypick;
      this.qtyrtn = pid.qtyrtn;
      this.qtyclear = pid.qtyclear;      
      this.status = pid.status;  
    }
  }  

export interface IPickOrderEvent {
    workrequest:PickOrder;
    workrequestitems:PickOrderDetail[];
    eventCode: string;  
    eventData: any;  
  }

export class PickOrderEvent implements IPickOrderEvent{
    workrequest:PickOrder;
    workrequestitems:PickOrderDetail[];
    eventCode: string;  
    eventData: any;  

    constructor(){        
    }
}


export interface IPickProduct {
  sku: string;  
  upc: string;     
  manufacturer: string;  
  brand: string; 
  descriptor: string;
  sphere: number;
  cylinder: number;
  axis: number;
  unit_of_measure: string;
  qty: number;
  sub_qty: number;
}

export class PickProduct implements IPickProduct{
  public sku: string; 
  public upc: string;     
  public manufacturer: string;  
  public brand: string; 
  public descriptor: string;
  public sphere: number;
  public cylinder: number;
  public axis: number;
  public unit_of_measure: string;
  public qty: number;
  public sub_qty: number;

  public lot: string;
  public expiration: Date;
  public serialnumber: string;
  public mfgdate: Date;    

  constructor(){        
  }
  
} 