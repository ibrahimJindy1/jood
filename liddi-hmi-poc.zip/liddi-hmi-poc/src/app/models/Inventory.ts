export interface IInventory {
    inventoryid: number;
    status:string;
    area:string;
    location:string;
    sku:string;
    upc:string;    
    expiration:string;
    lot:string;
    serialnumber:string;
    qty: number;
    subqty: number;
    gtin:string;
    mfgdate:string;
    manufacturer:string;
    descriptor:string;
    brand:string;
  }

export class InventoryItem implements IInventory{
    inventoryid: number;
    status:string;
    area:string;
    location:string;
    sku:string;
    upc:string;    
    expiration:string;
    lot:string;
    serialnumber:string;
    qty: number;
    subqty: number;
    gtin:string;
    mfgdate:string;
    manufacturer:string;
    descriptor:string;
    brand:string;

    constructor(){        
    }

}


export class InventoryPickItem implements IInventory{
  inventoryid: number;
  status:string;
  area:string;
  location:string;
  sku:string;
  upc:string;  
  expiration:string;
  lot:string;
  serialnumber:string;
  qty: number;
  subqty: number;
  gtin:string;
  mfgdate:string;
  manufacturer:string;
  descriptor:string;
  brand:string;

  wrd_index_id:number;
  workqueueitemid:number;
  workrequestid:number;

  qtymax: number;
  qtypick: number;
  qtyrtn: number;

  qtyclear: number
 
  constructor(){        
  }

}
