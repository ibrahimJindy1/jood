export class NetworkConfig { 

    private _primaryNetwork = "";
    private _configStatus = "";
    private _netStatus = "";     
    private _wifi = new WiFiNet(false,'','');
    private _lan= new LanNet(false,'','','');

    constructor(
       // primaryNetwork: string,  //WiFi or Lan
       // configStatus: string,
       // netStatus: string,      
       // wifi: WiFiNet,
       // lan: LanNet
      ) {  }

    updateConfig(){
    }

    loadConfig(){
    }    
  
    get primaryNetwork() { return this._primaryNetwork; }
    get configStatus() { return this._configStatus; }
    get netStatus() { return this._netStatus; }     
    get wifi() { return this._wifi; }
    get lan() { return this._lan; }
    
    set primaryNetwork(value:string) { this._primaryNetwork = value; }
    set configStatus(value:string) { this._configStatus = value; }
    set netStatus(value:string) { this._netStatus = value; }     
    set wifi(value:WiFiNet) { this._wifi = value; }
    set lan(value:LanNet) { this._lan = value; }

  }

  class WiFiNet {
    private _dhcp = true;
    private _ssid = "";
    private _passphrase = "";

    constructor(
         public dhcp: boolean,
         public ssid: string,
         public passphrase: string
    ) {
        this._dhcp = dhcp;
        this._ssid = ssid;
        this._passphrase = passphrase;    
    }    
  }

  class LanNet {
    private _dhcp = true;
    private _ip = "";
    private _mask = "";
    private _gtwy = "";    

    constructor(
         public dhcp: boolean,
         public ip: string,
         public mask: string,
         public gtwy: string
    ) {
        this._dhcp = dhcp;
        this._ip = ip;
        this._mask = mask;    
        this._gtwy = gtwy;    
    }    
  }