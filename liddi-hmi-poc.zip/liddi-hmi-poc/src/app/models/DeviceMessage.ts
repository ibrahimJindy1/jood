export class DeviceMessage{
    topic: String;
    payload: any;

    constructor(topic:String, payload: any) {
        this.topic = topic;
        this.payload = payload;
    }
}