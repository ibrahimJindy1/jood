export class LogMessage{
    source:string;
    levelNum: LogLevel;
    level:string;
    message: string;

    constructor(source:string = "", levelNum:LogLevel, message: string) {
        this.source = source;
        this.levelNum = levelNum;
        this.message = message;
        this.level = LogLevel[levelNum];
    }
}

export enum LogLevel {
    All = 0,
    Debug = 1,
    Info = 2,
    Warn = 3,
    Error = 4,
    Fatal = 5,
    Off = 6
}