export class EventServiceMessage{
    source: String;
    destination:String[];    
    topic: String;
    payload: any;

    constructor(source:String, topic:String, payload: any, destination:String[]=[]) {
        this.source = source;
        this.destination = destination;
        this.topic = topic;
        this.payload = payload;
    }
}