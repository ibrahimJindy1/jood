export interface IPutItemDetail {
    upc: string;   
    manufacturer: string;  
    descriptor: string;
    expiration: Date;
    lot: string;
    serial:string;
    area: string;
    location: string;
    qty: number;
    status: string;
  }

export class PutItemDetail implements IPutItemDetail{
    public upc: string;
    public manufacturer: string;  
    public descriptor: string;
    public expiration: Date;
    public lot: string;
    public serial:string;    
    public area: string;
    public location: string;
    public qty: number;
    public status: string;

    constructor(){        
    }
  }

  export interface IStockProduct {
    upc: string;   
    manufacturer: string;  
    brand: string; 
    descriptor: string;
    sphere: number;
    cylinder: number;
    axis: number;
    unit_of_measure: string;
    qty: number;
    sub_qty: number;
  }

export class StockProduct implements IStockProduct{
    public upc: string;   
    public manufacturer: string;  
    public brand: string; 
    public descriptor: string;
    public sphere: number;
    public cylinder: number;
    public axis: number;
    public unit_of_measure: string;
    public qty: number;
    public sub_qty: number;

    public lot: string;
    public expiration: Date;
    public serialnumber: string;
    public mfgdate: Date;    


    constructor(){        
    }
    
  } 
  
  export interface IStorageLocation {
    area: string;   
    location: string;
    size: any[];
    size_ref: string;
    main_led: number;
    led_addr_offset: any[];
    gpio: number;
  }

export class StorageLocation implements IStorageLocation{
    public area: string;   
    public location: string;
    public size: any[];
    public size_ref: string;
    public main_led: number;    
    public led_addr_offset: any[];
    public gpio: number;

    constructor(){        
    }
    
  }   