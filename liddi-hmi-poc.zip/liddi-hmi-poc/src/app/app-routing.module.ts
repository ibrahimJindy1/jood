import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { HomeComponent } from "./../app/home/home.component";
import { WorkrequestActiveComponent } from "./../app/components/workrequest-active/workrequest-active.component";
import { RestockComponent } from "./../app/components/restock/restock.component";
import { InventoryComponent } from "./../app/components/inventory/inventory.component";
import { HelpComponent } from "./../app/components/help/help.component";
import { SplashIdleScreenComponent } from "./../app/components/splash-idle-screen/splash-idle-screen.component";
import { NetworkEditorComponent } from "./../app/components/network-editor/network-editor.component";
import { DiagnosticsEngComponent } from "./../app/components/diagnostics-eng/diagnostics-eng.component";
import { PrivacyPolicyComponent } from "./../app/components/privacy-policy/privacy-policy.component";
import { TermsOfServiceComponent } from "./../app/components/terms-of-service/terms-of-service.component";
import { SplashShutdownScreenComponent } from "./components/splash-shutdown-screen/splash-shutdown-screen.component";
import { OptionsMenuComponent } from "./../app/components/options-menu/options-menu.component" 
import { ProductFinderComponent } from "./components/product-finder/product-finder.component";
import { SynchronizeComponent } from "./components/synchronize/synchronize.component";


const routes: Routes = [
  
  {
    component: HomeComponent,
    path: "home",     
    pathMatch: "full",
    data:{footer:true}
  },        
  {
    component: ProductFinderComponent,
    path: "direct-pick",     
    pathMatch: "full",
    data:{footer:true}
  },
  {
    component: WorkrequestActiveComponent,
    path: "workrequest-active",
    pathMatch: "full",
    data:{footer:true}
  },      
  {
    component: RestockComponent,
    path: "restock",
    pathMatch: "full",
    data:{footer:true}
  },
  {
    component: OptionsMenuComponent,
    path: "other",
    pathMatch: "full",
    data:{footer:true}
  },
  {
    component: SynchronizeComponent,
    path: "synchronize",
    pathMatch: "full",
    data:{footer:true}
  },  
  {
    component: InventoryComponent,
    path: "inventory",
    pathMatch: "full",
    data:{footer:true}
  },  
  {
    component: HelpComponent,
    path: "help",     
    pathMatch: "full",
    data:{footer:true}
  },
  {
    component: NetworkEditorComponent,
    path: "neteditor",    
    pathMatch: "full",
    data:{footer:true}
  },
  {
    component: SplashIdleScreenComponent,
    path: "splashidle",     
    pathMatch: "full",
    data:{footer:false}
  }, 
  {
    component: DiagnosticsEngComponent,
    path: "diagengr",     
    pathMatch: "full",
    data:{footer:true}
  }, 
  {
    component: PrivacyPolicyComponent,
    path: "privacy-policy",     
    pathMatch: "full",
    data:{footer:true}
  },
  {
    component: TermsOfServiceComponent,
    path: "terms-of-service",     
    pathMatch: "full",
    data:{footer:true}
  },   
  {
    component: SplashShutdownScreenComponent,
    path: "shutdown",     
    pathMatch: "full",
    data:{footer:false}
  },      
  {
    path: "",
    redirectTo: "/splashidle",
    pathMatch: "full",
    data:{footer:false}
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}