import { Component, ElementRef, EventEmitter, OnInit, QueryList, ViewChildren, ViewEncapsulation, TemplateRef} from '@angular/core';
import { DeviceApiService } from '../services/device-api.service';
import { WebsocketService } from "../services/websocket.service";

import {Title} from "@angular/platform-browser";

import {AfterViewInit, ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';

import { DeviceMessage } from 'src/app/models/DeviceMessage';
import { EventService, EventServiceMessage } from '../services/event.service';
import { environment } from 'src/environments/environment';

import { FormGroup, FormControl, Validators } from '@angular/forms';

//import { NgbModal, NgbModalRef, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
//import {map} from 'rxjs/operators';

import { PickOrder } from '../models/PickOrder';
import { HtmlUtils } from '../shared/html-utils'

const ELEMENT_EMPTY: PickOrder[] = [];

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  encapsulation: ViewEncapsulation.None,
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  private readonly _eventService: EventService;
  private eventServiceSubscription: any;
  public componentReference: string = "HomeComponent";

  public eventMessage: string;

  title = 'ims-hmi';

  constructor(public router: Router, public websocketService: WebsocketService, public restApi: DeviceApiService, 
    public htmlUtils: HtmlUtils, private titleService:Title, eventService: EventService) { 
      this._eventService =  eventService;
      this.eventServiceSubscription = this._eventService.emitter.subscribe( message => {this.eventMessage = message; this.handleComponentMessage(message);});
      this.titleService.setTitle("IMS HMI");
   }
   
  private wsSubscription: Subscription;
  public scanSummary: string[] = ["",""];

  public loading: boolean = true;
  public invMessage: string = "Loading...";
  public errState: boolean = false;

  public deviceState: string = "...";
 
  public displayedColumns: string[] = ['requestor', 'recipient',  'items', 'status', 'action'];
  public dataSource: MatTableDataSource<PickOrder> = new MatTableDataSource<PickOrder>(ELEMENT_EMPTY);
  //public noData = this.dataSource.connect().pipe(map(data => data.length === 0));

  public filterText = new FormControl({value:'', disabled: true});
  public diopterFilterText = new FormControl('');
  public lastDiopterFilterText: string = "";
 
  public filterGroup:boolean[] = [true,false,false];
  public filterButtonsText:Array<string> = []; //= ['A','D','P','Z'];
  public stagedInvCodes:Array<string> = [];
  public filter_lvl1:Array<string> = [];
  public filter_lvlx:Array<string> = [];
 
  public pickOrderArray = ELEMENT_EMPTY;
  public inventoryRefreshAllowNext: Date = new Date();
 
  public selectedRowIndex: string = "";
  public showDiopterStyle: string = "none";

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChildren('input') inputs: QueryList<ElementRef>;

  ngOnInit(): void {
    //this.websocketService.openWebSocket(); //using appmodule websocket (static)
    this.wsSubscription = this.websocketService.deviceMessageChange.subscribe((m:string) => {this.incomingMessage(m)});
    this.htmlUtils = new HtmlUtils;

    this.dataSource.paginator = this.paginator;

    //get work requests order list
    this.loadWorkRequests();

    const message:EventServiceMessage = new EventServiceMessage(this.componentReference, "send-heartbeat-latest", null, ['AppToolbarComponent']);
    this.broadcastComponentMessage(message);
     
  }

  ngOnDestroy(): void {
    console.log("ngOnDestroy HomeComponent!");

    //unsubscribe/dispose    
    this.eventServiceSubscription.unsubscribe();
    this.wsSubscription.unsubscribe();
  }

  ngAfterViewInit() {
    //Note: ngAfterViewInit fires on init but there may not be a data source ready/loaded
    this.configDatasource();
  }

  configDatasource(){
    if(this.dataSource) {
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;   
    }
  }

  incomingMessage(msg: string){    
    console.log("incoming (home) message:", msg);
    var in_msg = msg.toLowerCase();
    if(in_msg.includes(":ready") || in_msg.includes(":init") || in_msg.includes(":update")) this.loadWorkRequests();   

  }


  loadWorkRequests(){
    this.dataSource = new MatTableDataSource(ELEMENT_EMPTY);
   
    this.errState = false;
    this.loading = true;
  
    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.invMessage = "Sorry, something is not quite right.";}
      }, 6000);

    this.restApi.getWorkRequests().subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.invMessage = "";
  
      let wrdata = data as {topic:string, payload:any};

      that.pickOrderArray = wrdata.payload.messageData;

      that.dataSource = new MatTableDataSource(that.pickOrderArray);

      //ngAfterViewInit not firing - safe call here instead
      that.configDatasource();

    });     
  }
  
  activateWorkRequest(selectedPickOrder:PickOrder){
    //this.dataSource = new MatTableDataSource(ELEMENT_EMPTY);
    selectedPickOrder.mode = "normal";

    this.errState = false;
    this.loading = true;

    let that = this;    
  
    setTimeout(function(){
      if (that.loading) {
        //that.loading = false; 
        that.errState = true;
        that.invMessage = "Sorry, something is not quite right.";}
      }, 6000);

    this.restApi.putWorkRequest(selectedPickOrder.workrequestid,selectedPickOrder.mode).subscribe((data: {}) => {    
      that.loading = false;
      that.errState = false;
      that.invMessage = "";
  
      let wrdata = data as {topic:string, payload:any};
      
      console.log('activateWorkRequest --> wrdata: ',wrdata)

      var workrequestref = selectedPickOrder;

      that.router.navigate(['/workrequest-active'], { state: workrequestref});

    });     
  }

  onPickOrderClicked(row:PickOrder) {
    console.log('Row clicked: ', row); //, ' this.lastMState:', this.lastMState);
    
    if(this.deviceState === "ready") {
      this.activateWorkRequest(row);
    } else 
    console.log(this.deviceState);

  }

  refresh(){

      //on second/successive clicks clear/reload form  
      let refreshNow = Date.now();
      var diff = this.inventoryRefreshAllowNext.getTime() - refreshNow;
  
      if(diff < 0) {
        this.inventoryRefreshAllowNext = new Date(Date.now() + 1500);
        
        //get invenotry
        this.loadWorkRequests();
      }
  }

  processKeyedInput(key:string){
    //Using the single key(ed) input for demo/testing
    switch(key){    
      case "R":
      case "r":
        //reset the demo inventory and workrequests
        console.log("HOME:processKeyedInput (emulate DEMO Reset)");
        let demoMsg:DeviceMessage = new DeviceMessage("Reset", {prodEnv:environment.production});
        
        this.restApi.postDemoAction(demoMsg).subscribe((response: {}) => {    
          console.log(response);
        });        
        break;                                
      default:
        break;
    }
  }

  updateDeviceStatusFromHeartbeat(hbPayload:any){   
    var state = (hbPayload && hbPayload?.machineState)?hbPayload.machineState.toLowerCase():"";
    this.setDeviceState(state);
  }

  updateDeviceStatusFromConnection(status:any){    
    if(status == "closed") this.setDeviceState("?");
  }

  setDeviceState(state:any){
    console.log("device state:"+state);
    this.deviceState = state.toLowerCase();
  }

  handleComponentMessage(message:EventServiceMessage){
    if(message.source !== this.componentReference && ( message.destination.length == 0 || message.destination.includes(this.componentReference) ) ){
      //console.log(this.componentReference+' received Message...', message);
      switch(message.topic){
        case "apptoolbar-heartbeat-relay":
        case "apptoolbar-heartbeat-lastest":
          this.updateDeviceStatusFromHeartbeat(message.payload);
          break;         
        case "apptoolbar-device-connection":
          this.updateDeviceStatusFromConnection(message.payload);
          break;    
        case "apptoolbar-workrequest-queued":
          this.loadWorkRequests();
          break;                     
        case "app-keyinput":
          console.log("home received key:"+message.payload);
          this.processKeyedInput(message.payload); 
          break;         
      }
    }    
  }   

  broadcastComponentMessage(message:EventServiceMessage = null): void { 
    //console.log(this.componentReference+' sent Message...', message);  
    let msgx:EventServiceMessage = message || new EventServiceMessage(this.componentReference, "generic_message", "not_implemented", []);
    this._eventService.broadcastMessage(msgx);
  }  
}
