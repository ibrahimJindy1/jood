import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { NetworkConfig } from '../shared/network-config';
import { NetworkStatus } from '../shared/network-status';
import { InventoryItem } from '../shared/inventory-item';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { PickOrder, PickOrderDetail, PickOrderEvent } from '../models/PickOrder';
import { DeviceMessage } from '../models/DeviceMessage';
import { StockProduct } from '../models/PutItem';
import { LogMessage } from '../models/LogMessage'
 
export const DEVICEAPI_URL = environment.deviceApi_httpUrl;
export const DEVICEAPI_KEY = environment.deviceApi_apiKey;

@Injectable({
  providedIn: 'root'
})

export class DeviceApiService {
  
  // Define API
  apiURL = DEVICEAPI_URL; //'http://localhost:3000';
  apiKey = DEVICEAPI_KEY; 

  constructor(private http: HttpClient) { }

  /*========================================
    CRUD Methods for consuming RESTful API
  =========================================*/

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'x-apikey' : this.apiKey
    })
  }  
 
  // HttpClient API put() method => put log
  postLog(log:LogMessage):void{
    console.log("postLog: ", log);
    var p = this.http.put<any>(this.apiURL + '/logger', log, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    );

    p.subscribe(); //fire and forget
  }

  // HttpClient API get() method => get device info
  getDeviceInfo(): Observable<String[]> {
    return this.http.get<String[] >(this.apiURL + '/deviceinfo', this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }  

  // HttpClient API get() method => get device heartbeat (detailed)
  getHeartbeat(): Observable<String[]> {
    return this.http.get<String[] >(this.apiURL + '/heartbeat', this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }    

  getErrorQueue(){
    return this.http.get(this.apiURL + '/errorqueue')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
  
  getHmiConfig(): any {
    return this.http.get(this.apiURL + '/hmiconfig')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }  
   
  // HttpClient API get() method => Fetch nework config
  getNetworkConfig(): Observable<NetworkConfig[]> {
    return this.http.get<NetworkConfig[]>(this.apiURL + '/networkconfig', this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // HttpClient API put() method => update nework config
  updateNetworkConfig(id, networkconfig): Observable<NetworkConfig> {
    let urlsuffix = id ? '/networkconfig/' + id: '/networkconfig/' ;
    console.log(urlsuffix);
    return this.http.put<NetworkConfig>(this.apiURL + urlsuffix, JSON.stringify(networkconfig), this.httpOptions)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // HttpClient API get() method => fetch nework status
  getNetworkStatus(): Observable<NetworkStatus> {
    return this.http.get<NetworkStatus>(this.apiURL + '/networkstatus', this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // HttpClient API get() method => fetch Wifi ssid's
  getWifiSSIDList(): Observable<String[]> {
    return this.http.get<String[] >(this.apiURL + '/netssids')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }  

  // HttpClient API get() method => fetch all active/actionable work requests
  getWorkRequests(): Observable<any> {
    return this.http.get<any>(this.apiURL + '/workrequests', this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
 
  // (s0) HttpClient API put() method => activate a work request
  putWorkRequest(wrid:number, mode:string = "normal", request:any = {}): Observable<any> {
    const body = { workrequestid: wrid, mode: mode, request: request };
    return this.http.put<any>(this.apiURL + '/workrequests', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // (s1) HttpClient API put() method => send/report the scanned item on the back end
  putWorkRequestItemScanned(workrequestid:number, scanneditem:string, qty:number, area:string, location:string, gs1data:any): Observable<any> {
    const body = { workrequestid: workrequestid, scanneditem: scanneditem, qty:qty, area:area, location:location, gs1data:gs1data };
    return this.http.put<any>(this.apiURL + '/workrequestitems/scanned', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // (s1) HttpClient API put() method => send/report the scanned item on the back end
  putWorkRequestItemNoScan(upc:string, area:string, location:string): Observable<any> {
    const body = { upc:upc, area:area, location:location };
    return this.http.put<any>(this.apiURL + '/workrequestitems/noscan', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }  

  // HttpClient API put() method => send item to be resolved - provides resolution to pick issues
  putWorkRequestItemResolved(writem:PickOrderDetail): Observable<any> {
    const body = writem;
    return this.http.put<any>(this.apiURL + '/workrequestitems/resolved', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
  
  // (s8) HttpClient API put() method => send update action/event for a work request item
  putWorkRequestScannedItem(writem:PickOrderDetail): Observable<any> {
    const body = writem;
    return this.http.put<any>(this.apiURL + '/workrequestitems', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // HttpClient API put() method => send request to find resolution for work request inventory gap via cloud/LLISA
  putWorkRequestResolution(writems:PickOrderEvent): Observable<any> {
    const body = writems;
    return this.http.put<any>(this.apiURL + '/workrequests/resolution', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
    
  // HttpClient API put() method => send data/event for a work request
  putWorkRequestEvent(eventData:PickOrderEvent): Observable<any> {
    const body = eventData;
    return this.http.put<any>(this.apiURL + '/workrequests/event', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // HttpClient API get() method => fetch all active/actionable work requests
  getWorkRequestsItemsStaged(): Observable<any> {
    console.log("API Calling...get workrequestitemsstaged");
    return this.http.get<any>(this.apiURL + '/workrequestitems/staged', this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
  
  // HttpClient API get() method => fetch active item
  getWorkRequestsItemsActive(): Observable<any> {
    console.log("API Calling...get workrequestitemsactive");
    return this.http.get<any>(this.apiURL + '/workrequestitems/active', this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
  
  
  // HttpClient API get() method => fetch all active inventory
  getInventory(): Observable<any> {
    return this.http.get<any>(this.apiURL + '/inventory', this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }

  // HttpClient API get() method => fetch all active/actionable work requests
  putInventoryNoBarcode(locationInfo:any): Observable<any> {
    const body = locationInfo;
    return this.http.put<any>(this.apiURL + '/inventory/nobarcodeonlocation', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 

  // HttpClient API get() method => set location empty
  putInventorySlotEmpty(locationInfo:any): Observable<any> {
    const body = locationInfo;
    return this.http.put<any>(this.apiURL + '/inventory/emptylocation', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }  

  // HttpClient API get() method => set location not empty (to clear inventory from location)
  putInventorySlotNotEmpty(locationInfo:any): Observable<any> {
    const body = locationInfo;
    return this.http.put<any>(this.apiURL + '/inventory/notemptylocation', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 
  
  // HttpClient API get() method => fetch product info by upc
  putProductToRestock(stockItem:StockProduct, getstockloc:boolean = false): Observable<any> {
    const body = {stockItem:stockItem, getStockLocation:getstockloc};
    return this.http.put<any>(this.apiURL + '/products/stage', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }  

  // HttpClient API get() method => fetch action for restock event
  putRestockAction(stockprod: StockProduct , action:string): Observable<any> {
    let finalaction;

    switch(action){
      case "cancel":
        finalaction = "cancel";
        break;
      case "save":
        finalaction = "save";
        break;
      case "notempty":
        finalaction = "notempty";
        break;
    }

    const body = {item:stockprod, action:finalaction};
    
    return this.http.put<any>(this.apiURL + '/inventory/stock', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 
  
  // HttpClient API get() method => fetch all active/actionable work requests
  postDemoAction(postData:DeviceMessage): Observable<any> {
    const body = postData;
    return this.http.post<any>(this.apiURL + '/demo/action', body, this.httpOptions) 
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 

  /*

  sendConfig(): any {
    return this.http.get(this.apiURL + '/configsend')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 
  
  sendConfigId(): any {
    return this.http.get(this.apiURL + '/configidsend')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 

  toggleLedCycle(pattern:string): any {

    let pat = encodeURIComponent(pattern);
    return this.http.put(this.apiURL + '/ledcycle', pattern)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 

  getInventorySummary(): Observable<InventoryItem[]> {
    const params = new HttpParams().set('type', 'summ');
    
    return this.http.get<InventoryItem[] >(this.apiURL + '/inventoryscan', {params})
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }  

  getScanSummary(): Observable<InventoryItem[]> {
    return this.http.get<InventoryItem[] >(this.apiURL + '/scansummary')
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }   

  getLog(): any {
    return this.http.get(this.apiURL + '/logger?mode=latest', {responseType: 'text'})
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 



  locateInventory(upc:string, sku:string, expired:boolean=false): Observable<String> {
    //ToDo: sanitize upc/sku
    let qry:string;

    qry = 'upc=' + ((upc) ? (upc) : 'null');
    qry+= '&sku=' + ((sku) ? (sku) : 'null');
    qry+= '&expired=' + ((expired) ? true : false);

    console.log(qry);

    return this.http.get<String>(this.apiURL + '/inventorylocate?' + qry )
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  } 

  locateExpired(): Observable<String> {
    //ToDo: sanitize upc/sku
    let qry:string;

    console.log(qry);

    return this.http.get<String>(this.apiURL + '/expiredlocate' )
    .pipe(
      retry(1),
      catchError(this.handleError)
    )
  }
*/
  shutdownDevice(option, delay:number = 5){
    let qry:string = "type=";

    if(option == "restart"){
      qry+="restart";
    } else {
      qry+="shutdown";
    }
    
    if(delay < -1 || delay > 10) delay = 5;
    if(delay != -1) qry+="&delay=" + delay;  //-1 ommit delay parameter - uses device default

    return this.http.get(this.apiURL + '/shutdown?' + qry)
    .pipe(
      retry(1),
      catchError(this.handleError)
    )    
  }

  // Error handling 
  handleError(error) {
     let errorMessage = '';
     if(error.error instanceof ErrorEvent) {
       // Get client-side error
       errorMessage = error.error.message;
     } else {
       // Get server-side error
       errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
     }
     //window.alert(errorMessage);
     return throwError(errorMessage);
  }

}