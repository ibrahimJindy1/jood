import { Injectable, EventEmitter } from '@angular/core';
import { EventServiceMessage } from '../models/EventServiceMessage';

@Injectable()
export class EventService {
  public emitter: EventEmitter<EventServiceMessage | null>;
  constructor() {
    this.emitter = new EventEmitter<EventServiceMessage>(null);
  }
  broadcastMessage(message: EventServiceMessage): void {
    this.emitter.emit(message);
  }
}

export * from '../models/EventServiceMessage'