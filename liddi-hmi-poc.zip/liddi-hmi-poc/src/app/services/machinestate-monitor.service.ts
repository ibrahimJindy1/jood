import { Injectable } from '@angular/core';
import { HmiAction } from '../shared/hmi-action';

@Injectable({
  providedIn: 'root'
})
export class MachineStateMonitorService {
  public machineState:String = "";
  public machineStateLast:String = "";

  constructor() { }

  getMachineStateIndicatorState(message:String[]):HmiAction {
    let hmiAct = new HmiAction;

    if(message[0].toLowerCase() === "mstate") {
      var mstatemsg = (message[1])?message[1].toLowerCase():"";
      switch(mstatemsg) {
        case "ready":
          hmiAct.display = "Ready";
          hmiAct.route = "home";
          hmiAct.actionType = "None";

          this.machineState = "ready";
          break;
        case "stock":
          hmiAct.display = "Stock";
          hmiAct.route = "home";
          hmiAct.actionType = "None";

          this.machineState = "stock";
          break;
        case "locate":  
        case "locatenoscan":    
          hmiAct.display = "Locate"+(mstatemsg == "locatenoscan"?"*":"");
          hmiAct.route = null;
          hmiAct.actionType = "None";
          if(mstatemsg == "locatenoscan") 
          this.machineState = "locate";
          break;  
        case "error":
        case "hardwareerror":
          hmiAct.display = "*ERROR*";
          hmiAct.route = "help";
          hmiAct.actionType = "None";
  
          this.machineState = "error";
          break;            
        case "diagnostics":
          hmiAct.display = "Diagnostics";
          hmiAct.route = null;
          hmiAct.actionType = "None";
    
          this.machineState = "diagnostics";
          break;  
        case "test":
        case "maintenance":          
          hmiAct.display = "Maintenance"+(mstatemsg == "test"?"*":"");
          hmiAct.route = null;
          hmiAct.actionType = "None";
    
          this.machineState = "diagnostics";
          break;   
        case "shutdown":          
          hmiAct.display = "Shutdown";
          hmiAct.route = null;
          hmiAct.actionType = "None";
    
          this.machineState = "shutdown";
        case "sync":          
          hmiAct.display = "Synchronizing...";
          hmiAct.route = null;
          hmiAct.actionType = "None";
    
          this.machineState = "synchronizing";          
          break;                             
        default: // "Initializing":
          hmiAct.display = "Initializing...";
          hmiAct.route = null;
          hmiAct.actionType = "None";

          this.machineState = "init";
          break;
      }
    }
        
    this.machineStateLast = this.machineStateLast;

    return hmiAct;

  }

}
