import { Injectable, EventEmitter, Output } from "@angular/core";
import { DeviceMessage } from "../models/DeviceMessage"
import { environment } from '../../environments/environment';

export const DEVICEMONITOR_URL = environment.deviceMonitor_wsUrl;

//import * as Rx from 'rxjs/Rx';

@Injectable()
export class WebsocketService {

  webSocket: WebSocket;
  //deviceMessages: DeviceMessage[] = [];
  deviceMessage: string; 
  reset: boolean = false;

  //@Input()
  //messageToDevice:String;

  @Output()
  deviceMessageChange:EventEmitter<string>;
  
  @Output()
  deviceConnectionChange:EventEmitter<string>;

  constructor() {
    this.deviceMessageChange = new EventEmitter<string>(); 
    this.deviceConnectionChange = new EventEmitter<string>();    
  }
  
  public openWebSocket(){
    if(!this.webSocket || this.reset) //this.webSocket.readyState !== WebSocket.OPEN
    {
      this.webSocket = new WebSocket(DEVICEMONITOR_URL);

      this.webSocket.onopen = (event) => {
        //console.log('Websocket: ',event);
        this.deviceConnectionChange.emit('opened');
        console.log('Websocket: Opened');
      };
    
      this.webSocket.onmessage = (event) => {
        const deviceMsg = JSON.parse(event.data);
        this.deviceMessage = deviceMsg.payload;
        this.deviceMessageChange.emit(this.deviceMessage);
        //console.log('onmessage: ',event); 
      };
  
      this.webSocket.onclose = (event) => {
        //console.log('Closed: ',event); 
        this.deviceConnectionChange.emit('closed');
        console.log('Websocket: Closed');
        let that = this;
        this.reset = true;
        setTimeout(function(){that.openWebSocket();},2000);
      }
    }

    this.reset = false;
  }

  public sendMessage(deviceMsg: DeviceMessage){
    this.webSocket.send(JSON.stringify(deviceMsg));
  }

  public closeWebSocket(){
    this.webSocket.close();
  }
}