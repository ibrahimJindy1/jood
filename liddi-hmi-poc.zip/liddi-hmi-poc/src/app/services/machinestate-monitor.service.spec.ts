import { TestBed } from '@angular/core/testing';

import { MachineStateMonitorService } from './machinestate-monitor.service';

describe('MachineStateMonitorService', () => {
  let service: MachineStateMonitorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MachineStateMonitorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
