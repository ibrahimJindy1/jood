import { TestBed } from '@angular/core/testing';

import { NetworkMonitorService } from './network-monitor.service';

describe('NetworkMonitorService', () => {
  let service: NetworkMonitorService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NetworkMonitorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
