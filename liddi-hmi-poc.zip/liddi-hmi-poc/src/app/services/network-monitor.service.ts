import { Injectable } from '@angular/core';
import { HmiAction } from './../shared/hmi-action';
import { NetworkStatus } from './../shared/network-status'

@Injectable({
  providedIn: 'root'
})
export class NetworkMonitorService {
  public netState:String = "";
  public netStateLast:String = "";

  constructor() { }

  getNetworkIndicatorState(message:string[]):HmiAction {
    let hmiAct = new HmiAction;

    if(message[0].toLowerCase() === "network") {
      switch(message[1]?.toLowerCase()) {
        //network-nonet - disconnected
        case "nonet":
          hmiAct.display = null;
          hmiAct.route = null;
          hmiAct.actionType = "None";
          hmiAct.imageSrc = "net_unk.png";

          this.netState = "NoNet";
        break;
        //network-net-nohub - limited
        case "net-nohub":
        case "iot-disconnected":
        case "mqtt-disconnected":
          hmiAct.display = null;
          hmiAct.route = null;
          hmiAct.actionType = "None";
          hmiAct.imageSrc = "net_nohub.png";

          this.netState = "Net-NoHub";
          break;  
        case "net-inithub":
          hmiAct.display = null;
          hmiAct.route = null;
          hmiAct.actionType = "None";
          hmiAct.imageSrc = "net_connecting.png";

          this.netState = "Net-InitHub";
          break;                  
        //network-net-hub - connected
        case "net-hub":
        case "iot-connected":
        case "mqtt-connected":
          hmiAct.display = null;
          hmiAct.route = null;
          hmiAct.actionType = "None";
          hmiAct.imageSrc = "net_ok.png";

          this.netState = "Net-Hub";
          break;
        //network-nocfg - configuration bad or missing
        default: //"NoCfg"
          hmiAct.display = null; //"Attention...";
          hmiAct.route = null;//"/neteditor";
          hmiAct.actionType = "None";
          hmiAct.imageSrc = "net_nocfg.png";

          this.netState = "NoCfg";
          break;
      }
    }

    return hmiAct;
  }

  getNetworkIndicatorFromStatus(message:NetworkStatus[]):HmiAction {
    let hmiAct = new HmiAction;
    let msgobj:string[] = ["network"];

    let net:NetworkStatus = message.find(o => o.primary);
  
    if(net.iot == "connected"){
      msgobj.push("Net-Hub");
    } else if(net.iot == "connecting"){
      msgobj.push("Net-InitHub");
    } else if(net.iot == "disconnected" || net.status == "connected"){
      msgobj.push("Net-NoHub");
    } else if(net.iot == "disconnected" && net.status == "disconnected"){
      msgobj.push("NoNet");
    }
    
    console.log(msgobj, net);

    hmiAct = this.getNetworkIndicatorState(msgobj);

    return hmiAct;
  }


}
