import {ErrorHandler, Injectable} from '@angular/core';
import {LoggerService} from './logger.service';

@Injectable({
  providedIn: 'root'
})
export class CustomErrorHandlerService extends ErrorHandler {

  constructor(private logger: LoggerService) {
      super();
  }

  handleError(error) {
      // Here you can provide whatever logging you want
      this.logger.logError(error);
      super.handleError(error);
  }
}
