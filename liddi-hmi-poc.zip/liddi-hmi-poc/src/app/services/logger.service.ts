import { Injectable } from '@angular/core';
import { DeviceApiService } from "../services/device-api.service";
import { LogLevel, LogMessage } from '../models/LogMessage';

@Injectable({
  providedIn: 'root'
})
export class LoggerService {

  constructor(public restApi: DeviceApiService) { }

  logError(err: any){  
    var errMsg = JSON.stringify(err, Object.getOwnPropertyNames(err));

    var logMsg:LogMessage = new LogMessage("HMI[local]",LogLevel.Error, errMsg);
    this.restApi.postLog(logMsg);
  }
}
