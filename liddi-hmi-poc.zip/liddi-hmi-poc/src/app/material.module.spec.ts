import { MaterialModule } from './material.module';

describe('MaterialModule', () => {
  it('should create an instance', () => {
    expect(new MaterialModule()).toBeTruthy();
  });
});
