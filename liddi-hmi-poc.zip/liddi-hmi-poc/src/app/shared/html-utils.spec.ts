import { TestBed } from '@angular/core/testing';

import { HtmlUtils } from './html-utils';

describe('HtmlUtilsService', () => {
  let service: HtmlUtils;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HtmlUtils);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
