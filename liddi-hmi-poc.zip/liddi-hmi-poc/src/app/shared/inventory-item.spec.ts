import { InventoryItem } from './inventory-item';

describe('InventoryItem', () => {
  it('should create an instance', () => {
    expect(new InventoryItem()).toBeTruthy();
  });
});
