import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HtmlUtils {

  constructor() { }
  
  stripAnchorLinks(text) {
    console.log("stripping!");
    var re = /<a\s.*?href=[\"\'](.*?)[\"\']*?>(.*?)<\/a>/g;
    var str = text;
    var subst = '$2';
    var result = str.replace(re, subst);
    return result;
  }

  removeHrefFromAnchor(html) { 
    var container = document.createElement('p');
    container.innerHTML = html;
    
    var elements = container.getElementsByTagName('*');
    
    for (var i = 0, max = elements.length; i < max; i++) {      
      if (elements[i].tagName === 'A') {
        (elements[i] as HTMLAnchorElement).href = 'javascript:void(0);';
      }
    }

    return [].map.call( elements, function(node){
        return node.outerHTML;
    }).join("");
  }

  upperCaseFirstChar(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  titleCase(str) {
    str = str.toLowerCase().split(' ');
    for (var i = 0; i < str.length; i++) {
      str[i] = str[i].charAt(0).toUpperCase() + str[i].slice(1); 
    }
    return str.join(' ');
  }

  formatDateTime(strDate:string, option:string = 'short'):string {
    var dtx = strDate;
    const dt = Date.parse(strDate);

    if(!isNaN(dt)){
      const dty = new Date(strDate);
      //assume option is 'short'
      dtx = dty.getMonth()+"/"+dty.getDate()+"/"+dty.getFullYear();
    }
    // (new Date(date) !== "Invalid Date") && !isNaN(new Date(date))
    return dtx;
  }
}
