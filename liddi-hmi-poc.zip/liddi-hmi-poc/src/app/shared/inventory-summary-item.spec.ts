import { InventorySummaryItem } from './inventory-summary-item';

describe('InventorySummaryItem', () => {
  it('should create an instance', () => {
    expect(new InventorySummaryItem()).toBeTruthy();
  });
});
