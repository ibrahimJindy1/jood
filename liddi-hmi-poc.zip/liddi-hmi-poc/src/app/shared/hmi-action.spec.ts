import { HmiAction } from './hmi-action';

describe('HmiAction', () => {
  it('should create an instance', () => {
    expect(new HmiAction()).toBeTruthy();
  });
});
