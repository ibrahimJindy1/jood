export class HmiAction {

    public display: string;
    public route: string;
    public actionType: string;
    public imageSrc: string;
    
}