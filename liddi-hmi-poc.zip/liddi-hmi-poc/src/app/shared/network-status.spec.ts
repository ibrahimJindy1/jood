import { NetworkStatus } from './network-status';

describe('NetworkStatus', () => {
  it('should create an instance', () => {
    expect(new NetworkStatus()).toBeTruthy();
  });
});
