export class NetworkConfig {    
	id: string;
	device: string;
	primary: boolean;
    config: {
		ssid: string;
		pass: string;
		ip: string;
		mask: string;
		gwy: string;
	}
}
