export class InventorySummaryItem {
}
