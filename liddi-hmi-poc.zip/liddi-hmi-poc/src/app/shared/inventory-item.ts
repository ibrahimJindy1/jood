export class InventoryItem {
	sku: string;
	description: boolean;
    qty: number;
}
