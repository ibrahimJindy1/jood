import { NetworkConfig } from './network-config';

describe('NetworkConfig', () => {
  it('should create an instance', () => {
    expect(new NetworkConfig()).toBeTruthy();
  });
});
