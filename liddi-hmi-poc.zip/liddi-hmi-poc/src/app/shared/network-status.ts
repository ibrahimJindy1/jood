export class NetworkStatus {
    id: string;
	device: string;
	primary: boolean;
    status: string;
    iot: string;
}
