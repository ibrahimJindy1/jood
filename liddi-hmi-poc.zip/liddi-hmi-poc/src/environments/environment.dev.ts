export const environment = {
  appVersion: require('../../package.json').version + '-dev',
  production: false,
  deviceMonitor_wsUrl: "ws://192.168.1.138:1880/red/hmi_socket", //requires docker on this host to be running emualtor app
  deviceApi_httpUrl: "http://192.168.1.138:1880/red"
};
