export const environment = {
  appVersion: require('../../package.json').version,
  production: true,
  deviceMonitor_wsUrl: "ws://localhost:1880/red/hmi_socket",
  deviceApi_httpUrl: "http://localhost:1880/red",
  deviceApi_apiKey: "50cb32e6-7641-4bc6-baf0-b4d92897ea07"
};
