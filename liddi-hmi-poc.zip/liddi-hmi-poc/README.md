# LLIDI (Angular) App

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.0.0.

This is a Simple Angular-based app for web apps and PWAs.

Please refer to [Medium Article](https://itnext.io/simple-splash-screen-for-your-angular-web-apps-and-pwas-f4fbf897540b) for more info.

npm install -g @angular/cli

## Development server

when using nvm, instead of `ng serve` use: `npm start`

option: ng serve --disable-host-check

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng generate component component-name` to generate a new component. You can also use `ng generate directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `--prod` flag for a production build.

To automatically `increment version in package.json` during build (pre-build stage):

	npm run build --prod

Reference: https://medium.com/@tolvaly.zs/how-to-version-number-angular-6-applications-4436c03a3bd3
## Running unit tests

Run `ng test` to execute the unit tests via [Karma](https://karma-runner.github.io).

## Running end-to-end tests

Run `ng e2e` to execute the end-to-end tests via [Protractor](http://www.protractortest.org/).

## Further help

To get more help on the Angular CLI use `ng help` or go check out the [Angular CLI README](https://github.com/angular/angular-cli/blob/master/README.md).

## Notes on `ng` :
	ng serve --disable-host-check
	ng serve --open --port 4300
	ng build --prod

## Optionally, use build script to rev up the app version
	npm run build

## Reference - Generate Commands
	ng g service services/[servicename]
	ng g component components/[componentname]
	ng g class shared/[classname]

	ng g s services/[servicename] --module app
	ng g c components/[componentname] --module app
	ng g cl shared/[classname] --module app